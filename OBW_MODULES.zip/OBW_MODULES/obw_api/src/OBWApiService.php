<?php

namespace Drupal\obw_api;

use Drupal;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Drupal\webform\Entity\WebformSubmission;
use Symfony\Component\HttpFoundation\JsonResponse;

class OBWApiService
{
  const RADIUS_TOP_LEFT = 'radius-top-left';
  const RADIUS_TOP_RIGHT = 'radius-top-right';
  const RADIUS_BOTTOM_LEFT = 'radius-bottom-left';
  const RADIUS_BOTTOM_RIGHT = 'radius-bottom-right';
  const RADIUS_CIRCLE = 'radius-circle text-center';
  const BG_COLOR_SHAPE = ['bg-purple', 'bg-burntSienna', 'bg-greenDark'];

  public function logout($user)
  {
    $collector = \Drupal::service('simple_oauth.expired_collector');
    // Collect the affected tokens and expire them.
    if ($user instanceof AccountInterface) {
      $etm = Drupal::entityTypeManager();
      $action_service = Drupal::service('action_entity.action_service');
      $url = 'https://forum.ourbetterworld.org/api/v2/users/tbt/' . $user->id() . '/logout';
      $headers = [
        'authorization: Bearer 5fc6717a-0dc6-4522-966a-7723cabea07e'
      ];
      $action_service->cUrlPost($url, [], $headers);

      $oauth2_token = $etm->getStorage('oauth2_token')->loadByProperties(['auth_user_id' => $user->id()]);
      foreach ($oauth2_token as $toke) {
        $toke->delete();
      }

      $session_manager = \Drupal::service('session_manager');
      $session_manager->delete($user->id());
      Drupal::logger('logout_multi_sites')->info('The uid ' . $user->id() . ' has logged out.');
      $response = new JsonResponse([
        'data' => [
          'message' => 'Logout succeed!'
        ],
        'success' => TRUE
      ]);
      $response->setStatusCode(200);
      return $response;
    }
    Drupal::logger('logout_multi_sites')->info('The uid ' . $user->id() . ' hasn\'t logged out yet.');
    $response = new JsonResponse([
      'data' => [
        'message' => 'Logout failed!'
      ],
      'success' => FALSE
    ]);
    $response->setStatusCode(200);
    return $response;
  }

  public function loadSIDByEmail($email, $webform_id)
  {
    $connection = Drupal::database();
    $str_query = "SELECT wf1.sid
                  FROM {webform_submission_data} AS wf1
                  WHERE wf1.name = 'email' AND wf1.value = :email AND wf1.webform_id = :webform_id";

    $query_params = [
      ':email' => $email,
      ':webform_id' => $webform_id
    ];
    $query = $connection->query($str_query, $query_params);
    $query_result = $query->fetchAll();

    if (empty($query_result)) {
      return false;
    }

    return $query_result;
  }

  public function personaCreateSubmissionVerifiedAccount($persona_id, $current_user)
  {
    $account = User::load($current_user->id());
    $subcribe_obw = "no";
    if (isset($account->field_account_news_subscribed) && $account->field_account_news_subscribed->value) {
      if (isset($account->field_account_subcribe_options) && !empty($account->field_account_subcribe_options->value)) {
        $subcribe_obw = $account->field_account_subcribe_options->value;
      } else {
        $subcribe_obw = 'weekly';
      }
    }
    $ws_data = [
      'first_name' => $account->field_account_first_name->value,
      'last_name' => $account->field_account_last_name->value,
      'email' => $current_user->getEmail(),
      'would_you_like_to_receive_stories_of_good_like_this_one_from_our' => $subcribe_obw,
      'i_have_read_and_agree_to_the_collection_use_and_disclosure_of_pe' => "1",
      'account_status' => "1",
      'persona_id' => $persona_id,
      'send_mail' => "1"
    ];

    $ws = WebformSubmission::create([
      'webform_id' => 'email_me_a_copy_of_my_persona',
      'uri' => Node::load($persona_id)->toUrl()->toString(),
      'entity_type' => 'node',
      'entity_id' => $persona_id,
      'in_draft' => FALSE,
      'langcode' => 'en',
      'remote_addr' => Drupal::request()->getClientIp(),
      'uid' => $current_user->id(),
      'data' => $ws_data
    ]);
    $ws->save();
  }

  public function getPostsBirthday2021($device = 'desktop', $filter = NULL)
  {
    $data_res = [
      'data' => []
    ];
    $wf_query_service = \Drupal::service('obw_utilities.entity_query');
    $square_posts = $wf_query_service->getPostBirthday2021ByShape('square', $filter);
    $vertical_posts = $wf_query_service->getPostBirthday2021ByShape('vertical_rectangle', $filter);
    $horizontal_posts = $wf_query_service->getPostBirthday2021ByShape('horizontal_rectangle', $filter);
    $index = 0;
    $number_shapes_on_page = $this->calculateNumberShapeForGalleries($device, count($square_posts), count($vertical_posts), count($horizontal_posts));
    while (!empty($square_posts) || !empty($vertical_posts) || !empty($horizontal_posts)) {
      $index++;
      $data_res['data'][$index] = $this->buildGalleryBirthday2021($index, $number_shapes_on_page, $square_posts, $vertical_posts, $horizontal_posts);
    }
    return $data_res;
  }

  /**
   *
   */
  private function calculateNumberShapeForGalleries($device, $total_square_posts, $total_vertical_posts, $total_horizontal_posts)
  {
    $total_point_per_page = ($device == 'mobile') ? 12 : 16;
    $total_point = $total_square_posts + ($total_vertical_posts * 2) + ($total_horizontal_posts * 2);
    $number_pages = ceil($total_point / $total_point_per_page);
    return [
      'vertical' => ceil($total_vertical_posts / $number_pages),
      'horizontal' => ceil($total_horizontal_posts / $number_pages),
      'square' => $total_point_per_page - (ceil($total_vertical_posts / $number_pages) + ceil($total_horizontal_posts / $number_pages)) * 2,
      'total_point_per_page' => $total_point_per_page,
      'device' => $device
    ];
  }

  /**
   *
   */
  private function buildGalleryBirthday2021($index, $number_shapes_on_page, &$all_square_posts, &$all_vertical_posts, &$all_horizontal_posts)
  {
    $total_point = $number_shapes_on_page['total_point_per_page'];
    if ($index > 1 && $number_shapes_on_page['device'] == 'mobile') {
      /**
       * By default, we will show 6 rows of images. Upon clicking on 'View More' everytime, we will load the next 8 rows of images.
       * For example, default: shows 6 rows. 1st click on load more, total 14 rows (6+8). Second click on load more, total 22 rows (6+8+8).
       */
      $total_point = 16;
    }
    $current_point = 0;
    $galleries = [];
    /**
     * Value of the point:
     * 1: if the post is square
     * 2: if the post is rectangle
     */
    $vertical_posts = $this->getPostsByShape($all_vertical_posts, $number_shapes_on_page['vertical'], $current_point, 2);
    $horizontal_posts = $this->getPostsByShape($all_horizontal_posts, $number_shapes_on_page['horizontal'], $current_point, 2);
    $square_posts = $this->getPostsByShape($all_square_posts, $total_point - $current_point, $current_point, 1);
    while ($current_point < $total_point && (!empty($all_vertical_posts) || !empty($all_horizontal_posts))) {
      if ($total_point - $current_point < 2) {
        break;
      }
      if (!empty($all_vertical_posts)) {
        $vertical_posts = array_merge($vertical_posts, $this->getPostsByShape($all_vertical_posts, floor(($total_point - $current_point) / 2), $current_point, 2));
      } else if (!empty($all_horizontal_posts)) {
        $vertical_posts = array_merge($vertical_posts, $this->getPostsByShape($all_horizontal_posts, floor(($total_point - $current_point) / 2), $current_point, 2));
      }

      if ($current_point < $total_point && (!empty($all_vertical_posts) || !empty($all_horizontal_posts))) {
        \Drupal::logger('get_birthday2021_posts')->info('build gallery birthday 2021 wrong!');
      }
    }
    if (count($square_posts) > 2) {
      $square_posts_1 = array_slice($square_posts, 0, floor(count($square_posts) / 2));
      $square_posts_2 = array_slice($square_posts, floor(count($square_posts) / 2));
    }
    else {
      $galleries = array_merge($galleries, $vertical_posts, $horizontal_posts, $square_posts);
      shuffle($galleries);
    }

    if (!empty($square_posts_1) && !empty($square_posts_2)) {
      $galleries = array_merge($galleries, $vertical_posts, $horizontal_posts, $square_posts_1);
      shuffle($galleries);
      $galleries = array_merge($galleries, $square_posts_2);
    }

    return $galleries;
  }

  /**
   *
   */
  private function getPostsByShape(&$posts, $length, &$current_point, $point)
  {
    $shape_posts = $this->convertShapePostsObjectToArray(array_slice($posts, 0, $length, TRUE));
    $number_posts = count(array_slice($posts, 0, $length, TRUE));
    $current_point += $point * $number_posts;
    $posts = array_slice($posts, $number_posts);
    return $shape_posts;
  }


  /**
   *
   */
  public function convertShapePostsObjectToArray($shape_posts)
  {
    $shape_posts_converted = [];
    $obw_utilities_service = \Drupal::service('obw_utilities.service');
    $arr_bg_color = self::BG_COLOR_SHAPE;
    $img_styles = [
      'square' => 'square_442x442',
      'horizontal_rectangle' => 'horizontal_916x442',
      'vertical_rectangle' => 'vertical_442x916'
    ];
    foreach ($shape_posts as $shape_post) {
      $ws_data = $shape_post->getData();
      if (!empty($ws_data['share_your_story'])) {
        $short_desc = implode(' ', array_slice(explode(' ', $ws_data['share_your_story']), 0, 16)) . '...';
      }
      $shape_post_converted = [
        'first_name' => !empty($ws_data['first_name']) ? $ws_data['first_name'] : '',
        'last_name' => !empty($ws_data['last_name']) ? $ws_data['last_name'] : '',
        'photo' => !empty($ws_data['image_upload']) ? $obw_utilities_service->getImgUrlByImageStyleForFileEntity($ws_data['image_upload'], $img_styles, $ws_data['image_type']) : '',
        'original_photo' => !empty($ws_data['image_upload']) ? $obw_utilities_service->getFileUrlFromFileId($ws_data['image_upload']) : '',
        'full_desc' => !empty($ws_data['share_your_story']) ? $ws_data['share_your_story'] : '',
        'short_desc' => !empty($short_desc) ? $short_desc : '',
        'occupation' => !empty($ws_data['occupation']) ? $ws_data['occupation'] : '',
        'shape_type' => !empty($ws_data['image_type']) ? $ws_data['image_type'] : '',
        'query_param' => !empty($ws_data['obw_values_story']) ? explode('?', $ws_data['obw_values_story'])[1] : '',
        'our_values' => !empty($ws_data['pick_one_of_our_values']) ? $ws_data['pick_one_of_our_values'] : '',
        'shape_style' => !empty($ws_data['shapes']) ? $this->mappingShapeStype($ws_data['shapes']) : '',
        'background_color' => empty($ws_data['image_upload']) ? $this->randomBackgroundColorForShape($arr_bg_color) : ''
      ];
      $twig = \Drupal::service('twig');
      $template = $twig->loadTemplate(drupal_get_path('theme', 'obw_theme') . '/templates/includes/story/popup-values-story-birthday2021.html.twig');
      $shape_post_converted['post_detail_html'] = $template->render(['post_detail' => $shape_post_converted]);
      $shape_posts_converted[] = $shape_post_converted;
    }
    return $shape_posts_converted;
  }

  private function mappingShapeStype($shape_key)
  {
    $shapes_args = [
      'shape1' => self::RADIUS_BOTTOM_LEFT,
      'shape2' => self::RADIUS_BOTTOM_RIGHT,
      'shape3' => self::RADIUS_TOP_LEFT,
      'shape4' => self::RADIUS_TOP_RIGHT,
      'shape5' => self::RADIUS_TOP_LEFT . ' ' . self::RADIUS_TOP_RIGHT,
      'shape6' => self::RADIUS_BOTTOM_LEFT . ' ' . self::RADIUS_BOTTOM_RIGHT,
      'shape7' => self::RADIUS_TOP_LEFT . ' ' . self::RADIUS_BOTTOM_LEFT,
      'shape8' => self::RADIUS_TOP_RIGHT . ' ' . self::RADIUS_BOTTOM_RIGHT,
      'shape9' => self::RADIUS_TOP_RIGHT . ' ' . self::RADIUS_BOTTOM_LEFT,
      'shape10' => self::RADIUS_TOP_LEFT . ' ' . self::RADIUS_BOTTOM_RIGHT,
      'shape11' => self::RADIUS_TOP_RIGHT . ' ' . self::RADIUS_BOTTOM_RIGHT . ' ' . self::RADIUS_BOTTOM_LEFT,
      'shape12' => self::RADIUS_TOP_LEFT . ' ' . self::RADIUS_BOTTOM_RIGHT . ' ' . self::RADIUS_BOTTOM_LEFT,
      'shape13' => self::RADIUS_TOP_LEFT . ' ' . self::RADIUS_TOP_RIGHT . ' ' . self::RADIUS_BOTTOM_RIGHT,
      'shape14' => self::RADIUS_BOTTOM_LEFT . ' ' . self::RADIUS_TOP_LEFT . ' ' . self::RADIUS_TOP_RIGHT,
      'shape15' => self::RADIUS_CIRCLE,
    ];
    return $shapes_args[$shape_key];
  }

  private function randomBackgroundColorForShape(&$arr_rand) {
    if (empty($arr_rand)) {
      $arr_rand = self::BG_COLOR_SHAPE;
    }
    $key = array_rand($arr_rand);
    $bg_color = $arr_rand[$key];
    unset($arr_rand[$key]);
    return $bg_color;
  }
}
