<?php

namespace Drupal\obw_api\Plugin\rest\resource;

use Drupal\webform\Entity\Webform;
use Drupal\webform\Entity\WebformSubmission;
use Drupal\webform\WebformSubmissionForm;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ModifiedResourceResponse;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Creates a resource for submitting a webform.
 *
 * @RestResource(
 *   id = "webform_rest_submit",
 *   label = @Translation("Webform Submit"),
 *   uri_paths = {
 *     "canonical" = "/webform_rest/submit",
 *     "https://www.drupal.org/link-relations/create" = "/webform_rest/submit"
 *   }
 * )
 */
class WebformRestSubmitCustom extends ResourceBase {

  /**
   * Responds to entity POST requests and saves the new entity.
   *
   * @param array $webform_data
   *   Webform field data and webform ID.
   *
   * @return \Drupal\rest\ResourceResponse
   *   The HTTP response object.
   *
   * @throws \Symfony\Component\HttpKernel\Exception\HttpException
   *   Throws HttpException in case of error.
   */
  public function post(array $webform_data) {

    // Basic check for webform ID.
    if (empty($webform_data['webform_id'])) {
      $errors = [
        'error' => [
          'code' => '500'
        ]
      ];
      return new JsonResponse($errors, 500);
    }

    // Convert to webform values format.
    $values = [
      'webform_id' => $webform_data['webform_id'],
      'entity_type' => NULL,
      'entity_id' => NULL,
      'in_draft' => FALSE,
      'remote_addr' => !empty($webform_data['browser_ip_address']) ? $webform_data['browser_ip_address'] : '',
      'uri' => '/webform/' . $webform_data['webform_id'] . '/api',
      'created' => time()
    ];

    $values['data'] = $webform_data;

    // Don't submit webform ID.
    unset($values['data']['webform_id']);

    // Check for a valid webform.
    $webform = Webform::load($values['webform_id']);
    if (!$webform) {
      $errors = [
        'error' => [
          'message' => 'Invalid webform_id value.'
        ]
      ];
      return new ModifiedResourceResponse($errors);
    }

    // Check webform is open.
    $is_open = WebformSubmissionForm::isOpen($webform);

    if ($is_open === TRUE) {
      // Validate submission.
      $errors = WebformSubmissionForm::validateFormValues($values);

      // Check there are no validation errors.
      if (!empty($errors)) {
        $errors = ['error' => $errors];
        return new ModifiedResourceResponse($errors);
      }
      else {
        // Return submission ID.

        if(!empty($values['webform_id'])) {
          switch ($values['webform_id']) {
            case 'subscribe_to_newsletter_tbt':
              if(!empty($values['data']) && !empty($values['data']['sign_up_for_obw_newsletter'])) {
                $subscriber_obw_values = [
                  "webform_id" => "subscribe_to_newsletter",
                  "entity_type" => null,
                  "entity_id" => null,
                  "in_draft" => false,
                  "remote_addr" => !empty($values['data']['browser_ip_address']) ? $values['data']['browser_ip_address'] : '',
                  "uri" => "/webform/subscribe_to_newsletter/api",
                  "data" => [
                    "email" => $values['data']['email']
                  ]
                ];


                // Validate submission.
                $subscriber_obw_errors = WebformSubmissionForm::validateFormValues($subscriber_obw_values);

                if(empty($subscriber_obw_errors)) {
                  $subscriber_obw_submission = WebformSubmissionForm::submitFormValues($subscriber_obw_values);

                }
              }

              $webform_submission = WebformSubmissionForm::submitFormValues($values);
              $user = user_load_by_mail($values['data']['email']);
              if($user) {
                $user->set('field_account_newsletter_tbt', '1');
                if(isset($subscriber_obw_submission)) {
                  $user->set('field_account_news_subscribed', '1');
                }
                $user->save();
              }
              return new ModifiedResourceResponse(['sid' => $webform_submission->id()]);
              break;
            default:
              $webform_submission = WebformSubmissionForm::submitFormValues($values);
              if($values['webform_id'] == 'wildlife_what_s_next') {
                return new ModifiedResourceResponse(['success' => preg_replace('/\s+/', ' ', trim(Webform::load('wildlife_what_s_next')->getSetting('confirmation_message')))]);
              }
              else {
                return new ModifiedResourceResponse(['sid' => $webform_submission->id()]);
              }
          }
        }
      }
    }
    else {
      $errors = [
        'error' => [
          'message' => 'This webform is closed, or too many submissions have been made.'
        ]
      ];
      return new ModifiedResourceResponse($errors);
    }
  }

}
