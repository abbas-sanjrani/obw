<?php

namespace Drupal\obw_api\Plugin\rest\resource;

use Drupal;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\Session\AccountInterface;
use Drupal\obw_reminder\Entity\ReminderEntity;
use Drupal\rest\ModifiedResourceResponse;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\Plugin\rest\resource\EntityResourceAccessTrait;
use Drupal\obw_api\Plugin\rest\resource\CustomEntityResourceValidationTrait;
use Drupal\user\UserInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;
use Drupal\user\Plugin\rest\resource\UserRegistrationResource;

/**
 * Represents user registration as a resource.
 *
 * @RestResource(
 *   id = "user_registration",
 *   label = @Translation("User registration"),
 *   serialization_class = "Drupal\user\Entity\User",
 *   uri_paths = {
 *     "https://www.drupal.org/link-relations/create" = "/user/register",
 *   },
 * )
 */
class UserResource extends UserRegistrationResource {

  use CustomEntityResourceValidationTrait;

  public function post(UserInterface $account = NULL) {

    $this->ensureAccountCanRegister($account);

    // Only activate new users if visitors are allowed to register and no email
    // verification required.

    $account->activate();

    $this->checkEditFieldAccess($account);

    //TODO: check rule to create user login name, currently get the first part of email address, with random num 100-999
    $new_name =  $account->name->value;
    $user = user_load_by_name($new_name);
    while ($user) {
      $rand_num = mt_rand(100,999);
      $new_name = $account->name->value .'_' .$rand_num;
      $user = user_load_by_name($new_name);
    }

    $account->set('name', $new_name);

    // Make sure that the user entity is valid (email and name are valid).
    if(!empty($this->validate($account)) && key_exists('status', $this->validate($account)) && $this->validate($account)['status'] === false) {
      return new ModifiedResourceResponse($this->validate($account), 422);
    }

    // Create the account.
    $account->save();
    $session_handler = Drupal::service('obw_social.session_handler');
    $session_handler->set('redirect_to_fe', $account->field_account_signup_url->value);

//    TODO: Remove the reminder temporarily and will apply again when the copy is approved
//    if(isset($account->field_account_submit_tbt_enquiry) && !empty($account->field_account_submit_tbt_enquiry->value) && $account->field_account_submit_tbt_enquiry->value == '1') {
//      $reminder_data = [
//        'name' => 'Reminder ' . $account->mail->value,
//        'user_id' => $account->id(),
//        'status' => '1',
//        'field_reminder_email' => $account->mail->value,
//        'field_reminder_type' => 2,
//        'field_reminder_time' => time() + 86400,
//        'field_reminder_desnation_url' => $account->field_account_signup_url->value,
//        'field_reminder_submission_id' => '',
//        'field_reminder_duration' => 86400,
//        'field_reminder_total' => 2,
//        'field_reminder_count' => 1,
//        'field_reminder_status' => 0
//      ];
//
//      $reminder_entity = ReminderEntity::create($reminder_data);
//      $reminder_entity->save();
//      $session_handler->set('reminder_record_id', $reminder_entity->id());
//    }

    $this->sendEmailNotifications($account);

    return new ModifiedResourceResponse($account, 200);
  }

  /**
   * Ensure the account can be registered in this request.
   *
   * @param \Drupal\user\UserInterface $account
   *   The user account to register.
   */
  protected function ensureAccountCanRegister(UserInterface $account = NULL) {

    if ($account === NULL) {
      throw new BadRequestHttpException('No user account data for registration received.');
    }

    // POSTed user accounts must not have an ID set, because we always want to
    // create new entities here.
    if (!$account->isNew()) {
      throw new BadRequestHttpException('An ID has been set and only new user accounts can be registered.');
    }

    //Check first name, last name, email and Accept Terms and Conditions and Privacy Policy
    if(!isset($account->field_account_first_name) || (isset($account->field_account_first_name) && empty($account->field_account_first_name->value))) {
      throw new BadRequestHttpException('The First Name field is required.');
    }

    if(!isset($account->field_account_last_name) || (isset($account->field_account_last_name) && empty($account->field_account_last_name->value))) {
      throw new BadRequestHttpException('The Last Name field is required.');
    }

    if(!isset($account->mail) || empty($account->getEmail())) {
      throw new BadRequestHttpException('The Email field is required.');
    }

    if(!isset($account->field_account_accept_tnc) || (isset($account->field_account_accept_tnc) && $account->field_account_accept_tnc->value !== "1")) {
      throw new BadRequestHttpException('Please agree to the Terms and Conditions.');
    }

    if (!$account->isNew()) {
      throw new BadRequestHttpException('An ID has been set and only new user accounts can be registered.');
    }

    // Only allow anonymous users to register, authenticated users with the
    // necessary permissions can POST a new user to the "user" REST resource.
    // @see \Drupal\rest\Plugin\rest\resource\EntityResource
    if (!$this->currentUser->isAnonymous()) {
      throw new AccessDeniedHttpException('Only anonymous users can register a user.');
    }

    // Verify that the current user can register a user account.
    if ($this->userSettings->get('register') == USER_REGISTER_ADMINISTRATORS_ONLY) {
      throw new AccessDeniedHttpException('You cannot register a new user account.');
    }

    if (!$this->userSettings->get('verify_mail')) {
      if (empty($account->getPassword())) {
        // If no e-mail verification then the user must provide a password.
        throw new UnprocessableEntityHttpException('No password provided.');
      }
    }
    else {
      if (!empty($account->getPassword())) {
        // If e-mail verification required then a password cannot provided.
        // The password will be set when the user logs in.
        throw new UnprocessableEntityHttpException('A Password cannot be specified. It will be generated on login.');
      }
    }
  }


}
