<?php

namespace Drupal\obw_api\Listener;

use Drupal;
use Drupal\image\Entity\ImageStyle;
use Drupal\user\Entity\User;
use Drupal\user\RoleInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Drupal\Component\Serialization\Json;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Url;
use Drupal\webform\Utility\WebformElementHelper;
use Drupal\webform\Entity\WebformOptions;

/**
 * Class ExampleLoginListener.
 *
 * @package Drupal\example
 */
class APIListener implements EventSubscriberInterface
{
  /**
   * Current path.
   *
   * @var pathcurrent
   */
  private $currentPath;

  /**
   * Constructor with dependency injection.
   *
   * Current path @param \Drupal\Core\Path\CurrentPathStack $currentPath .
   */
  public function __construct(CurrentPathStack $currentPath)
  {
    $this->currentPath = $currentPath;
  }

  /**
   * Alter apiResponse.
   *
   * Event @param \Symfony\Component\HttpKernel\Event\FilterResponseEvent
   * $event .
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\Core\Entity\EntityMalformedException
   */
  public function apiResponse(FilterResponseEvent $event)
  {
    //    Handler when anonymous access to the account settings or donation history
    if (preg_match('/user\/(\d+)\/settings/', $this->currentPath->getPath(), $matches)
      || preg_match('/user\/(\d+)\/donations/', $this->currentPath->getPath(), $matches)) {
      if (Drupal::currentUser()->isAnonymous()) {
        $response = new RedirectResponse('/node');
        $response->send();
        die();
      } else {
        if (Drupal::currentUser()->id() != $matches[1]) {
          $response = new RedirectResponse('/node');
          $response->send();
          die();
        }
      }
    }

    //    Handler when register user from FE but in the BE logged in.
    if ($this->currentPath->getPath() == '/user/register' && Drupal::currentUser()
        ->isAuthenticated()) {
      $query = Drupal::request()->query;
      if ($query->get('schema') && $query->get('domain') && $query->get('path') && $query->get('client_id') && $query->get('client_secret') && $query->get('src')) {
        $schema = $query->get('schema');
        $domain = $query->get('domain');
        $client_id = $query->get('client_id');
        $client_secret = $query->get('client_secret');
        $src = $query->get('src');
        $login_oauth = '/user/login?destination=';
        if ($src == 'tbt') {
          $login_oauth .= '/oauth/authorize%3Fclient_id%3D' . $client_id
            . '%26client_secret%3D' . $client_secret . '%26redirect_uri%3D' . $schema . '//' . $domain . '/auth/tbt%26response_type%3Dcode%26scope%3D%26';
        } elseif ($src == 'forum') {
          $login_oauth .= '/oauth/authorize%3Fclient_id%3D' . $client_id
            . '%26client_secret%3D' . $client_secret . '%26redirect_uri%3D' . $schema . '//' . $domain . '/auth/tbt/callback%26response_type%3Dcode%26scope%3D%26';
        }
        $response = new RedirectResponse($login_oauth);
        $response->send();
      }
    }
    if ($this->currentPath->getPath() == '/oauth/debug') {
      $response = $event->getResponse();

      // Ensure not error response.
      if ($response->getStatusCode() !== 200) {
        return;
      }
      if ($content = $response->getContent()) {
        if ($decoded = Json::decode($content)) {
          if ($decoded['permissions']) {
            unset($decoded['permissions']);
          }
          APIListener::getResourcesUser($decoded);
          // Set new response JSON.
          $response->setContent(Json::encode($decoded));
          $event->setResponse($response);
        }
      }
      return;
    }
    // Get response.
    $response = $event->getResponse();

    // Ensure not error response.
    if ($response->getStatusCode() !== 200) {
      if ($response->getStatusCode() == 403
        && (preg_match('/api\/v1\/bookmark-list\/delete\/(\d+)/', $this->currentPath->getPath(), $matches)
          || preg_match('/api\/v1\/bookmark-list\/create/', $this->currentPath->getPath(), $matches)
          || preg_match('/api\/v1\/bookmark-list\/update/', $this->currentPath->getPath(), $matches)
          || preg_match('/action\/bookmark/', $this->currentPath->getPath(), $matches))) {
        $response->setStatusCode(401);
        $event->setResponse($response);
      }
    } else {
      // Decode and add img url.
      if ($content = $response->getContent()) {
        if ($decoded = Json::decode($content)) {
          if (preg_match('/api-v1\/crt\/(.*)\/(.*)/', $this->currentPath->getPath(), $matches)
            || preg_match('/jsonapi\/node\/(.*)\/(.*)/', $this->currentPath->getPath(), $matches)) {
            // Check if array >1 node.
            switch ($matches[1]) {
              case 'main':
              case 'story':
                if (array_key_exists(0, $decoded['data'])) {
                  foreach ($decoded['data'] as $key => $item) {
                    APIListener::customizeJsonResponseStory($decoded['data'][$key]);
                  }
                } else {
                  APIListener::customizeJsonResponseStory($decoded['data']);
                }
                break;

              case 'organisations':
                // Check if array >1 node.
                if (array_key_exists(0, $decoded['data'])) {
                  foreach ($decoded['data'] as $key => $item) {
                    APIListener::customizeJsonResponseOrganisations($decoded['data'][$key]);
                  }
                } else {
                  APIListener::customizeJsonResponseOrganisations($decoded['data']);
                }
                break;

              case 'page':
                $nid = $decoded['data']['attributes']['drupal_internal__nid'];
                $multimedia_node = self::loadMultimediaNode($nid);
                if ($multimedia_node) {
                  $decoded['data']['relationships']['field_contributors']['data'] = [];
                  self::customizeContributors($decoded['data']['relationships']['field_contributors']['data'], $multimedia_node);
                } else {
                  $decoded['data']['relationships']['field_contributors']['data'] = [];
                }

                if (!empty($decoded['data']['relationships']['field_basic_tabs_content'])
                  && !empty($decoded['data']['relationships']['field_basic_tabs_content']['data'])) {
                  self::loadTabsContent($decoded['data']['relationships']['field_basic_tabs_content']['data']);
                }
                break;

              default:
                break;
            }
            // Set new response JSON.
            $response->setContent(Json::encode($decoded));
            $event->setResponse($response);
          }

          if (preg_match('/webform_rest\/(.*)\/fields/', $this->currentPath->getPath(), $matches)) {
            $alter_elements = [
              'webform_id' => $matches[1],
              'markup' => [],
              'fields' => [],
              'actions' => [],
            ];
            APIListener::customizeJsonResponseWebform($decoded, $alter_elements);
            // Set new response JSON.
            $response->setContent(Json::encode($alter_elements));
            $event->setResponse($response);
          }

          if (preg_match('/view_rest\/(.*)/', $this->currentPath->getPath(), $matches)) {
            $route = Drupal::routeMatch()->getRouteObject();
            $alter_response = [
              'view_id' => $route->getDefault('view_id'),
              'display_id' => $route->getDefault('display_id'),
              'header' => '',
              'items' => [],
              'field_metatags' => [],
            ];
            self::customizeJsonResponseMeetTheResidentsView($decoded, $alter_response);
            // Set new response JSON.
            $response->setContent(Json::encode($alter_response));
            $event->setResponse($response);
          }

          if ($this->currentPath->getPath() == '/user/login') {
            self::customizeJsonResponseLoginViaEmail($decoded);
            // Set new response JSON.
            $response->setContent(Json::encode($decoded));
            $event->setResponse($response);
          }

          if ($this->currentPath->getPath() == '/user/register') {

            if (!empty($decoded['uid'][0]['value'])) {
              $uid = $decoded['uid'][0]['value'];
              $decoded = [
                'uid' => $uid,
                'status' => TRUE,
                'title' => 'Account created!',
                'message' => 'Your account has been created. <br>Please check your email to set your password.',
              ];
            }
            // Set new response JSON.
            $response->setContent(Json::encode($decoded));
            $event->setResponse($response);
          }

          if (preg_match('/api\/v1\/taxonomy-role\/(.*)/', $this->currentPath->getPath(), $matches)
            || preg_match('/api\/v1\/user\/(\d+)/', $this->currentPath->getPath(), $matches)) {
            self::addPublicProfileForUser($decoded);
            $decoded = $decoded[0];

            // Set new response JSON.
            $response->setContent(Json::encode($decoded));
            $event->setResponse($response);
          }

          if ($this->currentPath->getPath() === '/api/v1/user') {
            self::addPublicProfileForUser($decoded);
            $response->setContent(Json::encode($decoded));
            $event->setResponse($response);
          }
        }
      }
    }
  }

  /**
   * The subscribed events.
   */
  public static function getSubscribedEvents()
  {
    $events = [];
    $events[KernelEvents::RESPONSE][] = ['apiResponse'];
    return $events;
  }

  /**
   * Data @param $item .
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\Core\Entity\EntityMalformedException
   */
  public static function customizeJsonResponseOrganisations(&$item)
  {
    if ($item['type'] == 'node--organisations') {
      $etm = Drupal::entityTypeManager();
      $nid = $item['attributes']['drupal_internal__nid'];
      $multimedia_node = self::loadMultimediaNode($nid);
      if ($multimedia_node) {
        $item['relationships']['field_contributors']['data'] = [];
        self::customizeContributors($item['relationships']['field_contributors']['data'], $multimedia_node);
      } else {
        $item['relationships']['field_contributors']['data'] = [];
      }

      if (!empty($item['relationships']['field_orgs_photo_list']['data'])) {
        foreach ($item['relationships']['field_orgs_photo_list']['data'] as $key => $photo) {
          $file = Drupal::entityTypeManager()
            ->getStorage('file')
            ->loadByProperties(['uuid' => $photo['id']]);
          $file = reset($file);
          if ($file && !empty($file->uri->value)) {
            $style730x400 = ImageStyle::load('medium_730x400');
            $style1460x800 = ImageStyle::load('large_1400x800');
            $image730x400 = $style730x400->buildUrl($file->uri->value);
            $image1460x800 = $style1460x800->buildUrl($file->uri->value);
            $item['relationships']['field_orgs_photo_list']['data'][$key]['img_url']['medium'] = $image730x400;
            $item['relationships']['field_orgs_photo_list']['data'][$key]['img_url']['big'] = $image1460x800;
          }
        }
      }
      if (!empty($item['relationships']['field_orgs_take_action']['data'])) {
        foreach ($item['relationships']['field_orgs_take_action']['data'] as $key => $cta) {
          $cta_node = Drupal::entityTypeManager()
            ->getStorage('node')
            ->loadByProperties(['uuid' => $cta['id']]);
          $cta_node = reset($cta_node);
          if ($cta_node) {
            $cta_description = !empty($cta_node->field_cta_short_description->value) ? $cta_node->field_cta_short_description->value : '';
            if (!empty($cta_node->field_cta_image->getValue())) {
              $file = Drupal::entityTypeManager()
                ->getStorage('file')
                ->load($cta_node->field_cta_image->getValue()[0]['target_id']);
              $file = reset($file);
              if ($file && !empty($file['uri']['x-default'])) {
                $style180x180 = ImageStyle::load('thumbnail_180x180');
                $image180x180 = $style180x180->buildUrl($file['uri']['x-default']);
                $cta_image = [
                  'url' => $image180x180,
                  'title' => $cta_node->field_cta_image->getValue()[0]['title'],
                  'alt' => $cta_node->field_cta_image->getValue()[0]['alt'],
                ];
              }
            }

            $cta_category_id = $cta_node->field_cta_category->getValue();
            if (!empty($cta_category_id[0]['target_id'])) {
              $cta_category = Drupal::entityTypeManager()
                ->getStorage('taxonomy_term')
                ->load($cta_category_id[0]['target_id']);
              if ($cta_category) {
                $cta_category_name = $cta_category->name->value;
              }
            }

            if (!empty($cta_node->field_cta_link->getValue()) && !empty($cta_node->field_cta_link->getValue()[0])) {
              $cta_link = !empty($cta_node->field_cta_link->getValue()[0]['uri']) ? Url::fromUri($cta_node->field_cta_link->getValue()[0]['uri'], ['absolute' => TRUE])
                ->toString() : '';
              $cta_button = !empty($cta_node->field_cta_link->getValue()[0]['title']) ? $cta_node->field_cta_link->getValue()[0]['title'] : '';
              $cta_target = !empty($cta_node->field_cta_link->getValue()[0]['options']['attributes']) ? $cta_node->field_cta_link->getValue()[0]['options']['attributes']['target'] : '';
            }

            if (isset($cta_node->field_cta_form_detail) && !empty($cta_node->field_cta_form_detail->getValue())) {
              $url_get_form_elements = '/webform_rest/' . $cta_node->field_cta_form_detail->getValue()[0]['target_id'] . '/fields';
            } else {
              $url_get_form_elements = '';
            }
            $item['relationships']['field_orgs_take_action']['data'][$key]['cta_image'] = isset($cta_image) ? $cta_image : '';
            $item['relationships']['field_orgs_take_action']['data'][$key]['category_name'] = isset($cta_category_name) ? $cta_category_name : '';
            $item['relationships']['field_orgs_take_action']['data'][$key]['short_description'] = $cta_description;
            $item['relationships']['field_orgs_take_action']['data'][$key]['link'] = isset($cta_link) ? $cta_link : '';
            $item['relationships']['field_orgs_take_action']['data'][$key]['url_get_form_elements'] = isset($url_get_form_elements) ? $url_get_form_elements : '';
            $item['relationships']['field_orgs_take_action']['data'][$key]['button_name'] = isset($cta_button) ? $cta_button : '';
            $item['relationships']['field_orgs_take_action']['data'][$key]['target'] = isset($cta_target) ? $cta_target : '';
            $item['relationships']['field_orgs_take_action']['data'][$key]['status'] = $cta_node->status->value;
          }
        }
      }

      if (!empty($item['relationships']['field_orgs_their_story']['data'])) {
        foreach ($item['relationships']['field_orgs_their_story']['data'] as $key => $story) {
          $story_node = Drupal::entityTypeManager()
            ->getStorage('node')
            ->loadByProperties(['uuid' => $story['id']]);
          $story_node = reset($story_node);
          if ($story_node) {
            if (!$story_node->get('field_story_feature_media')->isEmpty()) {
              // One line uri without loading.
              if ($story_node->get('field_story_feature_media')->entity) {
                $thumbnail = $story_node->get('field_story_feature_media')->entity->get('thumbnail')[0]->entity->uri->value;
                $style350x200 = ImageStyle::load('thumbnail_350x200');
                $image350x200 = $style350x200->buildUrl($thumbnail);
              }
            }
            if (!empty($story_node->field_story_category->getValue())) {
              $story_cause = $cta_category = Drupal::entityTypeManager()
                ->getStorage('taxonomy_term')
                ->load($story_node->field_story_category->getValue()[0]['target_id']);
              $story_cause_name = $story_cause->name->value;
              $story_cause_url = $story_cause->toUrl('canonical', ['absolute' => TRUE])
                ->toString();
            }

            $item['relationships']['field_orgs_their_story']['data'][$key]['thumbnail_350x200'] = isset($image350x200) ? $image350x200 : '';
            $item['relationships']['field_orgs_their_story']['data'][$key]['title'] = !empty($story_node->title->value) ? $story_node->title->value : '';
            $item['relationships']['field_orgs_their_story']['data'][$key]['short_description'] = !empty($story_node->field_story_short_description->value) ? $story_node->field_story_short_description->value : '';
            $item['relationships']['field_orgs_their_story']['data'][$key]['published_date'] = !empty($story_node->published_at->value) ? date('d M Y', $story_node->published_at->value) : '';
            $item['relationships']['field_orgs_their_story']['data'][$key]['story_cause'] = [
              'name' => isset($story_cause_name) ? $story_cause_name : '',
              'url' => isset($story_cause_url) ? $story_cause_url : '',
            ];
            $item['relationships']['field_orgs_their_story']['data'][$key]['status'] = $story_node->status->value;
          }

        }
      }

      if (!empty($item['relationships']['field_orgs_updates']['data'])) {
        foreach ($item['relationships']['field_orgs_updates']['data'] as $key => $update) {
          $story_update = Drupal::entityTypeManager()
            ->getStorage('node')
            ->loadByProperties(['uuid' => $update['id']]);
          $story_update = reset($story_update);
          if ($story_update) {
            $item['relationships']['field_orgs_updates']['data'][$key]['title'] = !empty($story_update->title->value) ? $story_update->title->value : '';
            $item['relationships']['field_orgs_updates']['data'][$key]['published_date'] = !empty($story_update->published_at->value) ? date('d M Y', $story_update->published_at->value) : '';
            $item['relationships']['field_orgs_updates']['data'][$key]['description'] = !empty($story_update->body->value) ? $story_update->body->value : '';
            $item['relationships']['field_orgs_updates']['data'][$key]['status'] = $story_update->status->value;
          }
        }
      }
    }
  }

  /**
   * Data @param $item .
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public static function customizeJsonResponseStory(&$item)
  {
    $etm = Drupal::entityTypeManager();

    if ($item['type'] == 'node--story') {
      $type = [
        '6' => 'substory',
        '5' => 'multimedia',
        '4' => 'vr',
        '3' => 'photo',
        '2' => 'text',
        '1' => 'video',
      ];
      if ($item['attributes']['field_story_format']) {
        foreach ($item['attributes']['field_story_format'] as $key => $s_type) {
          if (is_int($s_type) && isset($type[$s_type])) {
            $item['attributes']['field_story_format'][$key] = $type[$s_type];
          }
        }
      }

      $style1460x800 = ImageStyle::load('large_1400x800');
      if (!empty($item['relationships']['field_story_photo_gallery']['data'])) {
        // $para_photo_gallery = $etm->getStorage('paragraph')->loadByProperties(['uuid' => $item['relationships']['field_story_photo_gallery']['data']['id']]);.
        $para_photo_gallery = $etm->getStorage('paragraph')
          ->loadRevision($item['relationships']['field_story_photo_gallery']['data']['meta']['target_revision_id']);

        if ($para_photo_gallery) {
          if (!empty($para_photo_gallery->field_photo_gallery_image_list->getValue())) {
            $photo_gallery = [];
            foreach ($para_photo_gallery->field_photo_gallery_image_list->getValue() as $key => $photo) {
              $file = Drupal::entityTypeManager()
                ->getStorage('file')
                ->load($photo['target_id']);
              $file = reset($file);
              if ($file && !empty($file['uri']['x-default'])) {
                $image1460x800 = $style1460x800->buildUrl($file['uri']['x-default']);
                $photo_gallery[] = [
                  'url' => $image1460x800,
                  'title' => $photo['title'],
                  'alt' => $photo['alt'],
                ];
              }
            }
            $item['relationships']['field_story_photo_gallery']['data']['photo_gallery'] = $photo_gallery;
          }
        }
      }

      if (array_search('substory', $item['attributes']['field_story_format']) !== FALSE) {
        $nid = $item['attributes']['drupal_internal__nid'];
        $multimedia_node = self::loadMultimediaNode($nid);
        if ($multimedia_node) {
          self::customizeContributors($item['relationships']['field_contributors']['data'], $multimedia_node);
        } else {
          $item['relationships']['field_contributors']['data'] = [];
        }
      } else {
        // $contributors = [];.
        self::customizeContributors($item['relationships']['field_contributors']['data'], FALSE);
      }

      if (!empty($item['relationships']['field_story_thumbnail']['data'])) {
        $file = Drupal::entityTypeManager()
          ->getStorage('file')
          ->loadByProperties(['uuid' => $item['relationships']['field_story_thumbnail']['data']['id']]);
        $file = reset($file);
        if ($file && !empty($file->uri->value)) {
          $image1460x800 = $style1460x800->buildUrl($file->uri->value);
          $item['relationships']['field_story_thumbnail']['data']['url'] = $image1460x800;
        }
      }

      if (!empty($item['relationships']['field_story_feature_media']['data'])) {
        $embedded_media = Drupal::entityTypeManager()
          ->getStorage('media')
          ->loadByProperties(['uuid' => $item['relationships']['field_story_feature_media']['data']['id']]);
        $embedded_media = reset($embedded_media);
        if (!empty($embedded_media->field_media_video_embed_field->value)) {
          preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $embedded_media->field_media_video_embed_field->value, $match);
          $item['relationships']['field_story_feature_media']['data']['url_video'] = $embedded_media->field_media_video_embed_field->value;
          $item['relationships']['field_story_feature_media']['data']['id_video'] = $match[1];

        }
      }

      if (!empty($item['relationships']['field_story_call_to_actions']['data'])) {
        foreach ($item['relationships']['field_story_call_to_actions']['data'] as $key => $cta) {
          $cta_node = Drupal::entityTypeManager()
            ->getStorage('node')
            ->loadByProperties(['uuid' => $cta['id']]);
          $cta_node = reset($cta_node);
          if ($cta_node) {
            $cta_description = !empty($cta_node->field_cta_short_description->value) ? $cta_node->field_cta_short_description->value : '';
            if (!empty($cta_node->field_cta_image->getValue())) {
              $file = Drupal::entityTypeManager()
                ->getStorage('file')
                ->load($cta_node->field_cta_image->getValue()[0]['target_id']);
              $file = reset($file);
              if ($file && !empty($file['uri']['x-default'])) {
                $style180x180 = ImageStyle::load('thumbnail_180x180');
                $image180x180 = $style180x180->buildUrl($file['uri']['x-default']);
                $cta_image = [
                  'url' => $image180x180,
                  'title' => $cta_node->field_cta_image->getValue()[0]['title'],
                  'alt' => $cta_node->field_cta_image->getValue()[0]['alt'],
                ];
              }

            }
            if (!empty($cta_node->field_cta_link->getValue()) && !empty($cta_node->field_cta_link->getValue()[0])) {
              $cta_link = !empty($cta_node->field_cta_link->getValue()[0]['uri']) ? Url::fromUri($cta_node->field_cta_link->getValue()[0]['uri'], ['absolute' => TRUE])
                ->toString() : '';
              $cta_button = !empty($cta_node->field_cta_link->getValue()[0]['title']) ? $cta_node->field_cta_link->getValue()[0]['title'] : '';
              $cta_target = !empty($cta_node->field_cta_link->getValue()[0]['options']['attributes']) ? $cta_node->field_cta_link->getValue()[0]['options']['attributes']['target'] : '';
            }

            if (isset($cta_node->field_cta_form_detail) && !empty($cta_node->field_cta_form_detail->getValue())) {
              $url_get_form_elements = '/webform_rest/' . $cta_node->field_cta_form_detail->getValue()[0]['target_id'] . '/fields';
            } else {
              $url_get_form_elements = '';
            }

            $item['relationships']['field_story_call_to_actions']['data'][$key]['title'] = $cta_node->title->value;
            $item['relationships']['field_story_call_to_actions']['data'][$key]['cta_image'] = isset($cta_image) ? $cta_image : '';
            $item['relationships']['field_story_call_to_actions']['data'][$key]['short_description'] = $cta_description;
            $item['relationships']['field_story_call_to_actions']['data'][$key]['link'] = isset($cta_link) ? $cta_link : '';
            $item['relationships']['field_story_call_to_actions']['data'][$key]['url_get_form_elements'] = isset($url_get_form_elements) ? $url_get_form_elements : '';
            $item['relationships']['field_story_call_to_actions']['data'][$key]['button_name'] = isset($cta_button) ? $cta_button : '';
            $item['relationships']['field_story_call_to_actions']['data'][$key]['target'] = isset($cta_target) ? $cta_target : '';
            $item['relationships']['field_story_call_to_actions']['data'][$key]['status'] = $cta_node->status->value;
          }
        }
      }

      if (!empty($item['relationships']['field_story_full_page']['data'])) {
        $sections = [];
        foreach ($item['relationships']['field_story_full_page']['data'] as $sec) {
          $section = [];
          if (!empty($sec['id'])) {
            $section_para = $etm->getStorage('paragraph')
              ->loadByProperties(['uuid' => $sec['id']]);
            if ($section_para) {
              $section_para = reset($section_para);
              if (isset($section_para->field_para_section_id) && !empty($section_para->field_para_section_id->value)) {
                $section['section_id'] = $section_para->field_para_section_id->value;
              }

              if (isset($section_para->field_para_section_content) && !empty($section_para->field_para_section_content->value)) {
                $section['body'] = $section_para->field_para_section_content->value;
              }

              if (isset($section_para->field_para_section_slider) && !empty($section_para->field_para_section_slider->getValue())) {
                foreach ($section_para->field_para_section_slider->getValue() as $slider) {
                  $slider_para = $etm->getStorage('paragraph')
                    ->load($slider['target_id']);
                  if ($slider_para) {
                    if (isset($slider_para->field_para_slider_content) && !empty($slider_para->field_para_slider_content->value)) {
                      $section['sliders'][] = ['slider_body' => $slider_para->field_para_slider_content->value];
                    }
                  }
                }
              }

              if (isset($section_para->field_para_section_gallery) && !empty($section_para->field_para_section_gallery->getValue())) {
                $para_gallery = $etm->getStorage('paragraph')
                  ->load($section_para->field_para_section_gallery->target_id);
                $gallery = [];
                $gallery['gallery_id'] = (isset($para_gallery->field_photo_gallery_id) && !empty($para_gallery->field_photo_gallery_id->value)) ? $para_gallery->field_photo_gallery_id->value : '';
                $gallery['gallery_class'] = (isset($para_gallery->field_photo_gallery_class) && !empty($para_gallery->field_photo_gallery_class->value)) ? $para_gallery->field_photo_gallery_class->value : '';
                $gallery['gallery_photo'] = [];
                if (isset($para_gallery->field_photo_gallery_image_list) && !empty($para_gallery->field_photo_gallery_image_list->getValue())) {
                  foreach ($para_gallery->field_photo_gallery_image_list->getValue() as $photo) {
                    $photo_item = [];
                    $photo_item['alt'] = $photo['alt'];
                    $photo_item['title'] = $photo['title'];
                    $img = file_load($photo['target_id'])->getFileUri();
                    if ($img) {
                      $img_url = file_create_url($img);
                      $photo_item['photo'] = [
                        'small' => $img_url,
                        'medium' => $img_url,
                        'big' => $img_url,
                      ];
                    }

                    $gallery['gallery_photo'][] = $photo_item;
                  }
                }
                if (!empty($gallery)) {
                  $section['gallery'] = $gallery;
                }
              }

              $sections[] = $section;
            }
          }
        }

        if (!empty($sections)) {
          $item['relationships']['field_story_full_page']['data'] = $sections;
        }
      }
    }
  }

  /**
   * @param $elements
   * @param $alter_elements
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public static function customizeJsonResponseWebform($elements, &$alter_elements)
  {
    $etm = Drupal::entityTypeManager();
    foreach ($elements as $key => $element) {
      if (WebformElementHelper::isElement($element, $key)) {
        // dump($element['#type']);.
        switch ($element['#type']) {
          case 'webform_markup':
          case 'processed_text':
            $alter_element = [];
            foreach ($element as $sub_key => $item) {
              if (strpos($sub_key, '#') === 0) {
                $alter_element[substr($sub_key, 1)] = $item;
              } else {
                $alter_element[$sub_key] = $item;
              }
            }
            $alter_elements['markup'][] = ['key' => $key] + $alter_element;
            break;

          case 'textfield':
          case 'textarea':
          case 'select':
          case 'radios':
          case 'email':
          case 'tel':
          case 'checkbox':
          case 'checkboxes':
          case 'webform_checkboxes_other':
          case 'hidden':
          case 'value':
          case 'captcha':
          case 'webform_select_other':
          case 'webform_telephone':
            $alter_element = [];
            foreach ($element as $sub_key => $item) {
              if (strpos($sub_key, '#') === 0) {
                if ($sub_key == '#options') {
                  $alter_options = [];
                  foreach ($item as $option_key => $option_value) {
                    $obj_option = new \stdClass();
                    $obj_option->key = $option_key;
                    $obj_option->value = $option_value;
                    $alter_options[] = $obj_option;
                  }
                  $alter_element[substr($sub_key, 1)] = $alter_options;
                } else {
                  $alter_element[substr($sub_key, 1)] = $item;
                }
              } else {
                $alter_element[$sub_key] = $item;
              }
            }
            $alter_elements['fields'][] = ['key' => $key] + $alter_element;
            break;

          case 'webform_actions':
            $alter_element = [];
            foreach ($element as $sub_key => $item) {
              if (strpos($sub_key, '#') === 0) {
                $alter_element[substr($sub_key, 1)] = $item;
              } else {
                $alter_element[$sub_key] = $item;
              }
            }
            $alter_elements['actions'][] = ['key' => $key] + $alter_element;
            break;

          default:
            break;
        }
        APIListener::customizeJsonResponseWebform($element, $alter_elements);
      }
    }
    $webform = $etm->getStorage('webform')->load($alter_elements['webform_id']);
    if ($webform && $alter_elements['webform_id'] == $webform->id()) {
      $alter_elements['confirmation_message'] = [
        'title' => $webform->getSetting('confirmation_title'),
        'content' => $webform->getSetting('confirmation_message'),
      ];
    }
  }

  /**
   * @param $node_list
   * @param $alter_response
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public static function customizeJsonResponseMeetTheResidentsView($node_list, &$alter_response)
  {
    $etm = Drupal::entityTypeManager();
    $view = $etm->getStorage('view')->load($alter_response['view_id']);
    if ($view) {
      $metatags = self::getMetatagsForEntity($view);
      $alter_response['field_metatags'] = $metatags;

      $alter_response['action_status'] = [
        'post_data' => [
          'obj_url' => '/' . $view->get('display')['meet_the_residents_page']['display_options']['path'],
          'obj_title' => $view->get('label'),
          'obj_type' => 'view',
          'obj_subtype' => '',
          'obj_id' => $alter_response['view_id'],
        ],
        'share' => [
          'email' => [
            'webform_id' => 'share_email_meet_the_residents',
          ],
        ],
      ];
    }

    foreach ($node_list as $node) {
      $alias = explode('/', $node['path'][0]['alias']);

      $item = [
        'resident_title' => $node['title'][0]['value'],
        'resident_id' => $node['uuid'][0]['value'],
        'type' => $alias[1],
        'path' => $alias[2],
        'image_thumbnail' => [],
        'gif_thumbnail' => [],
      ];
      if (!empty($node['field_story_thumbnail'])) {
        // $media_entity = \Drupal::entityTypeManager()->getStorage('image')->load($node['field_story_thumbnail'][0]['target_id']);
        $photo = file_load($node['field_story_thumbnail'][0]['target_id']);
        if (!empty($photo->uri->value)) {
          $thumbnail = $photo->uri->value;
          $style420x280 = ImageStyle::load('medium_420x280');
          $image420x280 = $style420x280->buildUrl($thumbnail);
          $item['image_thumbnail'] = [
            'url' => $image420x280,
            'alt' => $node['field_story_thumbnail'][0]['alt'],
            'title' => $node['field_story_thumbnail'][0]['title'],
          ];
        }
      }
      if (!empty($node['field_story_gif_thumbnail'])) {
        $item['gif_thumbnail'] = [
          'url' => $node['field_story_gif_thumbnail'][0]['url'],
          'alt' => $node['field_story_gif_thumbnail'][0]['alt'],
          'title' => $node['field_story_gif_thumbnail'][0]['title'],
        ];
      }

      $alter_response['items'][] = $item;
    }
  }

  /**
   * @param $contributors
   * @param $multimedia_node
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public static function customizeContributors(&$contributors, $multimedia_node)
  {
    $etm = Drupal::entityTypeManager();
    if ($multimedia_node) {
      $count = count($multimedia_node->field_contributors);
      $contributors_multimedia_node = $multimedia_node->field_contributors->referencedEntities();
    } else {
      $count = count($contributors);
    }

    $contributor_names = $contributor_roles = [];

    // Todo: Need loading from system.
    $obw_roles = ['director', 'producer', 'writer', 'executive_produce'];
    $role_indexes = [];
    $terms = $etm->getStorage('taxonomy_term')
      ->loadByProperties(['vid' => 'personal_job_title']);

    if ($terms !== FALSE) {
      foreach ($terms as $item) {
        /** @var \Drupal\taxonomy\Entity\Term $item ; */
        $role_indexes[$item->getWeight()] = trim($item->getName());
      }
      ksort($role_indexes);
    }

    for ($i = 0; $i < $count; $i++) {

      /** @var \Drupal\paragraphs\Entity\Paragraph $paragraph ; */
      if (isset($contributors_multimedia_node)) {
        $paragraph = $contributors_multimedia_node[$i];
      } elseif (!$multimedia_node) {
        if (!empty($contributors[$i]['id'])) {
          $paragraph_uuid = $contributors[$i]['id'];
          $paragraph = $etm->getStorage('paragraph')
            ->loadByProperties(['uuid' => $paragraph_uuid]);
          if ($paragraph) {
            $paragraph = reset($paragraph);
          } else {
            continue;
          }
        }
      }

      if (isset($paragraph) && $paragraph->hasField('field_paragraph_user')) {

        $users = $paragraph->get('field_paragraph_user');
        $users = $users->referencedEntities();
        // Ignoring element when users empty.
        if (empty($users)) {
          continue;
        }

        /** @var \Drupal\user\Entity\User $user ; */
        $user = array_shift($users);
        $user_name = $user->getAccountName();
        $user_id = $user->id();
        $user_roles = $user->getRoles([
          RoleInterface::AUTHENTICATED_ID,
          RoleInterface::ANONYMOUS_ID,
        ]);

        // Add user belong to obw_roles to first positions.
        if (in_array($user_roles, $obw_roles)) {
          $contributor_names = [$user_id => $user_name] + $contributor_names;
        } else {
          $contributor_names[$user_id] = $user_name;
        }

        if ($paragraph->hasField('field_story_roles')) {

          $roles = $paragraph->get('field_story_roles');
          $roles = $roles->referencedEntities();
          foreach ($roles as $role) {

            /** @var \Drupal\taxonomy\Entity\Term $role ; */
            // Sort by roles name.
            $index = array_search(trim($role->getName()), $role_indexes);
            $contributor_roles[$user_id][$index] = trim($role->getName());
          }
          ksort($contributor_roles[$user_id]);
          $role_names = implode(', ', $contributor_roles[$user_id]);
          unset($contributor_roles[$user_id]);
          $contributor_roles[$user_id] = $role_names;
        }
      }// endforeach
    }

    // Group by userID.
    $temp = [];
    foreach ($contributor_names as $key => $value) {

      $current_user = User::load($key);
      $profile_type = 'public_profile';
      $entityTypeManager = Drupal::entityTypeManager();
      /**
       * @var $public_profile Profile
       */
      $profile_url = NULL;
      if ($current_user) {
        $public_profile = $entityTypeManager->getStorage('profile')
          ->loadByUser($current_user, $profile_type);

        if ($public_profile) {
          $profile_url = $public_profile->toUrl();
        }
      }

      $temp[$contributor_roles[$key]][] = [
        'uid' => $key,
        'profile_url' => $profile_url,
        'user_name' => $contributor_names[$key],
      ];
    }
    $contributor_roles = $temp;

    // dump($contributor_roles);
    // Sort desc roles.
    $roles_sorted = [];
    foreach ($contributor_roles as $key => $value) {

      $arrs = explode(', ', $key);
      $first = array_shift($arrs);
      $index = array_search(trim($first), $role_indexes);
      $count = count($arrs);

      // Replace last comma in string with “&”.
      $portion = strrchr($key, ',');
      $key = str_replace($portion, (" &" . substr($portion, 1, strlen($portion))), $key);
      $roles_sorted[$index][$count] = [$key => $value];
      krsort($roles_sorted[$index]);
    }
    ksort($roles_sorted);

    // dump($roles_sorted);
    $contributor_roles = [];
    foreach ($roles_sorted as $roles) {
      foreach ($roles as $item) {
        $contributor_roles += $item;
      }
    }

    $results = [];
    foreach ($contributor_roles as $key => $value) {
      $results[] = ['role' => $key, 'users' => $value];
    }
    if (!empty($results)) {
      $contributors = $results;
    }
  }

  /**
   * @param $nid_child
   *
   * @return bool|\Drupal\Core\Entity\EntityInterface|\Drupal\Core\Entity\EntityInterface[]|mixed
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public static function loadMultimediaNode($nid_child)
  {
    $etm = Drupal::entityTypeManager();
    $multimedia_node = $etm->getStorage('node')->loadByProperties(
      [
        'type' => 'story',
        'field_story_sub_stories' => $nid_child,
      ]
    );
    if ($multimedia_node) {
      $multimedia_node = reset($multimedia_node);
      return $multimedia_node;
    }
    return FALSE;
  }

  /**
   * @param $entity
   *
   * @return array
   */
  public static function getMetatagsForEntity($entity)
  {
    // $metatag_manager = \Drupal::service('metatag.manager');
    //    $metatags_for_entity = $metatag_manager->tagsFromEntityWithDefaults($entity);
    //    $tags = $metatag_manager->generateRawElements($metatags_for_entity, $entity);.
    $metatag_manager = Drupal::service('metatag.manager');
    $metatags = metatag_get_default_tags($entity);
    $context = [
      'entity' => $entity,
    ];
    Drupal::service('module_handler')->alter('metatags', $metatags, $context);
    $tags = $metatag_manager->generateRawElements($metatags, $entity);

    $alter_metatags = [];
    foreach ($tags as $k_1 => $tag) {
      foreach ($tag as $k_2 => $element) {
        $k_2 = str_replace('#', '', $k_2);
        $alter_metatags[$k_1][$k_2] = $element;
      }
    }

    $result = [];
    foreach ($alter_metatags as $item) {
      $result[] = $item;
    }

    return $result;
  }

  /**
   * Function customizeJsonResponseLoginViaEmail.
   *
   * @param $response
   */
  public static function customizeJsonResponseLoginViaEmail(&$response)
  {
    $alter_response = [];
    if (!empty($response['current_user']) && !empty($response['current_user']['uid'])) {
      $user = User::load($response['current_user']['uid']);
      if ($user) {
        $profile_picture = $user->get('user_picture')->entity->uri->value;
        if ($profile_picture) {
          $style48x48 = ImageStyle::load('thumbnail_48_48_');
          $photo_url = $style48x48->buildUrl($profile_picture);
        }

        $alter_response['uid'] = $response['current_user']['uid'];
        $alter_response['uuid'] = $user->uuid();
        $alter_response['name'] = $user->getAccountName();
        $alter_response['email'] = $user->getEmail();
        $alter_response['photoUrl'] = isset($photo_url) ? $photo_url : '';
        $alter_response['firstName'] = $user->get('field_account_first_name')
          ->first() ? $user->get('field_account_first_name')
          ->first()
          ->getValue()['value'] : '';
        $alter_response['lastName'] = $user->get('field_account_last_name')
          ->first() ? $user->get('field_account_last_name')
          ->first()
          ->getValue()['value'] : '';
        $alter_response['provider'] = 'OBW';
        $alter_response['csrf_token'] = $response['csrf_token'];
        $alter_response['logout_token'] = $response['logout_token'];
        $alter_response['coral_talk_config'] = self::getConfigurationOfCoralTalk();
        $alter_response['nationality'] = (!empty($user->field_account_nationality->value) && $user->field_account_nationality->value != '-1') ? $user->field_account_nationality->value : '';
        $alter_response['country'] = (!empty($user->field_account_residence->value) && $user->field_account_residence->value != '-1') ? $user->field_account_residence->value : '';

        $response = $alter_response;
      }
    }
  }

  /**
   *
   */
  public static function getConfigurationOfCoralTalk()
  {
    $coral_config = [];
    $config = Drupal::config('obw_talk_integration.config');
    $coral_config['jwt_audience'] = $config->get('OBW_TALK_JWT_AUDIENCE');
    $coral_config['jwt_issuer'] = $config->get('OBW_TALK_JWT_ISSUER');
    $coral_config['secret'] = $config->get('OBW_TALK_JWT_SECRET');
    $coral_config['coral_base_url'] = $config->get('OBW_TALK_JWT_ISSUER');
    return $coral_config;
  }

  /**
   * @param $field_tabs_content
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public static function loadTabsContent(&$field_tabs_content)
  {
    $etm = Drupal::entityTypeManager();
    $tabs_content = [];
    foreach ($field_tabs_content as $tab) {
      if (!empty($tab['id'])) {
        $tab_para = $etm->getStorage('paragraph')
          ->loadByProperties(['uuid' => $tab['id']]);
        if ($tab_para) {
          $tab_content = [
            'navigation_title' => '',
            'content_title' => '',
            'content' => '',
          ];
          $tab_para = reset($tab_para);
          if (isset($tab_para->field_para_tab_title) && !empty($tab_para->field_para_tab_title->value)) {
            $tab_content['navigation_title'] = $tab_para->field_para_tab_title->value;
          }

          if (isset($tab_para->field_para_body_title) && !empty($tab_para->field_para_body_title->value)) {
            $tab_content['content_title'] = $tab_para->field_para_body_title->value;
          }

          if (isset($tab_para->field_para_tab_body) && !empty($tab_para->field_para_tab_body->value)) {
            $tab_content['content'] = $tab_para->field_para_tab_body->value;
          }

          $tabs_content[] = $tab_content;
        }
      }
    }
    if (!empty($tabs_content)) {
      $field_tabs_content = $tabs_content;
    }
  }

  /**
   *
   */
  public static function shareViaEmail()
  {

  }

  /**
   * @param $data
   */
  public static function getResourcesUser(&$data)
  {
    if ($data['id'] && $data['roles']) {
      $user = User::load($data['id']);
      $data['uuid'] = $user->uuid();
      $data['email'] = $user->getEmail();
      $data['roles'] = $user->getRoles();
      $data['username'] = $user->getDisplayName();
      $data['firstName'] = isset($user->get('field_account_first_name')
          ->getValue()[0]['value']) ? $user->get('field_account_first_name')
        ->getValue()[0]['value'] : "";
      $data['lastName'] = isset($user->get('field_account_last_name')
          ->getValue()[0]['value']) ? $user->get('field_account_last_name')
        ->getValue()[0]['value'] : "";
      $data['picture'] = '';
      $data['nationality'] = isset($user->get('field_account_nationality')
          ->getValue()[0]['value']) ? $user->get('field_account_nationality')
        ->getValue()[0]['value'] : "";

      $data['country'] = isset($user->get('field_account_residence')
          ->getValue()[0]['value']) ? self::convertCountryNameToCountryCode($user->get('field_account_residence')
        ->getValue()[0]['value']) : "";

      if (!empty($user->get('user_picture')
          ->getValue()) && !empty($user->get('user_picture')
          ->getValue()[0]['target_id'])) {
        $fid = $user->get('user_picture')->getValue()[0]['target_id'];
        $file = \Drupal\file\Entity\File::load($fid);
        $data['picture'] = ($file) ? file_create_url($file->getFileUri()) : '';
      }
      $action_service = Drupal::service('action_entity.action_service');
      $data = array_merge($data, $action_service->loadBookmarkListByUID($data['id']));
    }
  }

  public static function addPublicProfileForUser(&$users)
  {
    global $base_url;
    foreach ($users as $key => $user) {
      if (!empty($user['uid'])) {
        $current_user = User::load($user['uid']);
        $profile_type = 'public_profile';
        $entityTypeManager = Drupal::entityTypeManager();
        /**
         * @var $public_profile Profile
         */
        $profile_url = NULL;
        if ($current_user) {
          $public_profile = $entityTypeManager->getStorage('profile')
            ->loadByUser($current_user, $profile_type);

          if ($public_profile) {
            $profile_url = $base_url . $public_profile->toUrl()->toString();
          }
        }
        $user['profile_url'] = $profile_url;
        $users[$key] = $user;
      }
    }
  }

  public static function convertCountryNameToCountryCode($countryName)
  {
    $country_options = WebformOptions::load('country_codes_2')->getOptions();
    $countryCode = '';

    if (!empty($country_options)) {
      foreach ($country_options as $index => $val) {
        if ($val == $countryName) {
          $countryCode = $index;
        }
      }
    }

    return $countryCode;
  }

}
