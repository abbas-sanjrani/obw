<?php
/**
 * @file
 * Contains \Drupal\obw_api\Routing\RouteSubscriber.
 */

// THIS FILE BELONGS AT /example_module/src/Routing/RouteSubscriber.php

namespace Drupal\obw_api\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Listens to the dynamic route events.
 */
class RouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   */
  public function alterRoutes(RouteCollection $collection) {
    // Replace "some.route.name" below with the actual route you want to override.
    if ($route = $collection->get('user.logout.http')) {
      $route->setDefaults(array(
        '_controller' => '\Drupal\obw_api\Controller\APIController::logout',
      ));
    }

    if ($route = $collection->get('user.pass.http')) {
      $route->setDefaults(array(
        '_controller' => '\Drupal\obw_api\Controller\CustomUserAuthenticationController::resetPassword',
      ));
    }
  }
}