<?php

namespace Drupal\obw_api\Controller;

use Drupal;
use Drupal\Core\Access\CsrfTokenGenerator;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Flood\FloodInterface;
use Drupal\Core\Routing\RouteProviderInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\user\UserAuthInterface;
use Drupal\user\UserInterface;
use Drupal\user\UserStorageInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Serializer;
use Drupal\user\Controller\UserAuthenticationController;

/**
 * Provides controllers for login, login status and logout via HTTP requests.
 */
class CustomUserAuthenticationController extends UserAuthenticationController {

  /**
   * Resets a user password.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The request.
   *
   * @return \Symfony\Component\HttpFoundation\Response
   *   The response object.
   */
  public function resetPassword(Request $request) {
    $format = $this->getRequestFormat($request);

    $content = $request->getContent();
    $credentials = $this->serializer->decode($content, $format);

    // Check if a name or mail is provided.
    if (!isset($credentials['name']) && !isset($credentials['mail'])) {
      throw new BadRequestHttpException('Missing credentials.name or credentials.mail');
    }

    // Load by name if provided.
    if (isset($credentials['name'])) {
      $data_request = $credentials['name'];
      $users = $this->userStorage->loadByProperties(['name' => trim($credentials['name'])]);
    }
    elseif (isset($credentials['mail'])) {
      $data_request = $credentials['mail'];
      $users = $this->userStorage->loadByProperties(['mail' => trim($credentials['mail'])]);
    }

    /** @var AccountInterface $account */
    $account = reset($users);
    if ($account && $account->id()) {
      if ($this->userIsBlocked($account->getAccountName())) {
        throw new BadRequestHttpException($data_request . ' is blocked or has not been activated yet.');
      }
      if(!empty($credentials['current_url'])) {
        $session_handler = Drupal::service('obw_social.session_handler');
        $session_handler->set('redirect_to_fe', $credentials['current_url']);
      }

      // Send the password reset email.
      $mail = _user_mail_notify('password_reset', $account, $account->getPreferredLangcode());
      if (empty($mail)) {
        $session_handler->clear('redirect_to_fe');
        throw new BadRequestHttpException('Unable to send email. Contact the site administrator if the problem persists.');
      }
      else {
        $this->logger->notice('Password reset instructions mailed to %name at %email.', ['%name' => $account->getAccountName(), '%email' => $account->getEmail()]);
        $response = new JsonResponse([
          'status' => true,
          'title' => 'Email sent!',
          'message' => 'Instructions to reset your password have been emailed to you. Please check your email.'
        ]);
        return $response;
      }
    }

    // Error if no users found with provided name or mail.
    throw new BadRequestHttpException($data_request . ' is not recognized as a username or an email address.');
  }

}
