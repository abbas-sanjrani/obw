<?php

namespace Drupal\obw_api\Controller;

use Drupal\node\NodeInterface;
use Drupal\Component\Serialization\Json;
use Drupal\Core\Cache\CacheableJsonResponse;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\image\Entity\ImageStyle;
use Drupal\node\Entity\Node;
use Drupal\obw_campaign\Theme\LandingPreprocessNodeManager;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\user\Entity\User;
use Drupal\webform\Entity\Webform;
use Drupal\webform\Entity\WebformSubmission;
use Drupal\webform\WebformSubmissionForm;
use Stripe\Customer;
use Stripe\Stripe;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Render\RenderContext;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\obw_action_entity\Controller\ActionEntityController;
use Symfony\Component\HttpFoundation\Request;
use Drupal\obw_contributor_profile\Controller\ActiveCampaignController;

/**
 * Class CustomRestController.
 */
class APIController extends ControllerBase {

  /**
   *
   */
  public function getStory($node_type = NULL, $node_title = NULL) {
    $request = \Drupal::request();
    $response_array = [];
    if ($node_type && $node_type == 'story') {
      $path = \Drupal::service('path_alias.manager')
        ->getPathByAlias('/' . $node_type . '/' . $node_title);
    }
    else {
      $path = \Drupal::service('path_alias.manager')
        ->getPathByAlias('/' . $node_title);
    }
    if (preg_match('/node\/(\d+)/', $path, $matches)) {

      $node = Node::load($matches[1]);
      if ($node) {
        // Retrieve JSON API representation of this node.
        //        $normalized = \Drupal::service('jsonapi_extras.entity.to_jsonapi')->normalize($node);
        //
        $serialize = \Drupal::service('jsonapi_extras.entity.to_jsonapi')
          ->serialize($node);
        $response_array = JSON::decode($serialize);

        $context = new RenderContext();
        /** @var CacheableDependencyInterface $result */
        $data = \Drupal::service('renderer')
          ->executeInRenderContext($context, function () use ($request, $node) {
            // do_things() triggers the code that we don't don't control that in turn triggers early rendering.
            return $this->addPropertiesForJsonResponse($request->query->all(), $node);
          });
        // Handle any bubbled cacheability metadata.
        if (!$context->isEmpty()) {
          $bubbleable_metadata = $context->pop();
          BubbleableMetadata::createFromObject($data)
            ->merge($bubbleable_metadata);
        }

        $response_array['data']['attributes']['action_status'] = $data['action_status'];
        $response_array['data']['attributes']['field_metatags'] = $data['metatags'];

      }
    }

    if (empty($response_array)) {
      $response = new JsonResponse(['status' => 'Not found']);
      $response->setStatusCode(404);
    }
    else {
      // // Add the node_list cache tag so the endpoint results will update when nodes are updated.
      //      $cache_metadata = new CacheableMetadata();
      //      $cache_metadata->setCacheTags(['node_list']);
      // Create the JSON response object.
      $response = new JsonResponse($response_array);
      $response->setStatusCode(200);
    }

    return $response;
  }

  /**
   *
   */
  public function addPropertiesForJsonResponse($request_param, $node) {
    $result = [];
    $metatags = $this->getMetatagsForNode($node);
    $action_status = $this->loadActionStatus($request_param, $node);
    $result = [
      'metatags' => $metatags,
      'action_status' => $action_status,
    ];
    return $result;
  }

  /**
   *
   */
  public function getMetatagsForNode($node) {
    $metatag_manager = \Drupal::service('metatag.manager');
    $metatags_for_entity = $metatag_manager->tagsFromEntityWithDefaults($node);
    $tags = $metatag_manager->generateRawElements($metatags_for_entity, $node);
    $alter_metatags = [];
    foreach ($tags as $k_1 => $tag) {
      foreach ($tag as $k_2 => $element) {
        $k_2 = str_replace('#', '', $k_2);
        $alter_metatags[$k_1][$k_2] = $element;
      }
    }

    $result = [];
    foreach ($alter_metatags as $item) {
      $result[] = $item;
    }

    return $result;
  }

  /**
   *
   */
  public function logout() {
    $user = \Drupal::currentUser();
    \Drupal::logger('logout_multi_sites')
      ->info('The uid ' . $user->id() . ' is logging out.');
    $obw_api_service = \Drupal::service('obw_api.obw_api_service');
    $response = $obw_api_service->logout($user);
    return $response;
  }

  /**
   *
   */
  public function loadActionStatus($request_param, $node) {
    $action_controller = new ActionEntityController();
    $uid = 'anonymous';
    if (!empty($request_param['uid'])) {
      $uid = $request_param['uid'];
    }

    $params = [
      'user_id' => $uid,
      'obj_url' => $node->toURL()->toString(),
      'obj_id' => $node->id(),
    ];

    $status_like = $action_controller->isUserActed($params, 'like');
    $status_follow = $action_controller->isUserActed($params, 'follow');
    $status_share = $action_controller->getAmoutOfClick($params);
    $share_mail_webform = 'email_a_friend';

    if ($node->toURL()->toString() == '/crt-impact') {
      $share_mail_webform = 'share_email_about_crt';
    }

    $action_status = [
      'post_data' => [
        'obj_url' => $node->toURL()->toString(),
        'obj_title' => $node->getTitle(),
        'obj_type' => 'node',
        'obj_subtype' => $node->getType(),
        'obj_id' => $node->id(),
      ],
      'like' => [
        'is_acted' => !empty($status_like['is_acted']) ? $status_like['is_acted'] : FALSE,
        'total' => !empty($status_like['total']) ? $status_like['total'] : '0',
      ],
      'follow' => [
        'is_acted' => !empty($status_follow['is_acted']) ? $status_follow['is_acted'] : FALSE,
        'total' => !empty($status_follow['total']) ? $status_follow['total'] : '0',
      ],
      'share' => [
        'total' => !empty($status_share['total']) ? $status_share['total'] : '0',
        'email' => [
          'webform_id' => $share_mail_webform,
        ],
      ],
    ];

    return $action_status;
  }

  /**
   *
   */
  public function checkEmail(Request $request) {
    $response = [
      'data' => [],
    ];
    $body = JSON::decode($request->getContent());
    if (!empty($body) && !empty($body['email']) && !empty($body['webform_id']) && !empty($body['data_submit']) && !empty($body['nid'])) {
      $obw_api_service = \Drupal::service('obw_api.obw_api_service');

      $sids = $obw_api_service->loadSIDByEmail($body['email'], $body['webform_id']);
      if ($sids) {
        $response['data']['action'] = 'registered_event';
      } else {
        $response['data']['action'] = 'registering_event';
      }
    }
    else {
      $response['data']['msg'] = 'Missing the data. Pls provide the webform_id and email';
    }
    $response_json = new JsonResponse($response, 200);
    return $response_json;
  }

  /**
   *
   */
  public function syncACTag(Request $request) {
    $response_array = [
      'status' => 200,
      'msg' => 'Sync tags to AC fail!',
    ];
    $body = Json::decode($request->getContent());

    if (!empty($body['email']) && !empty($body['ac_tags'])) {
      $config = \Drupal::config('obw_contributor_profile.config');
      $api_key = $config->get('AC_API_KEY');
      $params = [
        'api_key' => $api_key,
        'api_action' => 'contact_sync',
        'api_output' => 'serialize',
      ];
      $post_data = [
        'email' => $body['email'],
        'first_name' => !empty($body['first_name']) ? $body['first_name'] : '',
        'last_name' => !empty($body['last_name']) ? $body['last_name'] : '',
      ];

      $ac_controller = new ActiveCampaignController();
      // Create profile in the AC.
      $res_create_ac_profile = $ac_controller->requestServerActiveCampaign($params, $post_data);
      if (!empty($res_create_ac_profile['result_code']) && $res_create_ac_profile['result_code'] == 1) {
        // Sync tags to AC.
        $ac_sync_tags = $ac_controller->addTagToACContact($body['email'], $body['ac_tags']);
        if (!empty($ac_sync_tags) && $ac_sync_tags['result_code'] == 1) {
          $response_array['msg'] = 'Sync tags to AC successful!';
        }
        else {
          $response_array['msg'] = 'Sync tags to AC fail!';
        }
      }
    }
    else {
      $response_array['msg'] = 'Missing email or ac_tags';
    }

    $response = new JsonResponse($response_array);
    $response->setStatusCode(200);

    return $response;
  }

  /**
   *
   */
  public function cancelSubscriptionMonthly() {
    $response_array = [
      'status' => 200,
      'success' => FALSE,
      'msg' => '',
    ];
    $current_user = \Drupal::currentUser();
    if ($current_user->isAuthenticated()) {
      if (!empty($current_user->getEmail())) {
        $config = \Drupal::config('stripe.settings');
        $private_key = $config->get('apikey.' . $config->get('environment') . '.secret');
        Stripe::setApiKey($private_key);
        $customers = Customer::all(['email' => $current_user->getEmail()]);
        if (!empty($customers)) {
          $values = $customers->values();
          if (!empty($values[1][0])) {
            $customer = $values[1][0];
            if (!empty($customer->subscriptions) && !empty($customer->subscriptions->data)) {
              $subscription = $customer->cancelSubscription();
              $ac_controller = new ActiveCampaignController();
              $ac_sync_tags = $ac_controller->addTagToACContact($current_user->getEmail(), ['OBWACTION: Donate (Former Recurring)']);
              if ($ac_sync_tags['result_code'] == 1) {
                \Drupal::logger('cancel_donation_monthly')
                  ->info('Synced OBWACTION: Donate (Former Recurring) tag to AC');
              }
              else {
                \Drupal::logger('cancel_donation_monthly')
                  ->info('Sync OBWACTION: Donate (Former Recurring) tag to AC fail');
              }
              $query = \Drupal::service('obw_utilities.entity_query');
              $sids = $query->getSubmissionMonthlyIDByEmailInSupportUs($current_user->getEmail());
              if (!empty($sids)) {
                $sids_array = [];
                foreach ($sids as $sid) {
                  $sids_array[] = $sid->sid;
                }
                $submissions = WebformSubmission::loadMultiple($sids_array);
                foreach ($submissions as $submission) {
                  $ws_data = $submission->getData();
                  $ws_data['payment_status'] = 'Cancelled';
                  $submission->setData($ws_data);
                  $submission->save();
                }
              }
              $response_array = [
                'status' => 200,
                'success' => TRUE,
                'msg' => 'Your donation has been cancelled.',
              ];
            }
            else {
              \Drupal::logger('cancel_donation_monthly')
                ->info('cancel unsuccess: ' . json_encode($customer));
              $response_array['msg'] = 'You haven\'t donated monthly yet!';
            }
          }
          else {
            $response_array['msg'] = 'Can not found customer in Stripe based on your email';
          }
        }
        else {
          $response_array['msg'] = 'Can not found customer in Stripe based on your email';
        }
      }
      else {
        $response_array['msg'] = 'Missing email.';
      }
    }
    else {
      $response_array = [
        'status' => 403,
        'success' => FALSE,
        'msg' => 'Please login to perform this action',
      ];
    }

    $response = new JsonResponse($response_array);
    $response->setStatusCode($response_array['status']);

    return $response;
  }

  /**
   *
   */
  public function loadUserByMail(Request $request) {
    $result = [
      'uid' => NULL,
    ];

    $body = Json::decode($request->getContent());
    if (!empty($body['email'])) {
      $user = user_load_by_mail($body['email']);
      if (!$user) {
        $response = new JsonResponse($result);
        return $response;
      }

      $result = [
        'uid' => $user->id(),
      ];
    }
    $response = new JsonResponse($result);

    return $response;
  }

  /**
   *
   */
  public function getRegionsInfo() {
    $respond['data'] = [];
    $respond['suggested_countries'] = [];
    $response = [
      'id' => '',
      'name' => '',
      'ioc' => '',
      'is_country' => FALSE,
      'animals' => [],
    ];

    $params = ['type' => 'region', 'status' => 1];
    /** @var \Drupal\Core\Entity\EntityTypeManagerInterface $etm */
    $etm = \Drupal::entityTypeManager();
    /** @var \Drupal\Core\Entity\EntityStorageInterface $regions */
    $regions = $etm->getStorage('node')->loadByProperties($params);
    $wl_suggested_countries_config = \Drupal::config('obw_utilities.wl_suggested_countries.config');
    $wl_suggested_arr = [];
    if (!empty($wl_suggested_countries_config->get('WL_SUGGESTED_COUNTRIES'))) {
      $wl_suggested_arr = array_column($wl_suggested_countries_config->get('WL_SUGGESTED_COUNTRIES'), 'target_id');
    }
    if (!empty($regions)) {

      foreach ($regions as $region) {
        /** If exists $region */
        if (!empty($region)) {
          $response['id'] = $region->id();
          $response['name'] = $region->label();
        }
        /** If exists field_regoin_is_country */
        if (!empty($region->get('field_regoin_is_country')->value)) {
          $response['is_country'] = TRUE;
        }
        else {
          $response['is_country'] = FALSE;
        }
        /** If exists field_region_country */
        if (!empty($region->get('field_region_country')->getString())) {
          $response['ioc'] = $region->get('field_region_country')->getString();
        }
        if (in_array($response['id'], $wl_suggested_arr) !== FALSE) {
          $tmp = $response;
          unset($tmp['animals']);
          $respond['suggested_countries'][] = $tmp;
        }
        /** If exists field_region_list_animals */
        if (!empty($region->get('field_region_list_animals')->getString())) {
          $list_animals = explode(",", $region->get('field_region_list_animals')
            ->getString());
          /** @var \Drupal\node\Entity\Node $animals */
          $animals = Node::loadMultiple($list_animals);
          $response['animals'] = [];
          foreach ($animals as $animal) {
            /** If is published */
            if ($animal->status->value === '1') {
              if (!empty($animal->get('field_animal_icon')->entity)) {
                $path = $animal->get('field_animal_icon')->entity->uri->value;
                /** @var \Drupal\image\Entity\ImageStyle $iconUrl */
                $iconUrl = ImageStyle::load('thumbnail')->buildUrl($path);
              }

              $response['animals'][] = [
                'name' => $animal->label(),
                'id' => $animal->id(),
                'iconUrl' => isset($iconUrl) ? $iconUrl : '',
                'IUCNRedListStatusID' => (isset($animal->field_animal_iucn_list_status) && !empty($animal->get('field_animal_iucn_list_status')->entity)) ? $animal->get('field_animal_iucn_list_status')->entity->id() : '',
                'animalLevel' => !empty($animal->field_animal_level->target_id) ? $animal->field_animal_level->target_id : '',
                'theme' => $this->getAnimalTheme($animal),
              ];
            }
          }
        }
        $respond['data'][] = $response;
      }
    }
    $respond['time'] = time();
    $respond['#cache'] = [
      'max-age' => 43200,
    ];
    $responseJson = new CacheableJsonResponse($respond);
    $responseJson->addCacheableDependency(CacheableMetadata::createFromRenderArray($respond));
    return $responseJson;
  }

  /**
   *
   */
  public function getRegionDetailInfo($region_id = NULL) {
    $respond['data'] = [];
    $response = [
      'id' => '',
      'name' => '',
      'ioc' => '',
      'is_country' => FALSE,
      'animals' => [],
    ];

    /** @var  \Drupal\node\Entity\Node $region */
    $region = Node::load($region_id);
    if (!empty($region) && $region->bundle() == 'region') {

      /** If exists $region */
      if (!empty($region)) {
        $response['id'] = $region->id();
        $response['name'] = $region->label();
      }
      /** If exists field_regoin_is_country */
      if (!empty($region->get('field_regoin_is_country')->value)) {
        $response['is_country'] = TRUE;
      }
      else {
        $response['is_country'] = FALSE;
      }

      /** If exists field_region_country */
      if (!empty($region->get('field_region_country')->getString())) {
        /** @var \Drupal\Core\Field\FieldDefinitionInterface $identify_country */
        $response['ioc'] = $region->get('field_region_country')->getString();
      }

      if (!empty($region->get('field_region_list_animals')->getString())) {
        $response['animals'] = [];
        $list_animals = explode(",", $region->get('field_region_list_animals')
          ->getString());
        /** @var \Drupal\node\Entity\Node $animals */
        $animals = Node::loadMultiple($list_animals);
        foreach ($animals as $animal) {
          if ($animal->status->value === '1') {
            if (isset($animal->field_animal_icon) && !empty($animal->get('field_animal_icon')->entity)) {
              $path = $animal->get('field_animal_icon')->entity->uri->value;
              /** @var \Drupal\image\Entity\ImageStyle $iconUrl */
              $iconUrl = ImageStyle::load('thumbnail')->buildUrl($path);
              $response['animals'][] = [
                'name' => $animal->label(),
                'id' => $animal->id(),
                'iconUrl' => $iconUrl,
              ];
            }
            else {
              $response['animals'][] = [
                'name' => $animal->label(),
                'id' => $animal->id(),
                'iconUrl' => '',
              ];
            }
          }

        }
      }

      $respond['data'][] = $response;
      $response = new JsonResponse($respond);
      $response->setStatusCode(200);
      return $response;

    }
    else {
      $respond['data']['message'] = 'Data Not Found';
      $response = new JsonResponse($respond);
      $response->setStatusCode(404);
      return $response;
    }
  }

  /**
   *
   */
  public function getAnimalInfo($animal_id = NULL) {
    /** @var \Drupal\node\Entity\Node $animal */
    $animal = Node::load($animal_id);

    if (!empty($animal) && $animal->bundle() == 'animals') {

      /** @var \Drupal\Core\Field\FieldDefinitionInterface $path */
      $category = $animal->get('field_animal_category')->entity->label();

      /** @var \Drupal\Core\Field\FieldDefinitionInterface $IUCNRedListStatus */
      $IUCNRedListStatus = $animal->get('field_animal_iucn_list_status')->entity->id();

      /** @var \Drupal\Core\Field\FieldDefinitionInterface $population */
      $population = $animal->get('field_animal_population')->getString();

      if (count($animal->get('field_animal_type_of_threat')->getValue()) > 1) {
        $type_of_threat = $animal->get('field_animal_type_of_threat');
        foreach ($type_of_threat as $item) {
          $threats[] = [
            'name' => $item->entity->label(),
          ];
        }
      }
      else {
        /** @var \Drupal\Core\Field\FieldDefinitionInterface $threats */
        $threats = $animal->get('field_animal_type_of_threat')->entity->label();
      }

      if (!empty($animal->get('field_animal_icon')->entity)) {
        /** @var \Drupal\Core\Field\FieldDefinitionInterface $icon_path */
        $icon_path = $animal->get('field_animal_icon')->entity->uri->value;
        /** @var \Drupal\image\Entity\ImageStyle $iconUrl */
        $iconUrl = ImageStyle::load('thumbnail')->buildUrl($icon_path);
      }

      if (!empty($animal->get('field_animal_image')->entity)) {
        /** @var \Drupal\Core\Field\FieldDefinitionInterface $image_path */
        $image_path = $animal->get('field_animal_image')->entity->uri->value;

        /** @var \Drupal\image\Entity\ImageStyle $iconUrl */
        $imageUrl = ImageStyle::load('banner_gsoty_720x400')
          ->buildUrl($image_path);
      }

      /** @var \Drupal\Core\Field\FieldDefinitionInterface $story_id */
      $story_id = $animal->get('field_animal_story')->getString();
      if (!empty($story_id)) {
        /** @var \Drupal\Core\Url $url */
        $url = Url::fromRoute(
          'entity.node.canonical',
          ['node' => $story_id],
          ['absolute' => TRUE]
        );
        $story_link = $url->toString();
      }
      else {
        $story_link = '';
      }

      /** @var \Drupal\Core\Field\FieldDefinitionInterface $photoCredit */
      $photoCredit = $animal->get('field_animal_photo_credit')->getString();

      /** @var \Drupal\Core\Field\FieldDefinitionInterface $sources */
      if (isset($animal->field_animal_sources) && !empty($animal->get('field_animal_sources')
          ->getValue())) {
        $sources = $animal->get('field_animal_sources')->getValue()[0]['value'];
      }

      if (isset($animal->field_animal_level) && !empty($animal->get('field_animal_level')
          ->target_id)) {
        $animal_level = $animal->get('field_animal_level')->target_id;
      }

      /** @var \Drupal\Core\Field\FieldDefinitionInterface $factoid */
      $factoid = $animal->get('field_animal_factoid')->getString();
      $conservation_groups = [];
      foreach ($animal->get('field_revised_animal_cards')
                 ->getValue() as $key_card => $card) {
        $p_data_1 = array_column(Paragraph::load($card['target_id'])->get('field_name_of_organisation')->getValue(), 'value');
        $p_data_2 = array_column(Paragraph::load($card['target_id'])->get('field_market_that_this_organisat')->getValue(), 'value');
        $p_data_3 = array_column(Paragraph::load($card['target_id'])->get('field_animal_action_button')->getValue(), 'value');
        $conservation_groups[$key_card]['field_name_of_organisation'] = reset($p_data_1);
        $conservation_groups[$key_card]['field_market_that_this_organisat'] = reset($p_data_2);
        $conservation_groups[$key_card]['field_animal_action_button'] = reset($p_data_3);
      }

      $response = [
        'id' => $animal->id(),
        'subSpecies' => $animal->label(),
        'category' => !empty($category) ? $category : '',
        'animalLevel' => !empty($animal_level) ? $animal_level : '',
        'IUCNRedListStatusID' => !empty($IUCNRedListStatus) ? $IUCNRedListStatus : '',
        'theme' => $this->getAnimalTheme($animal),
        'population' => !empty($population) ? $population : '',
        'threats' => !empty($threats) ? $threats : '',
        'iconUrl' => !empty($iconUrl) ? $iconUrl : '',
        'imageUrl' => !empty($imageUrl) ? $imageUrl : '',
        'factoid' => !empty($factoid) ? $factoid : '',
        'story_link' => $story_link,
        'photoCredit' => !empty($photoCredit) ? $photoCredit : '',
        'sources' => isset($sources) ? $sources : '',
        'conservationGroups' => $conservation_groups,
      ];

      $response = new JsonResponse($response);
      $response->setStatusCode(200);
      return $response;

    }
    else {
      $response['data']['message'] = 'Data Not Found';
      $response = new JsonResponse($response);
      $response->setStatusCode(404);
      return $response;
    }
  }

  /**
   *
   */
  public function getCategoryIUCNListStatus() {
    $response = [];

    foreach ($this->loadTermByTaxonomyId('iucn_red_list_status') as $term) {
      /** @var \Drupal\Core\Field\FieldDefinitionInterface $color */
      $color = $term->get('field_iucn_color')->getString();
      $name = $term->get('description')->value;
      $level = 1;

      if (strpos($term->getName(), 'extremely high risk') !== FALSE) {
        $level = 3;
      }
      elseif (strpos($term->getName(), 'very high risk') !== FALSE) {
        $level = 2;
      }

      $response[] = [
        'id' => $term->id(),
        'name' => !empty($name) ? strip_tags($name, '<br>') : '',
        'color' => !empty($color) ? $color : '',
        'level' => $level,
      ];
    }

    usort($response, function($a, $b) {
      return $a['level'] < $b['level'];
    });

    $response = new JsonResponse($response);
    $response->setStatusCode(200);
    return $response;
  }

  /**
   *
   */
  public function getWlThemes() {
    $wl_themes = [];
    foreach ($this->loadTermByTaxonomyId('animal_theme_map') as $term) {
      $theme_item = [
        'id' => $term->id(),
        'name' => $term->getName(),
      ];
      $wl_themes[] = $theme_item;
    }

    $response = new JsonResponse($wl_themes);
    $response->setStatusCode(200);
    return $response;
  }

  /**
   *
   */
  public function updateSubmission() {
    $request = \Drupal::request();
    $request_data = Json::decode($request->getContent());
    $status['status'] = FALSE;
    $status['message'] = 'Update submission failed';

    $uid = \Drupal::currentUser()->id();
    if ($request_data['sid'] && $request_data['status']) {
      $action_status = $this->updateDataSubmission($request_data, $uid);
      if ($action_status) {
        $status['status'] = TRUE;
        $status['message'] = 'Update submission successful';
      }
    }
    else {
      \Drupal::logger('obw_api')->info("updateSubmission.
       Data: \"" . $request->getContent() . "\" not suitable.");
    }
    $response = new JsonResponse($status);
    $response->setStatusCode(200);
    return $response;
  }

  /**
   *
   */
  public function updateDataSubmission($data, $uid) {
    try {
      $sid = $data['sid'];
      $webform_submission = WebformSubmission::load($sid);
      $submisson_data = $webform_submission->getData();
      $user_roles = User::load($uid)->getRoles();
      if (in_array('data_team', $user_roles)
        || in_array('administrator', $user_roles)) {
        $submisson_data['status'] = $data['status'];
        $webform_submission->setData($submisson_data);
        $webform_submission->save();
        return TRUE;
      }
      else {
        \Drupal::logger('obw_api')
          ->warning("User uid: $uid do not have permission update submission $sid");
        return FALSE;
      }
    } catch (\Exception $ex) {
      \Drupal::logger('obw_api')->error("Update submission $sid failed.
       Erorr: " . $ex->getMessage());
    }
  }

  /**
   *
   */
  public function countDownloadPDF($nid) {
    $data_res = ['msg' => '', 'success' => TRUE];
    if (!empty($nid)) {
      $etm = \Drupal::entityTypeManager();
      $node = $etm->getStorage('node')->load($nid);
      if (!empty($node)) {
        if ($node->hasField('field_pdf_number_downloads')) {
          $count_download = (int) $node->get('field_pdf_number_downloads')
            ->getString();
          $node->set('field_pdf_number_downloads', ++$count_download);
          $node->save();
          $data_res['msg'] = 'Updated field_pdf_number_downloads to ' . $count_download;
        }

        if (isset($node->field_pdf_webform) && !empty($node->field_pdf_webform->value)) {
          $current_user = \Drupal::currentUser();
          $current_email = $current_user->getEmail();
          if ($node->hasField('field_pdf_wf_show_on_page') && !empty($node->field_pdf_wf_show_on_page->value)) {
            if (!empty($_COOKIE['wl2021_' . $node->field_pdf_wf_show_on_page->value . '_email'])) {
              $current_email = $_COOKIE['wl2021_' . $node->field_pdf_wf_show_on_page->value . '_email'];
            }
          }
          $ip_address = \Drupal::request()->getClientIp();
          $webform_id = $node->hasField('field_pdf_webform') ? $node->field_pdf_webform->value : NULL;
          switch ($webform_id) {
            case 'tracking_wl2021_pdf_download':
            case 'tracking_pdf_download':
              /** Create Tracking PDF Download Webform submission */
              $request_data = Json::decode(\Drupal::request()->getContent());
              if (isset($_COOKIE['download_creature_reuse'])) {
                $current_email = $_COOKIE['download_creature_reuse'];
              }
              $res = $this->checkExistsEmailAndNode($current_email, $nid, $webform_id, $request_data);
              if ($res['status']) {
                $webform_submission_id = $res['webform_submission_id'];
                // Check webform is open.
                $webform = Webform::load($webform_id);
                $is_open = WebformSubmissionForm::isOpen($webform);
                if ($is_open === TRUE) {
                  // Load submission.
                  $webform_submission = WebformSubmission::load($webform_submission_id);
                  $number_of_downloads = $res['number_of_downloads'] + 1;
                  $webform_submission->setElementData('number_of_downloads', $number_of_downloads);
                  if (Node::load($nid)->bundle() == 'galleries' &&
                    Node::load($nid)->field_gallery_anchor_id->value) {
                    $webform_submission->setElementData('animal_name', Node::load($nid)->field_gallery_anchor_id->value);
                  }
                  $webform_submission->save();
                }
              }
              else {
                $wf_data = [
                  'webform_id' => $webform_id,
                  'remote_addr' => $ip_address,
                  'uri' => $node->toUrl()->toString(),
                  'entity_type' => 'node',
                  'entity_id' => $nid,
                  'data' => [
                    'email' => !empty($current_email) ? $current_email : 'anonymous',
                    'entity_pdf' => $nid,
                    'number_of_downloads' => 1,
                  ],
                ];

                if (isset($_COOKIE['download_creature_reuse'])) {
                  $wf_data['data']['email'] = $_COOKIE['download_creature_reuse'];
                  if (Node::load($nid)->bundle() == 'galleries' &&
                    Node::load($nid)->field_gallery_anchor_id->value) {
                    $wf_data['data']['animal_name'] = ucfirst(Node::load($nid)->field_gallery_anchor_id->value);
                  }
                }
                if (isset($_COOKIE['newsletter_status'])) {
                  $wf_data['data']['newsletter_status'] = $_COOKIE['newsletter_status'];
                }
                else {
                  if (isset($_COOKIE['download_creature_reuse'])) {
                    $res = $this->checkExistsEmailAndNode($_COOKIE['download_creature_reuse'], $nid, $webform_id, ['newsletter_status' => 1]);
                    if ($res['status']) {
                      $webform_submission_id = $res['webform_submission_id'];
                      $webform_submission = WebformSubmission::load($webform_submission_id);
                      $newsletter_status = $webform_submission->getElementData('newsletter_status');
                      $wf_data['data']['newsletter_status'] = $newsletter_status;
                    }
                  }
                }
                if ($webform_id == 'tracking_pdf_download') {
                  $wf_data['data']['file_id'] = !empty($request_data['file_id']) ? $request_data['file_id'] : '';
                  $wf_data['data']['file_name'] = !empty($request_data['file_name']) ? $request_data['file_name'] : '';
                }

                /** @var \Drupal\webform\Entity\WebformSubmission $isNew */
                $isNew = WebformSubmission::create($wf_data);
                $isNew->save();
              }
              break;

            case 'dashboard_persona_download':
              /** Create Dashboard PDF Download Webformsubmission */

              /** @var \Drupal\Core\Entity\EntityDefinitionUpdateManager $nids */
              $nids = \Drupal::entityQuery('node')
                ->condition('type', 'persona')
                ->condition('field_persona_pdf_file', $nid, '=')
                ->execute();

              /** @var  \Drupal\Core\Entity\EntityInterface $nodes */
              $nodes = Node::loadMultiple($nids);
              $node_id = !empty($nodes) ? reset($nodes) : '';
              $res = $this->existsEmailAndPersona($current_email, $node_id->id());

              if ($res['status']) {
                $webform_submission_id = $res['webform_submission_id'];
                // Check webform is open.
                $webform = Webform::load($webform_id);
                $is_open = WebformSubmissionForm::isOpen($webform);
                if ($is_open === TRUE) {
                  // Load submission.
                  $webform_submission = WebformSubmission::load($webform_submission_id);
                  $number_of_downloads = $res['number_of_downloads'] + 1;
                  $webform_submission->setElementData('number_of_downloads', $number_of_downloads);
                  WebformSubmissionForm::submitWebformSubmission($webform_submission);
                }
              }
              else {
                /** @var \Drupal\webform\Entity\WebformSubmission $isNew */
                $isNew = WebformSubmission::create([
                  'webform_id' => $webform_id,
                  'remote_addr' => $ip_address,
                  'data' => [
                    'email' => $current_email,
                    'entity_persona' => !empty($node_id) ? $node_id->id() : NULL,
                    'entity_pdf' => $nid,
                    'number_of_downloads' => 1,
                  ],
                ]);
                $isNew->save();
              }
              break;

            default:
              $data_res = [
                'msg' => t('Webform is not supported'),
                'success' => FALSE,
              ];
              break;
          }

        }
      }
      else {
        $data_res = ['msg' => 'Nid is not exist', 'success' => FALSE];
      }
    }
    else {
      $data_res = ['msg' => 'Please provide nid', 'success' => FALSE];
    }
    $response = new JsonResponse($data_res);
    $response->setStatusCode(200);
    return $response;
  }

  //5475
  public function downloadGfg2022(){
    $webform_id = 'demo_tracking';
    $webform = Webform::load($webform_id);
    $data = [
      'email'=>$_SESSION['gfg_2022_story_form_email'],
      'newsletter_status'=>$_SESSION['gfg_2022_story_form_newsletter_status']
    ];
    if($_SESSION['gfg_2022_story_form_email'] != null){
      setcookie("gfg_2022_story_form_email", $data['email'], time() -3600);    
      setcookie("gfg_2022_story_form_newsletter", $data['newsletter_status'], time() - 3600);  
    }
    if($_COOKIE['gfg_2022_story_form_email']){
      setcookie("gfg_2022_story_form_email", $_COOKIE['gfg_2022_story_form_email'], time() + (10 * 365 * 24 * 60 * 60));    
      setcookie("gfg_2022_story_form_newsletter", $_COOKIE['gfg_2022_story_form_newsletter'], time() + (10 * 365 * 24 * 60 * 60));
    }else{
      setcookie("gfg_2022_story_form_email", $data['email'], time() + (10 * 365 * 24 * 60 * 60));    
      setcookie("gfg_2022_story_form_newsletter", $data['newsletter_status'], time() + (10 * 365 * 24 * 60 * 60));  
    }

    if($_COOKIE['gfg_2022_story_form_email'] != null || $_SESSION['gfg_2022_story_form_email'] != null){
      if($_COOKIE['gfg_2022_story_form_email']){
        $email = $_COOKIE['gfg_2022_story_form_email'];
        $newsletter_status = $_COOKIE['gfg_2022_story_form_newsletter'];
      }else{
        $email = $_SESSION['gfg_2022_story_form_email'];
        $newsletter_status = $_SESSION['gfg_2022_story_form_newsletter_status'];
      }
      $values = [
        'webform_id' => $webform->id(),
        'data' => [
          'email' => $email,
          'number_of_downloads' => 1,
          'newsletter_status' => $newsletter_status
        ],
      ];
      $is_updated = false;
      $webform = \Drupal\webform\Entity\Webform::load('demo_tracking');  //webform id is the webform name
      if ($webform->hasSubmissions()) {
        $query = \Drupal::entityQuery('webform_submission')
          ->condition('webform_id', 'demo_tracking');
        $result = $query->execute();
        $submission_data = [];

        foreach ($result as $item) {
          $submission = \Drupal\webform\Entity\WebformSubmission::load($item);
          //array_push($submission_data, $submission->getData()['email']);
          if($submission->getData()['email'] == $email){
            $number_of_downloads = $submission->getData()['number_of_downloads'] + 1;
            $submission->setElementData('number_of_downloads', $number_of_downloads);
            WebformSubmissionForm::submitWebformSubmission($submission);
            $is_updated = true;
          }
        }
      }
      if($is_updated === false){
        $webform_submission = WebformSubmission::create($values);
        $webform_submission->save();
      }

      $data_res = ['msg' => $webform_id.$email, 'success' => TRUE];
    }else{
      $data_res = ['msg' => 'error cookie ', 'success' => TRUE];
    }

    $response = new JsonResponse($data_res);
    $response->setStatusCode(200);
    return $response;    
  }
  //end 5475

  /**
   *
   */
  public function existsEmailAndPersona($email, $nid) {
    $result = \Drupal::entityQuery('webform_submission')
      ->condition('webform_id', 'dashboard_persona_download')
      ->execute();
    $storage = \Drupal::entityTypeManager()->getStorage('webform_submission');
    $submissions = $storage->loadMultiple($result);
    if (!empty($submissions)) {
      foreach ($submissions as $submission) {
        if ($submission->getData()['email'] === $email && $submission->getData()['entity_persona'] == $nid) {
          return [
            'status' => TRUE,
            'number_of_downloads' => $submission->getData()['number_of_downloads'],
            'webform_submission_id' => $submission->id(),
          ];
        }
      }
    }
    return ['status' => FALSE];
  }

  /**
   * Get first submission by email.
   *
   * @param $email
   * @param $nid
   * @param $wf_id
   *
   * @return array
   */
  public function checkExistsEmailAndNode($email, $nid, $wf_id, $request_data = []) {
    $query_params = [
      'webform_id' => $wf_id,
      'in_draft' => 0,
      'wf_email' => 'email',
      'wf_entity_pdf' => 'entity_pdf',
      'email_value' => !empty($email) ? $email : 'anonymous',
      'entity_pdf_id' => $nid,
    ];

    $connection = \Drupal::database();
    $query = $connection->select('webform_submission', 'ws');
    $query->innerJoin('webform_submission_data', 'wsd_email', 'ws.sid = wsd_email.sid AND wsd_email.name = :wf_email');
    $query->innerJoin('webform_submission_data', 'wsd_entity_pdf', 'ws.sid = wsd_entity_pdf.sid AND wsd_entity_pdf.name = :wf_entity_pdf');
    $query->fields('ws', ['sid']);
    $query->orderBy('ws.sid', 'DESC');
    $query->where('ws.webform_id = :webform_id AND ws.in_draft = :in_draft AND wsd_email.value = :email_value', $query_params);
    if (!empty($request_data['file_id'])) {
      $query_params['wf_file_id'] = 'file_id';
      $query_params['file_id'] = $request_data['file_id'];
      $query->innerJoin('webform_submission_data', 'wsd_file_id', 'ws.sid = wsd_file_id.sid AND wsd_file_id.name = :wf_file_id');
      $query->where('ws.webform_id = :webform_id AND ws.in_draft = :in_draft AND wsd_email.value = :email_value AND wsd_entity_pdf.value = :entity_pdf_id AND wsd_file_id.value = :file_id', $query_params);
    }
    elseif (isset($request_data['newsletter_status'])) {
      unset($query_params['entity_pdf_id']);
      $query->where('ws.webform_id = :webform_id AND ws.in_draft = :in_draft AND wsd_email.value = :email_value ', $query_params);
    }
    else {
      $query->where('ws.webform_id = :webform_id AND ws.in_draft = :in_draft AND wsd_email.value = :email_value AND wsd_entity_pdf.value = :entity_pdf_id', $query_params);
    }

    $submissions = $query->execute()->fetchCol('sid');

    $submission_id = $submissions ? reset($submissions) : NULL;

    $submission_id = isset($request_data['newsletter_status']) ? end($submissions) : $submission_id;
    if ($submission_id) {
      $submission = WebformSubmission::load($submission_id);
      return [
        'status' => TRUE,
        'number_of_downloads' => $submission->getElementData('number_of_downloads'),
        'webform_submission_id' => $submission->id(),
      ];
    }

    return ['status' => FALSE];
  }

  /**
   *
   */
  public function personaCreateSubmissionForVerifiedAccount($nid) {
    $data_res = ['msg' => 'Create submission success!', 'success' => TRUE];
    $current_user = \Drupal::currentUser();
    if ($current_user->isAuthenticated()) {
      $obw_api_service = \Drupal::service('obw_api.obw_api_service');
      $createSubmission = $obw_api_service->personaCreateSubmissionVerifiedAccount($nid, $current_user);
    }
    else {
      $data_res = [
        'msg' => 'Please login',
        'success' => FALSE,
      ];
    }

    $response = new JsonResponse($data_res);
    $response->setStatusCode(200);
    return $response;
  }

  /**
   *
   */
  public function countLinkClicks($nid) {
    $data_res = ['msg' => '', 'success' => TRUE];
    if (!empty($nid)) {
      $node = Node::load($nid);
      $context = ['@type' => $node->getType(), '%title' => $node->label()];
      if ($node instanceof NodeInterface) {
        $update_value = $node->get('field_persona_number_clicks')->value + 1;
        $node->set('field_persona_number_clicks', $update_value);
        $node->save();
        \Drupal::logger('obw_api')->notice('@type: updated %title.', $context);
      }
    }
    else {
      $data_res = ['msg' => 'Please provide nid', 'success' => FALSE];
    }
    $response = new JsonResponse($data_res);
    $response->setStatusCode(200);
    return $response;
  }

  /**
   *
   */
  public function trackingPostMarkWebhook(Request $request) {
    // $format = $request->getRequestFormat();
    $content = $request->getContent();
    $decode = Json::decode($content);
    \Drupal::logger('obw_api')->notice('$content ' . $request->getContent());

    if (!empty($decode) && $decode['Tag'] == 'OBW Birthd8') {
      $RecordType = $decode['RecordType'];
      switch ($RecordType) {
        case 'Delivery':
          if ($decode['Metadata']['account-status'] == '-1' || $decode['Metadata']['account-status'] == '0') {
            $nid = $decode['Metadata']['persona-id'];
            /** @var \Drupal\node\Entity\Node $node */
            $node = Node::load($nid);
            $upd_valid_email_sent = $node->get('field_persona_valid_emails_sent')->value + 1;
            $node->set('field_persona_valid_emails_sent', $upd_valid_email_sent);
            $node->save();
            $context = [
              '@type' => $node->getType(),
              '%title' => $node->label(),
              '%field' => $upd_valid_email_sent,
            ];
            \Drupal::logger('obw_api')
              ->notice('@type: updated field_persona_valid_emails_sent is %field of %title ', $context);

            if (intval($node->get('field_persona_valid_emails_open')->value) > 0 && intval($node->get('field_persona_valid_emails_sent')->value) > 0) {
              $upd_valid_open_rate = intval($node->get('field_persona_valid_emails_open')->value) / intval($node->get('field_persona_valid_emails_sent')->value);
              $node->set('field_persona_valid_open_rate', $upd_valid_open_rate);
              $node->save();
              $context = [
                '@type' => $node->getType(),
                '%title' => $node->label(),
                '%field' => $upd_valid_open_rate,
              ];
              \Drupal::logger('obw_api')
                ->notice('@type: updated field_persona_valid_emails_open is %field of %title ', $context);
            }

          }
          else {
            $nid = $decode['Metadata']['persona-id'];
            /** @var \Drupal\node\Entity\Node $node */
            $node = Node::load($nid);
            $upd_valid_email_sent = $node->get('field_persona_no_of_emails_sent')->value + 1;
            $node->set('field_persona_no_of_emails_sent', $upd_valid_email_sent);
            $node->save();
            $context = [
              '@type' => $node->getType(),
              '%title' => $node->label(),
              '%field' => $upd_valid_email_sent,
            ];
            \Drupal::logger('obw_api')
              ->notice('@type: updated field_persona_no_of_emails_sent is %field of %title ', $context);

            if (intval($node->get('field_persona_nof_emails_opened')->value) > 0 && intval($node->get('field_persona_no_of_emails_sent')->value) > 0) {
              $upd_valid_open_rate = intval($node->get('field_persona_nof_emails_opened')->value) / intval($node->get('field_persona_no_of_emails_sent')->value);
              $node->set('field_persona_open_rate', $upd_valid_open_rate);
              $node->save();
              $context = [
                '@type' => $node->getType(),
                '%title' => $node->label(),
                '%field' => $upd_valid_open_rate,
              ];
              \Drupal::logger('obw_api')
                ->notice('@type: updated field_persona_open_rate is %field of %title ', $context);
            }

          }
          break;

        case 'Open':
          if (($decode['Metadata']['account-status'] == '-1' && $decode['FirstOpen'] == TRUE) || ($decode['Metadata']['account-status'] == '0' && $decode['FirstOpen'] == TRUE)) {
            $nid = $decode['Metadata']['persona-id'];
            /** @var \Drupal\node\Entity\Node $node */
            $node = Node::load($nid);
            $upd_valid_email_sent = $node->get('field_persona_valid_emails_open')->value + 1;
            $node->set('field_persona_valid_emails_open', $upd_valid_email_sent);
            $node->save();
            $context = [
              '@type' => $node->getType(),
              '%title' => $node->label(),
              '%field' => $upd_valid_email_sent,
            ];
            \Drupal::logger('obw_api')
              ->notice('@type: updated field_persona_valid_emails_open is %field of %title ', $context);

            if (intval($node->get('field_persona_valid_emails_open')->value) > 0 && intval($node->get('field_persona_valid_emails_sent')->value) > 0) {
              $upd_valid_open_rate = intval($node->get('field_persona_valid_emails_open')->value) / intval($node->get('field_persona_valid_emails_sent')->value);
              $node->set('field_persona_valid_open_rate', $upd_valid_open_rate);
              $node->save();
              $context = [
                '@type' => $node->getType(),
                '%title' => $node->label(),
                '%field' => $upd_valid_open_rate,
              ];
              \Drupal::logger('obw_api')
                ->notice('@type: updated field_persona_valid_open_rate is %field of %title ', $context);
            }

            if (intval($node->get('field_persona_valid_emails_open')->value) > 0 && intval($node->get('field_persona_valid_clicks_link')->value) > 0) {
              $upd_valid_thru_rate = intval($node->get('field_persona_valid_clicks_link')->value) / intval($node->get('field_persona_valid_emails_open')->value);
              $node->set('field_persona_valid_thru_rate', $upd_valid_thru_rate);
              $node->save();
              $context = [
                '@type' => $node->getType(),
                '%title' => $node->label(),
                '%field' => $upd_valid_thru_rate,
              ];
              \Drupal::logger('obw_api')
                ->notice('@type: updated field_persona_valid_thru_rate is %field of %title ', $context);
            }

          }
          elseif ($decode['Metadata']['account-status'] == '1' && $decode['FirstOpen'] == TRUE) {
            $nid = $decode['Metadata']['persona-id'];
            /** @var \Drupal\node\Entity\Node $node */
            $node = Node::load($nid);
            $upd_email_opened = $node->get('field_persona_nof_emails_opened')->value + 1;
            $node->set('field_persona_nof_emails_opened', $upd_email_opened);
            $node->save();
            $context = [
              '@type' => $node->getType(),
              '%title' => $node->label(),
              '%field' => $upd_email_opened,
            ];
            \Drupal::logger('obw_api')
              ->notice('@type: updated field_persona_nof_emails_opened is %field of %title ', $context);

            if (intval($node->get('field_persona_nof_emails_opened')->value) > 0 && intval($node->get('field_persona_no_of_emails_sent')->value) > 0) {
              $upd_valid_open_rate = intval($node->get('field_persona_nof_emails_opened')->value) / intval($node->get('field_persona_no_of_emails_sent')->value);
              $node->set('field_persona_open_rate', $upd_valid_open_rate);
              $node->save();
              $context = [
                '@type' => $node->getType(),
                '%title' => $node->label(),
                '%field' => $upd_valid_open_rate,
              ];
              \Drupal::logger('obw_api')
                ->notice('@type: updated field_persona_open_rate is %field of %title ', $context);
            }

            if (intval($node->get('field_persona_nof_emails_opened')->value) > 0 && intval($node->get('field_persona_verification_link')->value) > 0) {
              $upd_valid_thru_rate = intval($node->get('field_persona_verification_link')->value) / intval($node->get('field_persona_nof_emails_opened')->value);
              $node->set('field_persona_click_thru_rate', $upd_valid_thru_rate);
              $node->save();
              $context = [
                '@type' => $node->getType(),
                '%title' => $node->label(),
                '%field' => $upd_valid_thru_rate,
              ];
              \Drupal::logger('obw_api')
                ->notice('@type: updated field_persona_click_thru_rate is %field of %title ', $context);
            }

          }
          break;

        case 'Click':
          if ($decode['Metadata']['account-status'] == '-1' || $decode['Metadata']['account-status'] == '0') {
            $path = $decode['OriginalLink'];
            if (preg_match('/user\/reset/', $path, $matches)) {
              $nid = $decode['Metadata']['persona-id'];
              $node = Node::load($nid);
              $upd_valid_click_link = $node->get('field_persona_valid_clicks_link')->value + 1;
              $node->set('field_persona_valid_clicks_link', $upd_valid_click_link);
              $node->save();
              $context = [
                '@type' => $node->getType(),
                '%title' => $node->label(),
                '%field' => $upd_valid_click_link,
              ];
              \Drupal::logger('obw_api')
                ->notice('@type: updated field_persona_valid_clicks_link is %field of %title ', $context);

              if (intval($node->get('field_persona_valid_emails_open')->value) > 0 && intval($node->get('field_persona_valid_clicks_link')->value) > 0) {
                $upd_valid_thru_rate = intval($node->get('field_persona_valid_clicks_link')->value) / intval($node->get('field_persona_valid_emails_open')->value);
                $node->set('field_persona_valid_thru_rate', $upd_valid_thru_rate);
                $node->save();
                $context = [
                  '@type' => $node->getType(),
                  '%title' => $node->label(),
                  '%field' => $upd_valid_thru_rate,
                ];
                \Drupal::logger('obw_api')
                  ->notice('@type: updated field_persona_valid_thru_rate is %field of %title ', $context);
              }
            }
            else {
              $nid = $decode['Metadata']['persona-id'];
              $node = Node::load($nid);
              $database = \Drupal::database();
              $transaction = $database->startTransaction();
              try {
                $upd_valid_other_links = $node->get('field_persona_valid_other_clicks')->value + 1;
                $node->set('field_persona_valid_other_clicks', $upd_valid_other_links);
                $node->save();
                $context = [
                  '@type' => $node->getType(),
                  '%title' => $node->label(),
                  '%field' => $upd_valid_other_links,
                ];
                \Drupal::logger('obw_api')
                  ->notice('@type: updated field_persona_valid_other_clicks is %field of %title ', $context);
              } catch (\Exception $e) {
                $transaction->rollBack();
                watchdog_exception($e->getMessage(), $e);
                throw new \NewException($e->getMessage(), $e->getCode(), $e->getPrevious());
              }
            }

          }
          else {
            $path = $decode['OriginalLink'];
            if (preg_match('/humankind\/birthd8/', $path, $matches)) {
              $nid = $decode['Metadata']['persona-id'];
              $node = Node::load($nid);
              $upd_valid_click_link = $node->get('field_persona_verification_link')->value + 1;
              $node->set('field_persona_verification_link', $upd_valid_click_link);
              $node->save();
              $context = [
                '@type' => $node->getType(),
                '%title' => $node->label(),
                '%field' => $upd_valid_click_link,
              ];
              \Drupal::logger('obw_api')
                ->notice('@type: updated field_persona_verification_link is %field of %title ', $context);

              if (intval($node->get('field_persona_nof_emails_opened')->value) > 0 && intval($node->get('field_persona_verification_link')->value) > 0) {
                $upd_valid_thru_rate = intval($node->get('field_persona_verification_link')->value) / intval($node->get('field_persona_nof_emails_opened')->value);
                $node->set('field_persona_click_thru_rate', $upd_valid_thru_rate);
                $node->save();
                $context = [
                  '@type' => $node->getType(),
                  '%title' => $node->label(),
                  '%field' => $upd_valid_thru_rate,
                ];
                \Drupal::logger('obw_api')
                  ->notice('@type: updated field_persona_click_thru_rate is %field of %title ', $context);
              }
              else {
                \Drupal::logger('obw_api')->notice('None everything to update');
              }
            }
            else {
              $nid = $decode['Metadata']['persona-id'];
              $node = Node::load($nid);
              $database = \Drupal::database();
              $transaction = $database->startTransaction();
              try {
                $upd_valid_other_links = $node->get('field_persona_no_of_other_clicks')->value + 1;
                $node->set('field_persona_no_of_other_clicks', $upd_valid_other_links);
                $node->save();
                $context = [
                  '@type' => $node->getType(),
                  '%title' => $node->label(),
                  '%field' => $upd_valid_other_links,
                ];
                \Drupal::logger('obw_api')
                  ->notice('@type: updated field_persona_no_of_other_clicks is %field of %title ', $context);
              } catch (\Exception $e) {
                $transaction->rollBack();
                watchdog_exception($e->getMessage(), $e);
                throw new \NewException($e->getMessage(), $e->getCode(), $e->getPrevious());
              }
            }
          }
          break;
      }
      $data_res = ['msg' => 'Has updated successfully', 'success' => TRUE];
    }
    else {
      $data_res = ['msg' => 'Can not access', 'false' => TRUE];
    }

    $response = new JsonResponse($data_res);
    $response->setStatusCode(200);
    return $response;

  }

  /**
   *
   */
  public function countTotalClickCTA($nid) {
    $data_res = ['msg' => '', 'success' => TRUE];
    if (!empty($nid)) {
      $etm = \Drupal::entityTypeManager();
      $node = $etm->getStorage('node')->load($nid);
      if ($node) {
        $total_action_cta = [
          'volunteer' => 0,
          'donate' => 0,
        ];
        if (isset($node->field_landing_ctas) && !empty($node->field_landing_ctas->getValue())) {
          $etm = \Drupal::entityTypeManager();
          $ctas = $etm->getStorage('node')
            ->loadMultiple(array_column($node->field_landing_ctas->getValue(), 'target_id'));
          $cta_ids = [
            '14' => 'volunteer',
            '15' => 'donate',
          ];
          foreach ($ctas as $cta_node) {
            LandingPreprocessNodeManager::countTotalCTAClick($cta_node, $total_action_cta, $cta_ids);
            if (isset($cta_node->field_migrant_workers_cta) && !empty($cta_node->field_migrant_workers_cta->referencedEntities())) {
              $linked_cta = $cta_node->field_migrant_workers_cta->referencedEntities()[0];
              LandingPreprocessNodeManager::countTotalCTAClick($linked_cta, $total_action_cta, $cta_ids);
            }
          }
        }
        $data_res['data'] = $total_action_cta;
      }
      else {
        $data_res = [
          'msg' => 'Can not load the node by nid: ' . $nid,
          'success' => FALSE,
        ];
      }
    }
    else {
      $data_res = ['msg' => 'Please provide nid', 'success' => FALSE];
    }
    $response = new JsonResponse($data_res);
    $response->setStatusCode(200);
    return $response;
  }

  /**
   *
   */
  private function getAnimalTheme($animal) {
    $animal_theme = [];
    if (isset($animal->field_animal_theme) && !empty($animal->field_animal_theme->referencedEntities())) {
      foreach ($animal->field_animal_theme->referencedEntities() as $taxo_theme) {

        $theme_item = [
          'id' => $taxo_theme->id(),
          'name' => $taxo_theme->getName(),
        ];
        $animal_theme[] = $theme_item;
      }
    }
    return $animal_theme;
  }

  /**
   *
   */
  private function loadTermByTaxonomyId($taxo_id) {
    /** @var \Drupal\Core\Entity\EntityTypeManagerInterface $terms */
    $terms = \Drupal::entityTypeManager()
      ->getStorage('taxonomy_term')
      ->loadByProperties([
        'vid' => $taxo_id,
        'status' => 1,
      ]);
    return $terms;
  }

  /**
   *
   */
  public function birthday2021GetPosts(Request $request) {
    $filter = !empty($request->get('filter')) ? $request->get('filter') : NULL;
    $device = !empty($request->get('device')) ? $request->get('device') : 'desktop';
    $obw_api_service = \Drupal::service('obw_api.obw_api_service');
    $data_res = $obw_api_service->getPostsBirthday2021($device, $filter);
    $response = new JsonResponse($data_res);
    $response->setStatusCode(200);
    return $response;
  }

  /**
   *
   */
  public function birthday2021GetPostDetail(Request $request) {
    $data_res = [
      'data' => [
        'title' => '',
        'img' => '',
        'desc' => '',
        'author' => '',
        'role' => '',
        'next' => '',
        'prev' => '',
      ],
      'status' => TRUE,
    ];

    $body_content = JSON::decode($request->getContent());

    $response = new JsonResponse($data_res);
    $response->setStatusCode(200);
    return $response;
  }

  public function getAnimalLevels() {
    $response = [];

    foreach ($this->loadTermByTaxonomyId('animal_level') as $term) {
      $response[] = [
        'id' => $term->id(),
        'name' => $term->getName(),
      ];
    }
    usort($response, function ($item1, $item2) {
      return $item1['name'] <=> $item2['name'];
    });
    $response = new JsonResponse($response);
    $response->setStatusCode(200);
    return $response;
  }

}
