
/**
 * @fileOverview The "cta" plugin. It wraps the selected block level elements
 *     with a 'div' element with specified styles and attributes.
 *
 */
var ctaDialog =null;
var currentSelect = '';
var elemtest = null;
(function ($, Drupal, CKEDITOR, drupalSettings) {
  Drupal.behaviors.myctabehavior = {
    attach: function(context, settings) {
      $(document).off('add_cta_data').on('add_cta_data', function(ev, param1, param2) {
        $('body, html').animate({scrollTop:$('#edit-body-wrapper').offset().top}, 'fast');
        ctaDialog = CKEDITOR.dialog.getCurrent();
        if (ctaDialog === null) {
          console.log("DO NOTHING");
          return;
        }
        ctaDialog.parts.contents.find('#cta-data-result').$[0].innerHTML =
            $('#cta-call-back-data')[0].innerHTML;
        var currentData = ctaDialog.parts.contents.find('textarea.cke_dialog_ui_input_textarea').$[0].value;

        $('#cta-data-result .cta-item input[type="checkbox"]').each(
            function(idex,x){
              if (currentData.indexOf(x.id) !== -1) {
                x.checked=true;
              }
            });
        return false;
      });
      $(document).on('click', '#cta-data-result .cta-item input[type="checkbox"]', function (e) {
        var selectItems = '';
        currentSelect = '';
        $('#cta-data-result .cta-item input[type="checkbox"]').each(function(i,elem){
          if (elem.checked){
            selectItems = selectItems + elem.id + "\n";
            $('label[for="'+elem.id+'"] drupal-entity')[0].id = generateEmbedId();
            currentSelect += $('label[for="'+elem.id+'"] drupal-entity')[0].outerHTML;
          }
        });

        $('.cke_dialog_ui_input_textarea').val(currentSelect);
      });
    }
  };

  CKEDITOR.plugins.add('cta', {
    icons: 'AddFollowUp,AddCta,CtaBox,subhead,quote,link',
    requires: 'widget',

    beforeInit: function( editor ) {
      CKEDITOR.dialog.add( 'ctasinglebox', this.path + 'dialogs/ctasinglebox.js' );

      editor.widgets.add( 'CtaBox', {

        button: 'Create a single CtaBox',
        template:
        '<div class="CtaBox you-can-help mb-30">' +
        '<div class="CtaBox-title head-block clearfix">' +
        '<h3>You can help</h3>' +
        '</div>' +
        '<div class="view-content row CtaBox-content">' +
        '<drupal-entity data-embed-button="cta_for_story" data-entity-embed-display="view_mode:node.feature_content" data-entity-type="node" data-entity-uuid="0fb547b6-038a-4e0f-8350-739c2d1e2379"></drupal-entity>' +
        '</div>' +
        '</div>',

        editables: {
          title: {
            selector: '.CtaBox-title',
            allowedContent: 'div h3 br strong em a img'
          },
          content: {
            selector: '.CtaBox-content',
            allowedContent: 'drupal-entity[data-entity-type,data-entity-uuid,data-entity-embed-display,data-entity-embed-display-settings,data-align,data-caption]'
          }
        },

        allowedContent:
            'div(!CtaBox); div(!CtaBox-content); div(!CtaBox-title)',

        requiredContent: 'div(CtaBox)',

        upcast: function( element ) {
          if (!(element.name == 'div' && element.hasClass( 'CtaBox' ))){
            return;
          }
          return element;
        },
        // Downcast the element.
        downcast: function (element) {

          var divContent = element.children[1].find('drupal-entity',true);
          elemtest = element.children[1];
          var dataOuter = "";
          for(var k=0; k< divContent.length; k++) {
            divContent[k].setHtml("");
            dataOuter +=divContent[k].getOuterHtml();
          }
          element.children[1].setHtml(dataOuter);
          return element;
        },
        init: function() {
          var width = this.element.getStyle( 'width' );
          if ( width )
            this.setData( 'width', width );
          if ( this.element.hasClass( 'align-left' ) )
            this.setData( 'align', 'left' );
          if ( this.element.hasClass( 'align-right' ) )
            this.setData( 'align', 'right' );
          if ( this.element.hasClass( 'align-center' ) )
            this.setData( 'align', 'center' );
        },

        data: function() {
          var element = this.element;
          if ( this.data.ctadata !== undefined) {
            element.find('.CtaBox-content',true).getItem(0).setHtml("");
            element.find('.CtaBox-content',true).getItem(0).appendHtml(this.data.ctadata );
          }
          if ( this.data.width === '' )
            this.element.removeStyle( 'width' );
          else
            this.element.setStyle( 'width', this.data.width );

          this.element.removeClass( 'align-left' );
          this.element.removeClass( 'align-right' );
          this.element.removeClass( 'align-center' );
          if ( this.data.align ) {
            this.element.addClass( 'align-' + this.data.align );
          }
        },
        dialog: 'ctasinglebox',
        edit: function(ev) {
          $('#edit-obw-cta-callback').trigger('click');
        },
      } );
      editor.ui.addButton('CtaBox', {
        label : 'CtaBox',
        command : 'CtaBox',
        toolbar: 'blocks,50'
      });

      editor.widgets.add( 'followup', {

        button: 'Create a Follow up section',
        template:
        '<div class="follow-up">' + '[view_follow_up]' +
        '</div>',

        editables: {
          content: {
            selector: '.follow-up',
            allowedContent: ''
          }
        },
        allowedContent:
            'div(!follow-up)',

        requiredContent: 'div(follow-up)',

        upcast: function( element ) {
          if (!(element.name == 'div' && element.hasClass( 'follow-up' ))){
            return;
          }
          return element;
        },
        // Downcast the element.
        downcast: function (element) {
          return element;
        },
        init: function() {
        },
      } );
      editor.ui.addButton('AddFollowUp', {
        label : 'Add Follow Up',
        command : 'followup',
        toolbar: 'blocks,50'
      });

      editor.widgets.add( 'addcta', {

        button: 'Create a Follow up section',
        template:
        '<div class="cta-block">' + '[view_all_cta]' +
        '</div>',

        editables: {
          content: {
            selector: '.cta-block',
            allowedContent: ''
          }
        },
        allowedContent:
            'div(!cta-block)',

        requiredContent: 'div(cta-block)',

        upcast: function( element ) {
          if (!(element.name == 'div' && element.hasClass( 'cta-block' ))){
            return;
          }
          return element;
        },
        // Downcast the element.
        downcast: function (element) {
          return element;
        },
        init: function() {
        },
      } );

      // editor.addCommand( 'addcta', {
      //   exec: function( editor ) {
      //     var now = new Date();
      //     editor.insertHtml(
      //         '<div class=\'cta-block\'>[view_all_cta]</div>'
      //     //    'The current date and time is: <em>' + now.toString() + '</em>'
      //     );
      //   }
      // });
      editor.ui.addButton( 'AddCta', {
        label: 'Insert CTA',
        command: 'addcta',
        toolbar: 'blocks,50'
      });

      editor.widgets.add( 'subhead', {
        button: 'Create a subhead section',
        template:
        '<subhead>' +
        '<div class="subhead" placeholder="subhead content">' +
            'TEXT HERE' +
        '</div>' +
        '</subhead>',
        editables: {
          content: {
            selector: '.subhead',
            allowedContent: 'div;i;a;b;br;h2;h3;h4'
          }
        },
        allowedContent:
            'div;i;a;b;br;h2;h3;h4',
        requiredContent: 'subhead',
      } );
      editor.ui.addButton('subhead', {
        label : 'subhead',
        command : 'subhead',
        toolbar: 'blocks,50'
      });
      editor.widgets.add( 'subhead', {
        button: 'Create a subhead section',
        template:
        '<subhead>' +
        '<div class="subhead" placeholder="subhead content">' +
        'SUBHEAD TEXT HERE' +
        '</div>' +
        '</subhead>',
        editables: {
          content: {
            selector: '.subhead',
            allowedContent: 'div;i;a;b;br;h2;h3;h4'
          }
        },
        allowedContent:
            'div;i;a;b;br;h2;h3;h4',
        requiredContent: 'subhead',
      } );
      editor.ui.addButton('subhead', {
        label : 'subhead',
        command : 'subhead',
        toolbar: 'blocks,50'
      });
      editor.widgets.add( 'quote', {
        button: 'Create a quote section',
        template:
        '<quote>' +
        '<div class="quote" placeholder="quote content">' +
        'QUOTE TEXT HERE' +
        '</div>' +
        '</quote>',
        editables: {
          content: {
            selector: '.quote',
            allowedContent: 'div;i;a;b;br;h2;h3;h4'
          }
        },
        allowedContent:
            'div;i;a;b;br;h2;h3;h4',
        requiredContent: 'quote',
      } );
      editor.ui.addButton('quote', {
        label : 'quote',
        command : 'quote',
        toolbar: 'blocks,50'
      });
      editor.widgets.add( 'link', {
        button: 'Create a link section',
        template:
        '<link-block>' +
        '<div class="link" placeholder="link content">' +
        'LINK BLOCK TEXT HERE' +
        '</div>' +
        '</link-block>',
        editables: {
          content: {
            selector: '.link',
            allowedContent: 'div;i;a;b;br;h2;h3;h4'
          }
        },
        allowedContent:
            'div;i;a;b;br;h2;h3;h4',
        requiredContent: 'link',
      } );
      editor.ui.addButton('link', {
        label : 'link',
        command : 'link',
        toolbar: 'blocks,50'
      });
    },
    onLoad: function() {
      CKEDITOR.addCss(
          'div.cta-block {' +
          'visibility: hidden;}\n' +
          'div.cta-block:after {' +
          'visibility: visible;' +
          'display: block;' +
          'content: \'This Block shows all "Call To Action" of the story\';' +
          'padding: 10px;' +
          'border: solid 1px green;' +
          'color: red;' +
          'text-align: center;' +
          'background: azure;' +
          'width: 100%;' +
          '}\n' +
          '.you-can-help {' +
          'border-bottom-left-radius: 3px;' +
          'border-bottom-right-radius: 3px;' +
          'border-top: solid 2px #F25A2C;' +
          'background-color: #FDF5F2;' +
          'font-family: "Source Sans Pro", sans-serif;' +
          '}\n' +
          '.you-can-help .head-block {' +
          'background-color: #E2612F;' +
          'padding: 16px 20px;' +
          '}\n' +
          '.you-can-help .item-block p {' +
          'margin: 0;' +
          'color: #6B6B6B;' +
          'font-size: 16px;' +
          'line-height: 22px;' +
          '}\n' +
          '.you-can-help .item-block h3 {' +
          'margin: 0 0 4px;' +
          '}\n' +
          '.you-can-help .item-block:first-child {' +
          'border-top: none;' +
          '}\n' +
          '.you-can-help .item-block {' +
          'padding: 10px 0;' +
          'border-top: solid 1px #eee;' +
          '}' +
          '.you-can-help .item-block a {'  +
          'display: inline-block;' +
          '}' +
          '.you-can-help .item-block a b {\n' +
          '    color: #F25A2C;\n' +
          '    font-size: 14px;\n' +
          '    font-weight: 600;\n' +
          '    letter-spacing: 0.5px;\n' +
          '    line-height: 18px;\n' +
          '    text-transform: uppercase;\n' +
          '    display: block;\n' +
          '    margin: 0 0 4px;\n' +
          '}' +
          '.you-can-help .item-block a span {\n' +
          '    margin: 0;\n' +
          '    color: #6B6B6B;\n' +
          '    font-size: 14px;\n' +
          '    line-height: 19px;\n' +
          '}' +
          '.you-can-help .item-block:before {\n' +
          '    -moz-osx-font-smoothing: grayscale;\n' +
          '    -webkit-font-smoothing: antialiased;\n' +
          '    display: inline-block;\n' +
          '    font-style: normal;\n' +
          '    font-variant: normal;\n' +
          '    text-rendering: auto;\n' +
          '    line-height: 1;\n' +
          '    font-family: Font Awesome\\ 5 Pro;\n' +
          '    content: "\\f054";\n' +
          '    position: absolute;\n' +
          '    -webkit-transform: translateY(-50%);\n' +
          '    -ms-transform: translateY(-50%);\n' +
          '    transform: translateY(-50%);\n' +
          '    top: 50%;\n' +
          '    right: 20px;\n' +
          '    font-size: 30px;\n' +
          '    color: #CCCCCC;\n' +
          '    font-weight: 300;\n' +
          '}' +
          'drupal-entity:after { \n' +
          '   display: block;\n' +
          '}' +
          'drupal-entity:after { ' +
          '    content: "{{The block content of CTA}}";\n' +
          '    font-size: 9px;' +
          '    color: grey;' +
          '}' +
          'subhead:after, quote:after, link-block:after { ' +
          '    font-size: 9px;' +
          '    color: red;' +
          '}' +
          'subhead div, quote div, link-block div { ' +
          '    font-size: 14px;' +
          '    background-color: #AAAAAA;'  +
          '}' +
          'subhead:after {' +
          '    content: "{{The block content of subhead}}";\n' +
          '}' +
          'quote:after {' +
          '    content: "{{The block content of quote}}";\n' +
          '}' +
          'link-block:after {' +
          '    content: "{{The block content of link}}";\n' +
          '}'
      );
    },

  });



    /**
   * Generates unique HTML IDs for the widgets.
   *
   * @returns {string}
   */
  function generateEmbedId() {
    if (typeof generateEmbedId.counter == 'undefined') {
      generateEmbedId.counter = 1000;
    }
    return 'entity-embed-' + generateEmbedId.counter++;
  }
})(jQuery, Drupal, CKEDITOR,drupalSettings);

CKEDITOR.on('instanceReady', function(ev){
  var tags_to_fix_indent = ['p','h1','h2','h3','h4','h5','h6', 'div', 'ul', 'ol', 'pre', 'table'];
  for (var tag in tags_to_fix_indent) {
    ev.editor.dataProcessor.writer.setRules(tags_to_fix_indent[tag], {
      indent: 0,
      breakBeforeOpen: 0,
      breakAfterOpen: 0,
      breakBeforeClose: 0,
      breakAfterClose: 0,
      needsSpace: 0
    });
  }

  ev.editor.on('paste', function (ev) {
    //Use regex to remove b tag when paste content into body of story.
    ev.data.dataValue = ev.data.dataValue.replace(/<\/?b[^>]*>/g, '');
  });

});
