
( function($, Drupal, drupalSettings) {
  CKEDITOR.dialog.add( 'ctasinglebox', function( editor ) {
    var dialogDefinition = {
      title:          'CTA Settings Dialog',
      resizable:      CKEDITOR.DIALOG_RESIZE_BOTH,
      minWidth:       500,
      minHeight:      400,
      contents: [
        {
          id:         'tab1',
          label:      'Select Call To Action',
          title:      'Call To Action Setting Dialog',
          accessKey:  'Q',
          elements: [

            {
              type: 'html',
              html: '<div id="cta-data-result" class="you-can-help"><i>Call To Action data is loading...</i></div>',
              setup: function( widget ) {
                //this.innerHTML  =  widget.data.ctadata ;
              },
              commit: function( widget ) {
               // widget.setData( 'ctadata', this.innerHTML );
              }
            },
            {
              type: 'textarea',
              id: 'ctadata',
              label: 'CTADATA',
              style:'display:none',
              class:'hidden-item',
              'default': '',
              validate: function() {
                if ( this.getValue().length < 5 ) {
                  api.openMsgDialog( 'The comment is too short.' );
                  return false;
                }
              },
              setup: function( widget ) {
                var element = getSelectedEmbeddedEntity(editor);
                var ctadata = '';
                if (element){
                element.find('drupal-entity',true).$.forEach(
                    function(x,i){
                      ctadata += x.outerHTML;
                    });
                }
                widget.data.ctadata = ctadata;
                this.setValue(ctadata) ;
              },
              commit: function( widget ) {
                widget.setData( 'ctadata', this.getValue() );
              }
            },
            {
              id: 'align',
              type: 'select',
              label: 'Align',
              items: [
                [ editor.lang.common.notSet, '' ],
                [ editor.lang.common.alignLeft, 'left' ],
                [ editor.lang.common.alignRight, 'right' ],
                [ editor.lang.common.alignCenter, 'center' ]
              ],
              setup: function( widget ) {
                this.setValue( widget.data.align );
              },
              commit: function( widget ) {
                widget.setData( 'align', this.getValue() );
              }
            },
            {
              id: 'width',
              type: 'text',
              label: 'Width',
              width: '200px',
              setup: function( widget ) {
                this.setValue( widget.data.width );
              },
              commit: function( widget ) {
                widget.setData( 'width', this.getValue() );
              }
            }
          ]
        }
      ],
      buttons : [ CKEDITOR.dialog.cancelButton, CKEDITOR.dialog.okButton ]
    };
    return dialogDefinition;
  } );
  /**
   * Get the surrounding drupalentity widget element.
   *
   * @param {CKEDITOR.editor} editor
   */
  function getSelectedEmbeddedEntity(editor) {
    var selection = editor.getSelection();
    var selectedElement = selection.getSelectedElement();
    if (isEditableEntityWidget(editor, selectedElement)) {
      return selectedElement;
    }

    return null;
  }
  /**
   * Checks if the given element is an editable drupalentity widget.
   *
   * @param {CKEDITOR.editor} editor
   * @param {CKEDITOR.htmlParser.element} element
   */
  function isEditableEntityWidget (editor, element) {
    var widget = editor.widgets.getByElement(element, true);
    if (!widget || widget.name !== 'CtaBox') {
      return false;
    }

    return $(element.$.firstChild).hasClass('CtaBox');
  }
  /**
   * Generates unique HTML IDs for the widgets.
   *
   * @returns {string}
   */
  function generateEmbedId() {
    if (typeof generateEmbedId.counter == 'undefined') {
      generateEmbedId.counter = 0;
    }
    return 'entity-embed-' + generateEmbedId.counter++;
  }
} )(jQuery, Drupal, drupalSettings);