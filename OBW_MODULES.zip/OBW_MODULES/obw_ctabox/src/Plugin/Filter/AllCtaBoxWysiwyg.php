<?php

namespace Drupal\obw_ctabox\Plugin\Filter;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\filter\FilterProcessResult;
use Drupal\filter\Plugin\FilterBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * The filter to turn tokens inserted into all cta box
 *
 * @Filter(
 *   title = @Translation("All CTA box WYSIWYG"),
 *   id = "all_cta_box_wysiwyg",
 *   description = @Translation("turn tokens inserted into all cta box."),
 *   type = Drupal\filter\Plugin\FilterInterface::TYPE_MARKUP_LANGUAGE
 * )
 */
class AllCtaBoxWysiwyg extends FilterBase implements ContainerFactoryPluginInterface {

  /**
   * The renderer.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected $renderer;

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   */
  protected $currentUser;

  /**
   * VideoEmbedWysiwyg constructor.
   *
   * @param array $configuration
   *   Plugin configuration.
   * @param string $plugin_id
   *   Plugin ID.
   * @param mixed $plugin_definition
   *   Plugin definition.
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The renderer.
   * @param \Drupal\Core\Session\AccountProxyInterface $current_user
   *   The current user.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, RendererInterface $renderer, AccountProxyInterface $current_user) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->renderer = $renderer;
    $this->currentUser = $current_user;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static($configuration, $plugin_id, $plugin_definition, $container->get('renderer'), $container->get('current_user'));
  }

  /**
   * {@inheritdoc}
   */
  public function process($text, $langcode) {

    $response = new FilterProcessResult($text);

    if (FALSE !== strpos($text, 'ckeditor-image-gallery')) {
      $doc = new \DomDocument();

      libxml_use_internal_errors(TRUE);
      $doc->loadHTML(mb_convert_encoding($text, 'HTML-ENTITIES', 'UTF-8'));
      libxml_clear_errors();

      $classname = "ckeditor-image-gallery";
      $finder = new \DomXPath($doc);
      $galleries = $finder->query("//*[contains(@class, '$classname')]");

      foreach ($galleries as $gallery) {

        $arr_imgages = $gallery->getElementsByTagName('img');

        foreach ($arr_imgages as $item) {

          $origin_src = $item->getAttribute('src');
          if (FALSE === strpos($origin_src, 'http')) {
            $origin_src = str_replace('/sites/default/files/', 'public://', $origin_src);
            $style600x400 = \Drupal\image\Entity\ImageStyle::load('medium_600x400');

            if ($style600x400) {
              $thumbnai_src = $style600x400->buildUrl($origin_src);
            }
            else {
              $thumbnai_src = $origin_src;
            }

            $item->setAttribute('class', 'origin-image');
            $imageElement = $doc->createElement('image');
            $imageElement->setAttribute('class', 'thumbnail-image');
            $imageElement->setAttribute('src', $thumbnai_src);

            $parentNode = &$item->parentNode;
            $parentNode->appendChild($imageElement);
          }
        }
      }

      $text = $doc->saveHTML();
      $text = str_replace("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\" \"http://www.w3.org/TR/REC-html40/loose.dtd\">\n<html><body>", '', $text);
      $text = str_replace('</body></html>', '', $text);
    }

    if (FALSE !== strpos($text, '[view_all_cta]')) {
      //  $view_all_cta = views_embed_view('cta_of_story', 'block_on_story');
      //  $view_all_cta_render = $this->renderer->render($view_all_cta);

      $node_preview = \Drupal::routeMatch()->getParameter('node_preview');
      $node = \Drupal::routeMatch()->getParameter('node');
      if ($node_preview && !$node) {
        $node = $node_preview;
      }
      $view_all_cta_render = "";
      if ($node instanceof \Drupal\node\NodeInterface) {
        // You can get nid and anything else you need from the node object.
        $type = $node->getType();
        if ('story' == $type) {
          $view_all_cta_render = $this->renderCTA($node);
        }
      }
      $text = str_replace('[view_all_cta]', $view_all_cta_render, $text);
    }


    if (FALSE !== strpos($text, '[view_follow_up]')) {
      $node_preview = \Drupal::routeMatch()->getParameter('node_preview');
      $node = \Drupal::routeMatch()->getParameter('node');
      if ($node_preview && !$node) {
        $node = $node_preview;
      }
      if ($node instanceof \Drupal\node\NodeInterface) {
        // You can get nid and anything else you need from the node object.
        $type = $node->getType();
        if ('story' == $type) {
          $render_array = $node->field_story_follow_up_story->view('full');
          // Render the result.
          $view_follow_up_render = $this->renderer->render($render_array);
          $text = str_replace('[view_follow_up]', $view_follow_up_render, $text);
        }
      }
    }
    $response->setProcessedText($text);
    return $response;
  }

  public function renderCTA($node) {
    $html = "";
    if ($node->get('field_story_call_to_actions') && $node->get('field_story_call_to_actions')
        ->getValue()) {

      $entity_type = 'node';
      $view_mode = 'feature_content';
      $builder = \Drupal::entityTypeManager()->getViewBuilder($entity_type);

      //show only 02 first cta of story
      $count = 0;
      $survey_index = 0;
      $survey_html = '';
      $cta_html = '';
      foreach ($node->field_story_call_to_actions as $item) {
        $item_category = $item->entity->field_cta_category->referencedEntities()[0]->name->value;
        if ($item_category == 'Survey') {
          $survey_index++;
          if ($survey_index === 1) {
            $survey_html = ' <div class="you-can-help">
              <div class="view-header head-block clearfix">
                  <h3> ' . t("Take a survey") . '</h3>
              </div>
              <div class="view-content">
              <div class="row"> ';
          }

          if ($survey_index <= 2) {
            $render_array = $builder->view($item->entity, $view_mode);
            $survey_html .= $this->renderer->render($render_array);
            $survey_html = str_replace('"survey-index"', 'survey-' . $survey_index, $survey_html);
          }
        }
        else {
          $count++;
          if ($count === 1) {
            $cta_html = ' <div class="you-can-help">
              <div class="view-header head-block clearfix">
                  <h3> ' . t("Take Action") . '</h3>
              </div>
              <div class="view-content">
              <div class="row"> ';
          }
          if ($count <= 2) {
            $render_array = $builder->view($item->entity, $view_mode);
            $cta_html .= $this->renderer->render($render_array);
          }
        }
      }

      if (!empty($cta_html)) {
        $cta_html .= '</div>';
        if ($count > 2) {
          $cta_html .= '<div class="viewall-cta"> <a href="#" class="go-take-action see-all">' .
            t('View all actions (:s)', [':s' => $count]) . '</a></div>';
        }
        $cta_html .= '</div> </div>';
        $html .= $cta_html;
      }

      if (!empty($survey_html)) {
        $survey_html .= '</div>';
        if ($survey_index > 2) {
          $survey_html .= '<div class="viewall-cta"> <a href="#" class="go-take-action see-all">' .
            t('View all actions (:s)', [':s' => $survey_index]) . '</a></div>';
        }
        $survey_html .= '</div> </div>';
        $html .= $survey_html;
      }
    }
    return $html;
  }

  public function getElementsByClass(&$parentNode, $tagName, $className) {
    $nodes = [];

    $childNodeList = $parentNode->getElementsByTagName($tagName);
    for ($i = 0; $i < $childNodeList->length; $i++) {
      $temp = $childNodeList->item($i);
      if (stripos($temp->getAttribute('class'), $className) !== FALSE) {
        $nodes[] = $temp;
      }
    }

    return $nodes;
  }

}
