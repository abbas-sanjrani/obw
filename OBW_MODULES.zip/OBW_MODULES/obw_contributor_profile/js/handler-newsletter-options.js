(function($) {
  $(document).ready(function(){
    $('select').select2();

    if($('#edit-field-account-news-subscribed').length > 0) {
      if($('#edit-field-account-news-subscribed').prop("checked") === false) {
        $('#edit-field-account-subcribe-options').hide();
      }

      $('#edit-field-account-news-subscribed').click(function(){
        if($(this).prop("checked") === true){
          $('#edit-field-account-subcribe-options').show();
          jQuery('#edit-field-account-subcribe-options-weekly').prop("checked", true);
        }
        else if($(this).prop("checked") === false){
          $('#edit-field-account-subcribe-options').hide();
        }
      });
    }
  });
})(jQuery);
