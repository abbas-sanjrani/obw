(function($) {
  $(document).ready(function(){
    $('#cancel-subscription-monthly').on('click', function(){
      console.log('23123');
      if ($('.popup-confirm-cancel-subscription').length > 0) {
        var element = $('.popup-confirm-cancel-subscription');
        $.magnificPopup.open({
          items: {
            src: element,
            type: 'inline'
          },
          mainClass: 'cancel-subscription-popup',
          midClick: true,
        });
      }
    });

    $('#confirm-cancel-subscription').on('click', function(){

      $('.page-loading').fadeIn();
      $.magnificPopup.close();
      var cancel_subscription_endpoint  = window.location.protocol + "//" + window.location.host + "/api/v1/cancel_subscription_monthly";
      $.ajax({
        type: "POST",
        url: cancel_subscription_endpoint,
        success: function(data) {
          if(data.success) {
            $('.section.donation-history .donation-buttons-list').remove();
            $(".section.donation-history table tbody tr").each(function (index, tr) {
              if($(tr).find('td:nth-child(3)').text() === 'Monthly' && $(tr).find('td:nth-child(4)').text() === 'Ongoing') {
                $(tr).find('td:nth-child(4)').text('Cancelled');
              }
            });
          }
          if(data.msg) {
            $('.popup-cancel-subscription-notify .msg-response').text(data.msg);
          }
          if ($('.popup-cancel-subscription-notify').length > 0) {
            $('.page-loading').fadeOut();
            var element1 = $('.popup-cancel-subscription-notify');
            $.magnificPopup.open({
              items: {
                src: element1,
                type: 'inline'
              },
              mainClass: 'cancel-subscription-notify',
              midClick: true,
            });
          }
        },
        dataType: "json"
      });
    });
  });
})(jQuery);
