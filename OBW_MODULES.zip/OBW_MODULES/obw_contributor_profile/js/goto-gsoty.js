(function($) {
  Drupal.behaviors.create_pass_then_gsoty = {
    attach: function (context, settings) {
      console.log('goto gsoty', $('.gsoty_voting').length);
      if ($('.gsoty_voting').length > 0) {
        var fiveSeconds = new Date().getTime() + 5000;
        $('#gsoty-count-down').countdown(fiveSeconds, function(event){
           $(this).html(event.strftime('%-S'));
        }).on('finish.countdown', function(event) {
          setTimeout(function(){
             $('.gsoty_voting')[0].click();
          },1000);
        });
      }
    }
  };
})(jQuery);
