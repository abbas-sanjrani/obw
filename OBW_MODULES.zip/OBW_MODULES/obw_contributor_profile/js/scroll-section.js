(function($) {
	var elem = $('#pos-scroll');
  if(elem) {
    var scrollTo = elem.attr('class');
    // console.log("top", $('.'+scrollTo).offset().top);
   	if(scrollTo){
   		 $("html, body").animate({
	      scrollTop: $('.'+scrollTo).offset().top - 145
	    });
   	}
  }
})(jQuery);