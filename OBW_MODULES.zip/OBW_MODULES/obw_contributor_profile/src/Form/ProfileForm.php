<?php

namespace Drupal\obw_contributor_profile\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\form_alter_service\FormAlterBase;

/**
 *  Alter profile form to add button and link
 *
 * Class ProfileForm
 *
 * @package Drupal\obw_contributor_profile\Form
 */
class ProfileForm extends FormAlterBase {


  /**
   * @param array $form
   * @param FormStateInterface $form_state
   */
  public function alterForm(array &$form, FormStateInterface $form_state) {
    //   kint($form);
    $form['actions']['discard'] = [
      '#type' => 'button',
      '#weight' => 30,
      '#value' => t('Discard '),
      '#attributes' => ['class' => ['btn-discard']],
      '#limit_validation_errors' => [],
    ];

    $form['#attached']['library'][] = 'obw_utilities/form_action_button';
  }

}
