<?php
/**
 * @file
 * Contains \Drupal\obw_contributor_profile\Form\activeCampaignConfig.
 */

namespace Drupal\obw_contributor_profile\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class activeCampaignConfig.
 *
 * @package \Drupal\obw_contributor_profile\Form
 */
class activeCampaignConfig extends ConfigFormBase {

  /**
   * Config settings.
   *
   * @var string
   */
  const SETTINGS = 'obw_contributor_profile.config';

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      static::SETTINGS,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'obw_contributor_profile_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config(static::SETTINGS);

    $form['AC_API_KEY'] = [
      '#type' => 'textfield',
      '#title' => t('API key'),
      '#required' => TRUE,
      '#default_value' => $config->get('AC_API_KEY'),
    ];
    $form['AC_LIST_ID_WEEKLY_FOR_OBW'] = [
      '#type' => 'textfield',
      '#title' => t('The active campaign list for OBW (Subscribe weekly)'),
      '#required' => TRUE,
      '#default_value' => $config->get('AC_LIST_ID_WEEKLY_FOR_OBW'),
    ];

    $form['AC_LIST_ID_MONTHLY_FOR_OBW'] = [
      '#type' => 'textfield',
      '#title' => t('The active campaign list for OBW (Subscribe monthly)'),
      '#required' => TRUE,
      '#default_value' => $config->get('AC_LIST_ID_MONTHLY_FOR_OBW'),
    ];

    $form['AC_LIST_ID_FOR_TBT'] = [
      '#type' => 'textfield',
      '#title' => t('The active campaign list for TBT'),
      '#required' => TRUE,
      '#default_value' => $config->get('AC_LIST_ID_FOR_TBT'),
    ];

    $form['AC_URL_REQUEST'] = [
      '#type' => 'textfield',
      '#title' => t('URL request to active campaign'),
      '#required' => TRUE,
      '#default_value' => $config->get('AC_URL_REQUEST'),
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => t('Save'),
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config(static::SETTINGS)
      ->set('AC_API_KEY', $form_state->getValue('AC_API_KEY'))
      ->set('AC_LIST_ID_WEEKLY_FOR_OBW', $form_state->getValue('AC_LIST_ID_WEEKLY_FOR_OBW'))
      ->set('AC_LIST_ID_MONTHLY_FOR_OBW', $form_state->getValue('AC_LIST_ID_MONTHLY_FOR_OBW'))
      ->set('AC_LIST_ID_FOR_TBT', $form_state->getValue('AC_LIST_ID_FOR_TBT'))
      ->set('AC_URL_REQUEST', $form_state->getValue('AC_URL_REQUEST'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}

?>
