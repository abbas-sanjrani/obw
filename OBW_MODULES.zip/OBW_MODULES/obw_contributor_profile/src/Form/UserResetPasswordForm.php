<?php
/**
 * Created by PhpStorm.
 * User: leopham
 * Date: 10/18/18
 * Time: 10:34 AM
 */

namespace Drupal\obw_contributor_profile\Form;

use Drupal;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\Component\Utility\Crypt;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\RedirectCommand;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Password\PasswordInterface;
use Drupal\Core\Render\Element\PasswordConfirm;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Drupal\user\UserInterface;
use Exception;
use Symfony\Component\DependencyInjection\ContainerInterface;


class UserResetPasswordForm extends FormBase {

  protected $entity_manager;

  protected $language_manager;

  protected $entity_type_bundle_info;

  protected $time;

  protected $current_user;

  protected $form_builder;

  protected $password_handler;

  protected $firstLogin;

  public function __construct(
    EntityTypeManagerInterface    $entity_manager,
    LanguageManagerInterface      $language_manager,
    EntityTypeBundleInfoInterface $entity_type_bundle_info = NULL,
    TimeInterface                 $time = NULL,
    AccountInterface              $account,
    PasswordInterface             $password_hasher,
    FormBuilderInterface          $form_builder) {
    $this->entity_manager = $entity_manager;
    $this->language_manager = $language_manager;
    $this->time = $time;
    $this->current_user = User::load($account->id());

    $this->form_builder = $form_builder;
    $this->password_handler = $password_hasher;
    $this->firstLogin = self::isFirstLogin();
  }

  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('language_manager'),
      $container->get('entity_type.bundle.info'),
      $container->get('datetime.time'),
      $container->get('current_user'),
      $container->get('password'),
      $container->get('form_builder')
    );
  }

  public static function loginHistoryLastLogin(AccountInterface $account = NULL) {
    if (!$account) {
      $account = \Drupal::currentUser();
    }

    if ($account->isAnonymous()) {
      return FALSE;
    }

    return \Drupal::database()->select('login_history', 'lh')
      ->fields('lh', ['login', 'hostname', 'one_time', 'user_agent'])
      ->condition('uid', $account->id())
      ->orderBy('login', 'DESC')
      ->execute()
      ->fetchAll();
  }

  public static function isFirstLogin (): bool {
    if (self::loginHistoryLastLogin() == FALSE || (is_array(self::loginHistoryLastLogin()) && count(self::loginHistoryLastLogin()) == 1)) {
      return TRUE;
    }
    return FALSE;
  }

  public function getFormId() {
    return 'obw_contributor_profile_reset_password_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state, UserInterface $user = NULL) {
    if (!$form_state->get('user_pass_reset') && ($token = $this->getRequest()
        ->get('pass-reset-token'))) {
      $session_key = 'pass_reset_' . $this->current_user->id();
      $user_pass_reset = isset($_SESSION[$session_key]) && hash_equals($_SESSION[$session_key], $token);
      $form_state->set('user_pass_reset', $user_pass_reset);
    }
    if ($form_state->get('user_pass_reset')) {

      $form['title'] = [
        '#markup' => t('<h3>Reset Password</h3>'),
      ];

      if ($this->firstLogin) {
        $form['title'] = [
          '#markup' => t('<h3>Set Your Password</h3>'),
        ];
      }
      $session_handler = \Drupal::service('obw_social.session_handler');
      if ($session_handler->get('come_back_url') !== NULL) {
        $node = $this->getNodeFromComeBackURL($session_handler->get('come_back_url'));
        if ($node && $node->getType() == 'pdf_page') {
          $form['title'] = [
            '#markup' => t('<h3>Reset Password</h3><p>Complete your account sign-up and receive your persona toolkit</p>'),
          ];

          if ($this->firstLogin) {
            $form['title'] = [
              '#markup' => t('<h3>Set Your Password</h3><p>Complete your account sign-up and receive your persona toolkit</p>'),
            ];
          }
        }
      }

      $form['pass'] = [
        '#type' => 'password_confirm',
        '#size' => 25,
        //        '#description' => $this->t('To change the current user password, enter the new password in both fields.'),
      ];
      $form['#id'] = 'obw-contributor-profile-reset-password-form';
      $form['actions']['submit'] = [
        '#type' => 'submit',
        '#value' => t('Change password'),
        '#button_type' => 'primary',
        '#attributes' => [
          'class' => [
            'use-ajax',
          ],
        ],
        '#ajax' => [
          'callback' => '::submitResetPassword',
          'event' => 'click',
          'method' => 'replace',
          'wrapper' => $form['#id'],
        ],
      ];

      if ($this->firstLogin) {
        $form['actions']['submit']['#value'] = t('Create Password');
      }

      $form['pass']['#process'][] = [$this, 'processPasswordField'];

      $form['#theme'][] = 'reset_password_form';
      $form['#attached']['library'][] = 'obw_contributor_profile/form-goto-gsoty';
    }
    else {
      return $this->redirect('<front>');
    }

    return $form;
  }

  function processPasswordField($element, FormStateInterface $form_state, &$complete_form) {
    $element = PasswordConfirm::processPasswordConfirm($element, $form_state, $complete_form);
    $element['pass1']['#title'] = t('New Password');
    $element['pass2']['#title'] = t('Confirm New Password');
    if ($this->firstLogin) {
      $element['pass1']['#title'] = t('Enter Password');
      $element['pass2']['#title'] = t('Confirm Password');

    }
    $element['#element_validate'] = [
      [get_called_class(), 'validatePasswordConfirm'],
      [
        '\Drupal\obw_contributor_profile\Form\ChangePasswordForm',
        'validatePasswordStrength',
      ],
    ];

    return $element;
  }

  /**
   * Validates a password_confirm element.
   */
  public static function validatePasswordConfirm(&$element, FormStateInterface $form_state, &$complete_form) {
    $pass1 = trim($element['pass1']['#value']);
    $pass2 = trim($element['pass2']['#value']);
    if (strlen($pass1) > 0 || strlen($pass2) > 0) {
      if (strcmp($pass1, $pass2)) {
        $error_message_text = t('<div class="ui basic red pointing prompt label transition visible">The specified passwords do not match.</div>');

        $form_state->setError($element, $error_message_text);
      }
    }
    elseif ($element['#required'] && $form_state->getUserInput()) {
      $error_message_text = t('<div class="ui basic red pointing prompt label transition visible">Password field is required.</div>');

      $form_state->setError($element, $error_message_text);
    }

    // Password field must be converted from a two-element array into a single
    // string regardless of validation results.
    $form_state->setValueForElement($element['pass1'], NULL);
    $form_state->setValueForElement($element['pass2'], NULL);
    $form_state->setValueForElement($element, $pass1);

    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $pass = $form_state->getValue('pass');
    if (empty($pass)) {
      $error_message_text = t('<div class="ui basic red pointing prompt label transition visible">Please input your new password.</div>');
      $form_state->setErrorByName('pass', $error_message_text);
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

  public function submitResetPassword(array &$form, FormStateInterface $formState) {
    try {
      $errors = $formState->getErrors();
      if (empty($errors)) {
        $session_handler = Drupal::service('obw_social.session_handler');
        $user = $this->current_user;
        if ($user->hasField('field_account_signup_url') && !$user->field_account_signup_url->isEmpty()) {
          $signup_url = $user->field_account_signup_url->getValue()[0]['value'];
        }
        $user->setPassword($formState->getValue('pass'));
        if ($this->firstLogin) {
          $session_handler->set('syn_ac_created_account', TRUE);
        }
        $user->save();

        if (isset($_SESSION['pass_reset_' . $user->id()])) {
          unset($_SESSION['pass_reset_' . $user->id()]);
        }

        if ($this->firstLogin) {
          _user_mail_notify('status_activated', $user);
        }


        $small_text = ['#markup' => ''];
        $title = ['#markup' => ($this->firstLogin == TRUE) ? t('<h3>Password created!</h3>') : t('<h3>Password Changed</h3>')];
        $description = ['#markup' => ($this->firstLogin == TRUE) ? '<p></p>' : t('<p>Your password has been changed.</p>')];
        $button = ['#markup' => '<a class="btn button" href="' . base_path() . 'user/' . $user->id() . '/settings' . '">' . t('Complete my profile') . '</a>'];
        // Action campaign
        $submission_id = $session_handler->get('submission_id');
        $submission_nid = $session_handler->get('submission_nid');
        $url_story = $session_handler->get('url_story');
        $campaign_url = $session_handler->get('campaign_url');
        $vr_series_url = $session_handler->get('vr_series_url');
        $event_url = $session_handler->get('event_url');
        $come_back_url = $session_handler->get('come_back_url');
        $fe_url = $session_handler->get('fe_url');
        $source_param = $session_handler->get('source_param');
        $sid = $session_handler->get('sid');

        $record_id = $session_handler->get('record_id');
        $is_waitlist = $session_handler->get('is_waitlist') !== NULL ? TRUE : FALSE;
        $wl_ebook_id = $session_handler->get('wl_ebook_id');

        if ($this->firstLogin) {
          /** TODO: Handle user register via email
           *
           */
          $session_handler->set('tracking_type', 'email_register');
          $session_handler->set('user_id_tracking', $user->id());

          //TODO: check gsoty login
          $gsoty_user = User::load($user->id());
          if (isset($gsoty_user->field_gsoty_story_id) && !empty($gsoty_user->field_gsoty_story_id->getValue()[0]['value'])) {
            $title = ['#markup' => ($this->firstLogin == TRUE) ? t('<h3>Your account is ready!</h3>') : t('<h3>Password Changed</h3>')];
            $gsoty_story_id = $gsoty_user->field_gsoty_story_id->getValue()[0]['value'];
            $description = ['#markup' => ($this->firstLogin == TRUE) ? '<p></p>' : t('<p>Your password has been changed. Continue to vote!</p>')];
            $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $gsoty_story_id . '?account_created=true' . '">' . t('Return to story to vote now') . '</a>'];
            $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the story you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
          }

          if ($submission_id !== NULL) {
            $session_handler->set('existed_user', 0);
            $signup_url = str_replace('?followed_campaign=true', '', $signup_url);
            $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $signup_url . '?followed_campaign=true">' . t('Return to story that you have followed!') . '</a>'];
            $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the story you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
          }
          else {
            if ($url_story !== NULL) {
              $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $url_story . '?follow-normal-url=true">' . t('Return to story that you have followed!') . '</a>'];
              $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the story you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
              $session_handler->clear('url_story');
              $session_handler->set('is_following_normal_url', TRUE);
            }
            elseif ($campaign_url !== NULL) {
              $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $campaign_url . (!empty($source_param) ? '?source=' . $source_param : '') . '">' . t('Return to the Event page!') . '</a>'];
              $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the campaign page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
              $session_handler->clear('campaign_id');
            }
            elseif ($fe_url !== NULL) {
              if (isset($user->field_account_submit_tbt_enquiry) && !empty($user->field_account_submit_tbt_enquiry->value) && $user->field_account_submit_tbt_enquiry->value === '1') {
                if ($record_id !== NULL) {
                  $this->updateReminderRecord($record_id);
                }

                //Update submission in the Enquiry form TBT to send mail to host
                $action_service = Drupal::service('action_entity.action_service');
                $leads_domain = 'https://leads.ourbetterworld.org';
                if (strpos($fe_url, 'travel.ourbetterworld.org') === FALSE) {
                  $leads_domain = 'https://tbt-stg.ourbetterworld.org';
                }

                $url = $leads_domain . '/api/v1/lead/update';
                $headers = [
                  'Content-Type: application/json',
                ];
                $jsonData = [
                  'email' => $user->getEmail(),
                ];
                $response = $action_service->cUrlPost($url, $jsonData, $headers);
                if (!empty($response['sid'])) {
                  $fe_url .= '&sid=' . $response['sid'] . '&uid=' . $user->id() . '&action=enquiryNewAccount';
                }
                Drupal::logger('lead_notification')
                  ->info('Lead response ' . json_encode($response));
              }

              $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $fe_url . '">' . t('Return to the previous page!') . '</a>'];
              $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
              $session_handler->clear('fe_url');
            }
            elseif ($sid !== NULL) {
              $ws = Drupal\webform\Entity\WebformSubmission::load($sid);
              if ($ws) {
                if ($record_id !== NULL) {
                  $this->updateReminderRecord($record_id);
                }

                if ($is_waitlist) {
                  $path = Drupal::service('path_alias.manager')
                    ->getPathByAlias(explode('?', $ws->uri->value)[0]);
                  if (preg_match('/node\/(\d+)/', $path, $matches)) {
                    $node = Node::load($matches[1]);
                    if ($node && $node->getType() == 'event') {
                      $total_user_registered = (int) $node->field_event_number_user_register->value;
                      $node->set('field_event_number_user_register', $total_user_registered + 1);
                      $node->save();
                    }
                  }
                }

                if (!empty($ws->getWebform())) {
                  $wf = $ws->getWebform();
                  switch ($wf->get('category')) {
                    case 'Event Form':
                      $this->updateSubmissionStatus($ws);

                      if ($is_waitlist) {
                        $event_url = explode('?', $ws->uri->value)[0] . '?action=join_waitlist_old_account';
                      }
                      else {
                        $event_url = explode('?', $ws->uri->value)[0] . '?action=register_event';
                      }
                      $title = ['#markup' => t('<h3>Your account has been created!</h3>')];
                      $description = ['#markup' => t('<p>As a community member, you can now get updates on stories, join the conversation and take action more easily!</p>')];
                      $button = [
                        '#markup' => '<a class="btn button" href="' . base_path() . 'user/' . $user->id() . '/settings' . '">' . t('Complete your profile') . '</a>
                                        <a class="btn button gsoty_voting hide" style="margin-top: 12px;" href="' . $event_url . '">' . t('Return to the event page!') . '</a>',
                      ];
                      $small_text = ['#markup' => t('<p class="gsoty-small-text pt-10">You will be redirected to the event page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
                      $session_handler->clear('sid');
                      break;
                  }

                  switch ($wf->id()) {
                    case 'community_event_oct_2019':
                      $this->cloneSubmission($ws);

                      if ($is_waitlist) {
                        $event_url = explode('?', $ws->uri->value)[0] . '?action=join_waitlist_old_account';
                      }
                      else {
                        $event_url = explode('?', $ws->uri->value)[0] . '?action=register_event';
                      }
                      $title = ['#markup' => t('<h3>Your account has been created!</h3>')];
                      $description = ['#markup' => t('<p>As a community member, you can now get updates on stories, join the conversation and take action more easily!</p>')];
                      $button = [
                        '#markup' => '<a class="btn button" href="' . base_path() . 'user/' . $user->id() . '/settings' . '">' . t('Complete my profile') . '</a>
                                        <a class="btn button gsoty_voting hide" href="' . $event_url . '">' . t('Return to the event page!') . '</a>',
                      ];
                      $small_text = ['#markup' => t('<p class="gsoty-small-text pt-10">You will be redirected to the event page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
                      $session_handler->clear('sid');
                      break;
                    case 'swag_giveaway_non_account':
                      $ws_data = $ws->getData();
                      $ws_data['user_status'] = 1;
                      $ws->setData($ws_data);
                      $ws->save();
                      $description = ['#markup' => ($this->firstLogin == TRUE) ? '<p></p>' : t('<p>Your password has been changed.</p>')];
                      $button = ['#markup' => '<a class="btn button" href="' . base_path() . 'user/' . $user->id() . '/settings' . '">' . t('Complete my profile') . '</a>'];
                      break;
                    case '2020_community_event':
                      $this->cloneSubmission($ws);

                      $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $ws->uri->value . '?action=register_event">' . t('Return to the event page!') . '</a>'];
                      $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the event page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
                      $session_handler->clear('sid');
                      break;
                  }
                }
                else {
                  $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $ws->uri->value . '?action=register_event">' . t('Return to the event page!') . '</a>'];
                  $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the event page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
                  $session_handler->clear('sid');
                }
              }
            }
          }
        }
        else {
          /**Handle when user reset password to follow.*/
          if ($submission_id !== NULL && $submission_nid !== NULL) {
            $session_handler->clear('submission_nid');
            $button = ['#markup' => '<a class="btn button gsoty_voting" href="/node/' . $submission_nid . '?followed_campaign=true">' . t('Return to story that you have followed!') . '</a>'];
            $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the story you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
          }
          elseif ($url_story !== NULL) {
            $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $url_story . '?follow-normal-url=true">' . t('Return to story that you have followed!') . '</a>'];
            $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the story you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
            $session_handler->clear('url_story');
            $session_handler->set('is_following_normal_url', TRUE);
          }
          elseif ($campaign_url !== NULL) {
            $button = ['#markup' => '<a class="btn button gsoty_voting" href="/' . $campaign_url . (!empty($source_param) ? '?source=' . $source_param : '') . '">' . t('Return to the Event page!') . '</a>'];
            $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the campaign page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
            $session_handler->clear('campaign_id');
          }
          elseif ($fe_url !== NULL) {
            $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $fe_url . '">' . t('Return to the previous page!') . '</a>'];
            $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
            $session_handler->clear('fe_url');
          }
        }
        /** Handle when user register or reset password to access VR Series */
        if ($vr_series_url !== NULL) {
          $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $vr_series_url . '#series">' . t('Return to VR Series page!') . '</a>'];
          $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the VR Series page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];
          $session_handler->clear('vr_series_url');
        }

        if ($come_back_url !== NULL) {
          $url_redirect = $come_back_url;
          if (!empty($source_param)) {
            $url_redirect .= '?source=' . $source_param;
          }
          elseif (!empty($wl_ebook_id)) {
            $url_redirect .= '?ebook-id=' . $wl_ebook_id;
            setcookie('wl2021_storybook_set_password', TRUE, 0, '/');
          }

          $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $url_redirect . '">' . t('Return to the page!') . '</a>'];
          $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the page you came from in <span id="gsoty-count-down">5</span> seconds.</p>')];

          $node = $this->getNodeFromComeBackURL($session_handler->get('come_back_url'));
          if ($node && $node->getType() == 'pdf_page') {
            if ($this->firstLogin) {
              $session_handler->set('show_pdf_desc_new_user', TRUE);
            }
            $button = ['#markup' => '<a class="btn button gsoty_voting" href="' . $url_redirect . '">' . t('Download your toolkit!') . '</a>'];
            $small_text = ['#markup' => t('<p class="gsoty-small-text">You will be redirected to the toolkit page in <span id="gsoty-count-down">5</span> seconds.</p>')];
          }

          $session_handler->clear('come_back_url');
        }

        if ($this->current_user->get('field_redirect_choose_actions')->value == 1) {
          $this->current_user->set('field_redirect_choose_actions', 0);
          $this->current_user->save();
          $session_handler->clear('causes');
          $session_handler->clear('your_actions');
          $session_handler->clear('countries');
          $session_handler->clear('nid');
          $response = new AjaxResponse();
          $command = new RedirectCommand('/user/' . $this->current_user->id() . '/you-can-help-stories');
          $response->addCommand($command);
          return $response;
        }


        return [
          '#type' => 'container',
          '#attributes' => [
            'class' => [
              'user-reset-password',
              'user-action',
              'user-reset-password-complete',
              'pt-25',
            ],
          ],
          'container' => [
            '#type' => 'container',
            '#attributes' => [
              'class' => ['container'],
            ],
            'title' => $title,
            'description' => $description,
            'button' => $button,
            'small_text' => $small_text,
          ],
        ];

      }


    } catch (Exception $e) {
      Drupal::logger('obw_contributor_profile')
        ->error('Cannot save password. Message ' . $e->getMessage());

    }
    return $form;
  }

  private function updateReminderRecord($record_id) {
    $etm = Drupal::entityTypeManager();
    $session_handler = Drupal::service('obw_social.session_handler');
    $reminder_entity = $etm->getStorage('reminder_entity')->load($record_id);
    if ($reminder_entity) {
      $reminder_entity->set('field_reminder_status', 1);
      $reminder_entity->save();
    }
    $session_handler->clear('record_id');
  }

  private function getNodeFromComeBackURL($come_back_url) {
    if (preg_match('/node\/(\d+)/', $come_back_url, $matches)) {
      $etm = \Drupal::entityTypeManager();
      $node = $etm->getStorage('node')->load($matches[1]);
      if ($node) {
        return $node;
      }
    }
    return FALSE;
  }

  private function cloneSubmission($ws) {
    $ws_clone = $ws->createDuplicate();
    $ws_data = $ws_clone->getData();
    $ws_data['user_status'] = 1;
    $ws_data['submission_status'] = 1;
    $ws_clone->setData($ws_data);
    $ws_clone->setOwnerId(\Drupal::currentUser()->id());
    $ws_clone->save();
    $ws->delete();
  }

  private function updateSubmissionStatus($ws) {
    $ws_data = $ws->getData();
    $ws_data['user_status'] = 1;
    $ws_data['submission_status'] = 1;
    $ws->setData($ws_data);
    $ws->setOwnerId(\Drupal::currentUser()->id());
    $ws->save();
  }

}
