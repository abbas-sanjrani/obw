<?php

namespace Drupal\obw_contributor_profile\Form;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\obw_contributor_profile\Controller\ActiveCampaignController;
use Drupal\user\Entity\User;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * User modify newsletter field in profile
 *
 * Class ProfileSettingsForm.
 */
class ProfileNewsletterForm extends FormBase {

  /**
   * @var AccountInterface $currentUser
   */
  protected $currentUser;

  protected $entityManager;

  /**
   * ProfileSettingsForm constructor.
   *
   * @param AccountInterface $account
   */
  public function __construct(AccountInterface $account, EntityTypeManagerInterface $entityManager) {
    $this->currentUser = User::load($account->id());
    $this->entityManager = $entityManager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
    // Load the service required to construct this class.
      $container->get('current_user'),
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'obw_contributor_profile_profile_newsletter_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['group_subscribed_obw'] = [
      '#type' => 'fieldset',
      '#prefix' => '<div class="wrapper-subscribed-obw"',
      '#description' => '<span>' . t('If unchecked, you will not receive newsletter emails from Our Better World') . '</span>',
    ];
    $form['group_subscribed_obw']['field_account_news_subscribed'] = [
      '#type' => 'checkbox',
      '#title' => t('I would like to receive Our Better World’s newsletter'),
      '#default_value' => $this->currentUser->get('field_account_news_subscribed')->value,
    ];

    $entityManager = \Drupal::service('entity_field.manager');
    $fields = $entityManager->getFieldStorageDefinitions('user', 'user');
    $subscribe_obw_options = options_allowed_values($fields['field_account_subcribe_options']);

    $form['group_subscribed_obw']['field_account_subcribe_options'] = [
      '#type' => 'radios',
      '#options' => $subscribe_obw_options,
      '#default_value' => $this->currentUser->get('field_account_subcribe_options')->value,
      '#suffix' => '</div>',
    ];

    $form['field_account_newsletter_tbt'] = [
      '#type' => 'checkbox',
      '#title' => t('I would like to receive The Better Traveller newsletter'),
      '#default_value' => $this->currentUser->get('field_account_newsletter_tbt')->value,
      '#description' => '<span>' . t('If unchecked, you will not receive newsletter emails from The Better Traveller') . '</span>',
    ];

    $form['actions'] = ['#type' => 'actions'];


    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save changes'),
    ];

    $form['#theme'] = 'profile_settings_form';
    $form['#attached']['library'][] = 'obw_contributor_profile/form-scroll-to-section';
    $form['#attached']['library'][] = 'obw_contributor_profile/handler-newsletter-options';

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    //@TODO: validate form input

    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    if ($this->currentUser->get('field_account_news_subscribed')->value == $form_state->getValue('field_account_news_subscribed')
      && $this->currentUser->get('field_account_newsletter_tbt')->value == $form_state->getValue('field_account_newsletter_tbt')
      && $this->currentUser->get('field_account_subcribe_options')->value == $form_state->getValue('field_account_subcribe_options')) {
      return $form;
    }
    else {
      //      TODO: Need to remove the user out of the AC list when uncheck the subscribe newsletter
      $obw_subscribed = $form_state->getValue('field_account_news_subscribed');

      if ((int) $this->currentUser->get('field_account_news_subscribed')->value !== (int) $obw_subscribed) { // 44
        switch ($obw_subscribed) {
          case TRUE:
            $this->currentUser->set('field_account_news_subscribed', $form_state->getValue('field_account_news_subscribed'));
            break;
          case FALSE:
            $this->removeUserFromACList('obw');
            $this->currentUser->set('field_account_news_subscribed', $form_state->getValue('field_account_news_subscribed'));
            $this->currentUser->set('field_account_subcribe_options', NULL);
            break;
        }
      }

      if ($obw_subscribed && $this->currentUser->get('field_account_subcribe_options')->value !== $form_state->getValue('field_account_subcribe_options')) {
        $this->addUserToACList('obw', $form_state->getValue('field_account_subcribe_options'));
        $this->currentUser->set('field_account_subcribe_options', $form_state->getValue('field_account_subcribe_options'));
      }

      if ((int) $this->currentUser->get('field_account_newsletter_tbt')->value !== (int) $form_state->getValue('field_account_newsletter_tbt')) { // 33
        if ($form_state->getValue('field_account_newsletter_tbt') == FALSE) {
          $this->removeUserFromACList('tbt');
        }
        else {
          $this->addUserToACList('tbt');
        }
        $this->currentUser->set('field_account_newsletter_tbt', $form_state->getValue('field_account_newsletter_tbt'));
      }
    }
    $this->currentUser->save();

    return $form;
  }

  private function removeUserFromACList($type) {
    $uid = \Drupal::currentUser()->id();
    $user = \Drupal\user\Entity\User::load($uid);
    $current_email = $user->getEmail();
    $ac_controller = new ActiveCampaignController();
    $result_contact_view = $ac_controller->getACContactDetailByEmail($current_email);
    if (isset($result_contact_view['subscriberid'])) {
      if ($type === 'obw') {
        $result_contact_delete = $ac_controller->unsubscribeACContact($result_contact_view['subscriberid'], $this->currentUser->get('field_account_subcribe_options')->value);
      }
      else {
        $result_contact_delete = $ac_controller->unsubscribeACContact($result_contact_view['subscriberid'], 'tbt');
      }

      if ($result_contact_delete) {
        \Drupal::logger('obw_contributor_profile')
          ->info("Unsubscribed " . $this->currentUser->get('field_account_subcribe_options')->value . " contact with email: $current_email on active campaign");
      }
    }
  }

  private function addUserToACList($type, $option = FALSE) {
    $uid = \Drupal::currentUser()->id();
    $user = \Drupal\user\Entity\User::load($uid);
    $current_email = $user->getEmail();
    $ac_controller = new ActiveCampaignController();
    $result_contact_view = $ac_controller->getACContactDetailByEmail($current_email);
    if (isset($result_contact_view['subscriberid'])) {
      if ($type === 'obw') {
        $result_contact_delete = $ac_controller->subscribeListACContact(strtolower($option));
      }
      else {
        $result_contact_delete = $ac_controller->subscribeListACContact('tbt');
      }

      if ($result_contact_delete) {
        \Drupal::logger('obw_contributor_profile')
          ->info("Subscribed " . ($type == 'obw' ? $option : 'tbt newsletter') . " contact with email: $current_email on active campaign");
      }
    }
  }


}
