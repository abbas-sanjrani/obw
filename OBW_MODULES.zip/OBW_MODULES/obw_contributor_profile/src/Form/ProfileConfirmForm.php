<?php

namespace Drupal\obw_contributor_profile\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\form_alter_service\FormAlterBase;

/**
 *  Alter profile confirm form to add button and link
 *
 * Class ProfileConfirmForm
 *
 * @package Drupal\obw_contributor_profile\Form
 */
class ProfileConfirmForm extends FormAlterBase {


  /**
   * @param array $form
   * @param FormStateInterface $form_state
   */
  public function alterForm(array &$form, FormStateInterface $form_state) {
    $form['actions']['cancel'] = [
      '#type' => 'button',
      '#weight' => 30,
      '#value' => t('Cancel'),
      '#attributes' => ['class' => ['btn-cancel']],
      '#limit_validation_errors' => [],
    ];

    $form['#attached']['library'][] = 'obw_utilities/form_action_button';
  }


}
