<?php

namespace Drupal\obw_contributor_profile\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\user\Entity\User;
use Drupal\webform\Entity\WebformOptions;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * User modify general infomation in settings pages
 *
 * Class ProfileSettingsForm.
 */
class ProfileSettingsForm extends FormBase {

  /**
   * @var AccountInterface $currentUser
   */
  protected $currentUser;

  /**
   * ProfileSettingsForm constructor.
   *
   * @param AccountInterface $account
   */
  public function __construct(AccountInterface $account) {
    $this->currentUser = User::load($account->id());
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
    // Load the service required to construct this class.
      $container->get('current_user')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'obw_contributor_profile_profile_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['profile_photo'] = [
      '#type' => 'managed_image',
      '#field_name' => 'profile_image',
      '#upload_validators' => [
        'file_validate_extensions' => ['gif png jpg jpeg'],
        'file_validate_size' => [25600000],
      ],
      '#preview_image_style' => 'thumbnail',
      '#upload_location' => 'public://',
      '#image_style' => 'thumbnail_48_48_',
    ];

    if (!empty($this->currentUser->get('user_picture')->target_id)) {
      $form['profile_photo']['#default_value'][] = $this->currentUser->get('user_picture')->target_id;
      $form['profile_photo']['#attributes'] = ['class' => ['uploaded']];
    }

    $form['salutation_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['form-item-full']],
    ];

    $element = ['#options' => 'salutation'];
    $options = WebformOptions::getElementOptions($element);
    $form['salutation_wrapper']['field_account_salutation'] = [
      '#type' => 'select',
      '#options' => $options,
      '#title' => $this->t('Salutation'),
      '#default_value' => $this->currentUser->get('field_account_salutation')->value,
    ];

    $form['field_account_first_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('First name'),
      '#required' => TRUE,
      '#default_value' => $this->currentUser->get('field_account_first_name')->value,
      '#maxlength' => 20,
    ];
    $form['field_account_last_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Last name'),
      '#required' => TRUE,
      '#default_value' => $this->currentUser->get('field_account_last_name')->value,
      '#maxlength' => 20,
    ];

    $form['profession_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['form-item-full']],
    ];
    $form['profession_wrapper']['field_account_profession'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Profession'),
      '#default_value' => $this->currentUser->get('field_account_profession')->value,
    ];

    $form['mail'] = [
      '#type' => 'email',
      '#title' => $this->t('Email address'),
      '#default_value' => $this->currentUser->getEmail(),
      '#disabled' => TRUE,
    ];

    $form['field_account_contact_number'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Contact number'),
      '#default_value' => $this->currentUser->get('field_account_contact_number')->value,
      '#validated' => TRUE,  // Important - skip default validation.
    ];

    $element = ['#options' => 'country_names'];
    $options = WebformOptions::getElementOptions($element);
    $options = ['-1' => 'Select Country'] + $options;
    $form['field_account_residence'] = [
      '#type' => 'select',
      '#options' => $options,
      '#title' => $this->t('Country of residence'),
      '#default_value' => $this->currentUser->get('field_account_residence')->value,
      '#id' => 'country',
    ];

    $form['field_account_city_of_residence'] = [
      '#type' => 'textfield',
      '#title' => $this->t('City'),
      '#default_value' => $this->currentUser->get('field_account_city_of_residence')->value,
    ];

    $element = ['#options' => 'nationality'];
    $options = WebformOptions::getElementOptions($element);
    $options = ['-1' => 'Select Nationality'] + $options;
    $form['field_account_nationality'] = [
      '#type' => 'select',
      '#options' => $options,
      '#title' => $this->t('Nationality'),
      '#default_value' => $this->currentUser->get('field_account_nationality')->value,
    ];

    $form['field_account_street_address'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Street Address'),
      '#default_value' => $this->currentUser->get('field_account_street_address')->value,
    ];

    $form['field_account_street_address_2'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Street Address 2'),
      '#default_value' => $this->currentUser->get('field_account_street_address_2')->value,
    ];

    $form['field_account_postal_code'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Postal Code'),
      '#default_value' => $this->currentUser->get('field_account_postal_code')->value,
    ];

    $form['submit_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['form-item-full']],
    ];
    $form['actions'] = [
      '#type' => 'actions',
      '#attributes' => ['class' => ['form-item-full']],
    ];
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save changes'),
    ];

    $form['#theme'] = 'profile_settings_form';

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    //@TODO: validate form input

    parent::validateForm($form, $form_state);

    $value_number_phone = $form_state->getValue('field_account_contact_number');

    if ($value_number_phone !== '') {
      $pattern = '/^[0-9-\+]+$/';
      if (!preg_match($pattern, $value_number_phone)) {
        $form_state->setErrorByName('field_account_contact_number', t('Please enter the number.'));
      }
    }

    $formCity = $form['field_account_city_of_residence'];
    $value = $form_state->getValue('field_account_city_of_residence');
    if ($value !== '') {
      // Todo: remove validate field "city" to pass value was selected
      if (!is_null($form_state->getError($formCity))) {
        $form_errors = $form_state->getErrors();
        $form_state->clearErrors();
        unset($form_errors['field_account_city_of_residence']);
        foreach ($form_errors as $name => $error_message) {
          $form_state->setErrorByName($name, $error_message);
        }
      }
    }
  }

  public function settingsFormSubmit(array &$form, FormStateInterface $form_state) {

    $response = new AjaxResponse();
    try {
      $this->currentUser->set('field_account_first_name', $form_state->getValue('field_account_first_name'));
      $this->currentUser->set('field_account_last_name', $form_state->getValue('field_account_last_name'));
      $this->currentUser->set('field_account_city_of_residence', $form_state->getValue('field_account_city_of_residence'));
      $this->currentUser->set('field_account_nationality', $form_state->getValue('field_account_nationality'));
      $this->currentUser->set('field_account_salutation', $form_state->getValue('field_account_salutation'));
      $this->currentUser->set('field_account_residence', $form_state->getValue('field_account_residence'));
      $this->currentUser->set('field_account_contact_number', $form_state->getValue('field_account_contact_number'));
      $this->currentUser->set('field_account_profession', $form_state->getValue('field_account_profession'));
      $this->currentUser->set('field_account_street_address', $form_state->getValue('field_account_street_address'));
      $this->currentUser->set('field_account_street_address_2', $form_state->getValue('field_account_street_address_2'));
      $this->currentUser->set('field_account_postal_code', $form_state->getValue('field_account_postal_code'));
      $this->currentUser->save();
    } catch (\Exception $e) {

      throw new \Exception('Cannot update profile settings, message: ' . $e->getMessage());
    }

    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $this->currentUser->set('field_account_first_name', $form_state->getValue('field_account_first_name'));
    $this->currentUser->set('field_account_last_name', $form_state->getValue('field_account_last_name'));
    $this->currentUser->set('field_account_city_of_residence', $form_state->getValue('field_account_city_of_residence'));
    $this->currentUser->set('field_account_nationality', $form_state->getValue('field_account_nationality'));
    $this->currentUser->set('user_picture', $form_state->getValue('profile_photo'));
    $this->currentUser->set('field_account_salutation', $form_state->getValue('field_account_salutation'));
    $this->currentUser->set('field_account_residence', $form_state->getValue('field_account_residence'));
    $this->currentUser->set('field_account_contact_number', $form_state->getValue('field_account_contact_number'));
    $this->currentUser->set('field_account_profession', $form_state->getValue('field_account_profession'));
    $this->currentUser->set('field_account_street_address', $form_state->getValue('field_account_street_address'));
    $this->currentUser->set('field_account_street_address_2', $form_state->getValue('field_account_street_address_2'));
    $this->currentUser->set('field_account_postal_code', $form_state->getValue('field_account_postal_code'));
    $this->currentUser->save();

  }

}
