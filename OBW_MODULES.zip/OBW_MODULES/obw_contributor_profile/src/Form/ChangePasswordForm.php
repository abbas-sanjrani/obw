<?php
/**
 * Created by PhpStorm.
 * User: leopham
 * Date: 9/5/18
 * Time: 10:48 AM
 */

namespace Drupal\obw_contributor_profile\Form;

use Drupal\Component\Utility\Crypt;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Password\PasswordInterface;
use Drupal\Core\Render\Element\PasswordConfirm;
use Drupal\Core\Session\AccountInterface;
use Drupal\user\UserInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;


/**
 * Provides a user password reset form.
 */
class ChangePasswordForm extends FormBase {

  /**
   * The account the shortcut set is for.
   *
   * @var \Drupal\user\UserInterface
   */
  //protected $user;

  /**
   * The Password Hasher.
   *
   * @var \Drupal\Core\Password\PasswordInterface;
   */
  protected $password_hasher;

  /**
   * Constructs a UserPasswordForm object.
   *
   * @param \Drupal\Core\Password $password_hasher
   *   The password hasher.
   * @param \Drupal\Core\Session $account
   *   The account.
   */
  public function __construct(PasswordInterface $password_hasher, AccountInterface $account) {
    $this->password_hasher = $password_hasher;
    $this->account = $account;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('password'),
      $container->get('current_user')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'profile_settings_change_password_form';
  }

  /**
   * {@inheritdoc}
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The request object.
   */
  public function buildForm(array $form, FormStateInterface $form_state, UserInterface $user = NULL) {
    /** @var \Drupal\user\UserInterface $account */
    $this->user_profile = $account = $user;
    $user = $this->currentUser();
    $config = \Drupal::config('user.settings');
    $form['#cache']['tags'] = $config->getCacheTags();

    $language_interface = \Drupal::languageManager()->getCurrentLanguage();
    $register = $account->isAnonymous();
    $admin = $user->hasPermission('administer users');

    // Account information.
    $form['account'] = [
      '#type' => 'container',
      '#weight' => -10,
      '#attributes' => [
        'class' => [
          'form-item-full',
        ],
      ],
    ];
    // Display password field only for existing users or when user is allowed to
    // assign a password during registration.
    if (!$register) {
      $form['account']['pass'] = [
        '#type' => 'password_confirm',
        '#size' => 25,
        '#required' => TRUE,
      ];

      // To skip the current password field, the user must have logged in via a
      // one-time link and have the token in the URL. Store this in $form_state
      // so it persists even on subsequent Ajax requests.
      if (!$form_state->get('user_pass_reset') && ($token = $this->getRequest()
          ->get('pass-reset-token'))) {
        $session_key = 'pass_reset_' . $account->id();
        $user_pass_reset = isset($_SESSION[$session_key]) && Crypt::hashEquals($_SESSION[$session_key], $token);
        $form_state->set('user_pass_reset', $user_pass_reset);
      }

      // The user must enter their current password to change to a new one.
      if ($user->id() == $account->id()) {
        $form['account']['current_pass'] = [
          '#type' => 'password',
          '#title' => $this->t('Current password'),
          '#size' => 25,
          '#access' => !$form_state->get('user_pass_reset'),
          '#weight' => -5,
          // Do not let web browsers remember this password, since we are
          // trying to confirm that the person submitting the form actually
          // knows the current one.
          '#attributes' => ['autocomplete' => 'off'],
          '#required' => TRUE,
        ];
        $form_state->set('user', $account);
      }
    }
    $form['account']['pass']['#process'][] = [$this, 'processPasswordField'];
    $form['actions'] = ['#type' => 'actions'];
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save changes'),
    ];
    $form['#theme'] = 'profile_settings_form';

    return $form;
  }

  function processPasswordField($element, FormStateInterface $form_state, &$complete_form) {
    $element = PasswordConfirm::processPasswordConfirm($element, $form_state, $complete_form);

    $element['pass1']['#title'] = t('New Password');
    $element['pass2']['#title'] = t('Confirm New Password');
    $element['#element_validate'][] = [$this, 'validatePasswordStrength'];
    return $element;
  }

  public static function validatePasswordStrength(&$element, FormStateInterface $form_state, &$complete_form) {
    $pass1 = trim($element['pass1']['#value']);
    $uppercase = preg_match('@[A-Z]@', $pass1);
    $lowercase = preg_match('@[a-z]@', $pass1);
    $number = preg_match('@[0-9]@', $pass1);

    if (!$uppercase || !$lowercase || !$number || strlen($pass1) < 8) {
      $form_state->setError($element, t('<div class="ui basic red pointing prompt label transition visible">Password needs to include lowercase, uppercase, number and be at least 8 characters long.</div>'));
    }


    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $current_pass_input = trim($form_state->getValue('current_pass'));
    if ($current_pass_input) {
      $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
      if (!$this->password_hasher->check($current_pass_input, $user->getPassword())) {
        $form_state->setErrorByName('current_pass', $this->t('The current password you provided is incorrect.'));
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    //@TODO add ajax to this form

    $user = \Drupal\user\Entity\User::load($this->user_profile->id());
    $user->setPassword($form_state->getValue('pass'));
    $user->save();

    \Drupal::messenger()->addMessage(t('Your password has been changed.'), 'status');
  }

}
