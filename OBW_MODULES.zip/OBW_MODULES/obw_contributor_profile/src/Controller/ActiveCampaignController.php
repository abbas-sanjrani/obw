<?php
/**
 * Created by PhpStorm.
 * User: TRI_TRAN
 * Date: 19-Aug-19
 * Time: 6:21 PM
 */

namespace Drupal\obw_contributor_profile\Controller;

class ActiveCampaignController {

  private $ac_url_request;

  private $api_key;

  private $ac_list_id_weekly;

  private $ac_list_id_monthly;

  private $ac_list_id_tbt;

  public function __construct() {
    $config = \Drupal::config('obw_contributor_profile.config');
    $this->api_key = $config->get('AC_API_KEY');
    $this->ac_url_request = $config->get('AC_URL_REQUEST');
    $this->ac_list_id_weekly = $config->get('AC_LIST_ID_WEEKLY_FOR_OBW');
    $this->ac_list_id_monthly = $config->get('AC_LIST_ID_MONTHLY_FOR_OBW');
    $this->ac_list_id_tbt = $config->get('AC_LIST_ID_FOR_TBT');
  }

  public function unsubscribeACContact($subscriberid, $option = 'weekly') {
    if ($option === 'tbt') {
      $ac_list_id = $this->ac_list_id_tbt;
    }
    else {
      $ac_list_id = $option === 'weekly' ? $this->ac_list_id_weekly : $this->ac_list_id_monthly;
    }
    $params = [
      'api_key' => $this->api_key,
      'api_action' => 'contact_delete',
      'api_output' => 'serialize',
      'id' => $subscriberid,
      'listids[' . $ac_list_id . ']' => $ac_list_id,
    ];
    $result = $this->requestServerActiveCampaign($params);
    if (isset($result['result_code']) && (!$result['result_code'])) {
      \Drupal::logger('obw_contributor_profile')->info('unsubscribeACContact:
     Result code FAILED. Message: ' . $result['result_message']);
    }
    return $result;
  }


  public function subscribeListACContact($option = 'weekly') {
    if ($option === 'tbt') {
      $ac_list_id = $this->ac_list_id_tbt;
    }
    else {
      $ac_list_id = $option === 'weekly' ? $this->ac_list_id_weekly : $this->ac_list_id_monthly;
    }
    $params = [
      'api_key' => $this->api_key,
      'api_action' => 'contact_sync',
      'api_output' => 'serialize',
    ];

    $post = [
      'email' => \Drupal::currentUser()->getEmail(),
      'p[' . $ac_list_id . ']' => $ac_list_id,
      'status[' . $ac_list_id . ']' => 1,
    ];

    $result = $this->requestServerActiveCampaign($params, $post);

    if (isset($result['result_code']) && (!$result['result_code'])) {
      \Drupal::logger('obw_contributor_profile')->info('subscribeACContact:
     Result code FAILED. Message: ' . $result['result_message']);
      return FALSE;
    }
    return $result;
  }

  /**
   * @param $email
   *
   * @return bool|mixed
   */
  public function getACContactDetailByEmail($email) {
    $params = [
      'api_key' => $this->api_key,
      'api_action' => 'contact_view_email',
      'api_output' => 'serialize',
      'email' => $email,
    ];
    $result = $this->requestServerActiveCampaign($params);
    if (isset($result['result_code']) && (!$result['result_code'])) {
      \Drupal::logger('obw_contributor_profile')->info('getACContactDetailByEmail:
     Result code FAILED. Message: ' . $result['result_message']);
    }
    return $result;
  }

  /**
   * @param $params
   *
   * @return bool|mixed
   */
  public function requestServerActiveCampaign($params, $post_data = []) {
    $url = $this->ac_url_request;
    $query = "";

    foreach ($params as $key => $value) {
      $query .= urlencode($key) . '=' . urlencode($value) . '&';
    }
    $query = rtrim($query, '& ');

    // clean up the url
    $url = rtrim($url, '/ ');

    // This sample code uses the CURL library for php to establish a connection,
    // submit your request, and show (print out) the response.
    if (!function_exists('curl_init')) {
      \Drupal::logger('obw_contributor_profile')->error('requestServerActiveCampaign:
       CURL not supported. (introduced in PHP 4.0.2)');
      return FALSE;
    }

    // If JSON is used, check if json_decode is present (PHP 5.2.0+)
    if ($params['api_output'] == 'json' && !function_exists('json_decode')) {
      \Drupal::logger('obw_contributor_profile')->error('requestServerActiveCampaign:
       JSON not supported. (introduced in PHP 5.2.0)');
      return FALSE;
    }

    // define a final API request - GET
    $api = $url . '/admin/api.php?' . $query;
    $request = curl_init($api); // initiate curl object
    curl_setopt($request, CURLOPT_HEADER, 0); // set to 0 to eliminate header info from response
    curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); // Returns response data instead of TRUE(1)
    if (!empty($post_data)) {
      $data = "";
      if (is_array($post_data)) {
        foreach ($post_data as $key => $value) {
          $data .= urlencode($key) . '=' . urlencode($value) . '&';
        }
        $data = rtrim($data, '& ');
      }
      elseif (is_string($post_data)) {
        $data = $post_data;
      }

      curl_setopt($request, CURLOPT_POSTFIELDS, $data); // use HTTP POST to send form data
    }
    //curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE); // uncomment if you get no gateway response and are using HTTPS
    curl_setopt($request, CURLOPT_FOLLOWLOCATION, TRUE);

    $response = (string) curl_exec($request); // execute curl fetch and store results in $response

    // additional options may be required depending upon your server configuration
    // you can find documentation on curl options at http://www.php.net/curl_setopt
    curl_close($request); // close curl object

    if (!$response) {
      \Drupal::logger('obw_contributor_profile')->error('requestServerActiveCampaign:
       Nothing was returned. Do you have a connection to Email Marketing server?');
      return FALSE;
    }
    return unserialize($response);
  }

  public function addTagToACContact($email, $tags = []) {
    $post_data = '';
    $params = [
      'api_key' => $this->api_key,
      'api_action' => 'contact_tag_add',
      'api_output' => 'serialize',
    ];

    $post_data .= urlencode('email') . '=' . urlencode($email) . '&';

    foreach ($tags as $tag) {
      $post_data .= urlencode('tags[]') . '=' . urlencode($tag) . '&';
    }
    $post_data = rtrim($post_data, '&');

    $sync_ac_tags = $this->requestServerActiveCampaign($params, $post_data);
    return $sync_ac_tags;
  }

  public function isTagNameExistInAcContact($email, $tag_name) {
    if (empty($email) || empty($tag_name)) {
      return FALSE;
    }
    $ac_response = $this->getACContactDetailByEmail($email);

    if (empty($ac_response['tags']) || in_array($tag_name, $ac_response['tags']) == FALSE) {
      return FALSE;
    }

    return TRUE;
  }

}
