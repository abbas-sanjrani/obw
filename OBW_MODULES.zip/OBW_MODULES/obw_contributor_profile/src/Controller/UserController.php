<?php
/**
 * Created by PhpStorm.
 * User: leopham
 * Date: 10/18/18
 * Time: 9:51 AM
 */

namespace Drupal\obw_contributor_profile\Controller;


use Drupal;
use Drupal\Component\Utility\Crypt;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;
use Drupal\obw_action_entity\Controller\ActionEntityController;
use Drupal\user\UserInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class UserController extends \Drupal\user\Controller\UserController {

  public function resetPass(Request $request, $uid, $timestamp, $hash) {
    $session_handler = Drupal::service('obw_social.session_handler');
    $query = Drupal::request()->query;
    /**ACTION CAMPAIGN: Get params in the url when register to follow story.*/
    $submission_id = $query->get('submission_id');
    $submission_nid = $query->get('nid');
    $url_story = $query->get('url_story');
    $campaign_url = $query->get('campaign_id');
    $vr_series_url = $query->get('vr_series_url');
    $event_url = $query->get('event_url');
    $come_back_url = $query->get('come_back_url');
    $source = $query->get('source');
    $fe_url = $query->get('fe_url');
    $sid = $query->get('sid');
    $record_id = $query->get('record_id');
    $waitlist = $query->get('waitlist');
    $handler_id = $query->get('handler_id');
    $email = $query->get('email_user');
    $wl_ebook_id = $query->get('wl_ebook_id');

    if ($submission_id !== NULL) {
      $session_handler->set('submission_id', $submission_id);
    }

    if ($submission_nid !== NULL) {
      $session_handler->set('submission_nid', $submission_nid);
    }

    if ($url_story !== NULL) {
      $session_handler->set('url_story', $url_story);
    }

    if ($campaign_url !== NULL) {
      $session_handler->set('campaign_url', $campaign_url);
      if ($source) {
        $session_handler->set('source_param', $source);
      }
    }

    if ($vr_series_url !== NULL) {
      $session_handler->set('vr_series_url', $vr_series_url);
    }

    if ($event_url !== NULL) {
      $session_handler->set('event_url', $event_url);
      if ($source) {
        $session_handler->set('source_param', $source);
      }
    }

    if ($come_back_url !== NULL) {
      $session_handler->set('come_back_url', $come_back_url);
      if ($source) {
        $session_handler->set('source_param', $source);
      }
      if ($wl_ebook_id) {
        $session_handler->set('wl_ebook_id', $wl_ebook_id);
      }
    }

    if ($fe_url !== NULL) {
      if (strpos($fe_url, '?') !== FALSE) {
        foreach ($query->all() as $key => $param) {
          if ($key == 'fe_url') {
            continue;
          }
          $fe_url .= '&' . $key . '=' . rawurlencode($param);
        }
        $fe_url .= '&login=true';
      }
      else {
        $index = 0;
        foreach ($query->all() as $key => $param) {
          if ($key == 'fe_url' || $key == 'record_id') {
            continue;
          }
          if ($index === 0) {
            $fe_url .= '?' . $key . '=' . rawurlencode($param);
          }
          else {
            $fe_url .= '&' . $key . '=' . rawurlencode($param);
          }
          $index++;
        }

        if (strpos($fe_url, '?') !== FALSE) {
          $fe_url .= '&login=true';
        }
        else {
          $fe_url .= '?login=true';
        }
      }
      $session_handler->set('fe_url', $fe_url);
    }

    if ($sid !== NULL) {
      $session_handler->set('sid', $sid);
    }

    if ($record_id !== NULL) {
      $session_handler->set('record_id', $record_id);
    }

    if ($waitlist !== NULL) {
      $session_handler->set('is_waitlist', TRUE);
    }

    if ($handler_id !== NULL) {
      $session_handler->set('handler_id', $handler_id);
    }

    if ($email !== NULL) {
      $session_handler->set('email_user', $email);
    }

    $account = $this->currentUser();
    // When processing the one-time login link, we have to make sure that a user
    // isn't already logged in.
    if ($account->isAuthenticated()) {
      // The current user is already logged in.
      if ($account->id() == $uid) {
        user_logout();
        // We need to begin the redirect process again because logging out will
        // destroy the session.
        return $this->redirect(
          'user.reset',
          [
            'uid' => $uid,
            'timestamp' => $timestamp,
            'hash' => $hash,
          ]
        );
      }
      // A different user is already logged in on the computer.
      else {
        /** @var UserInterface $reset_link_user */
        if ($reset_link_user = $this->userStorage->load($uid)) {
          \Drupal::messenger()
            ->addWarning($this->t('Another user (%other_user) is already logged into the site on this computer, but you tried to use a one-time link for user %resetting_user. Please <a href=":logout">log out</a> and try using the link again.',
              [
                '%other_user' => $account->getAccountName(),
                '%resetting_user' => $reset_link_user->getAccountName(),
                ':logout' => $this->redirect('user.logout'),
              ]));
        }
        else {
          // Invalid one-time link specifies an unknown user.
          \Drupal::messenger()
            ->addError($this->t('The one-time login link you clicked is invalid.'));
        }
        return $this->redirect('<front>');
      }
    }

    $session = $request->getSession();
    $session->set('pass_reset_hash', $hash);
    $session->set('pass_reset_timeout', $timestamp);
    return $this->redirect(
      'user.reset.login',
      [
        'uid' => $uid,
        'timestamp' => $timestamp,
        'hash' => $hash,
      ]
    );
  }


  public function resetPassLogin($uid, $timestamp, $hash) {

    // The current user is not logged in, so check the parameters.
    $current = \Drupal::time()->getRequestTime();
    /** @var UserInterface $user */
    $user = $this->userStorage->load($uid);

    // Verify that the user exists and is active.
    if ($user === NULL || !$user->isActive()) {
      // Blocked or invalid user ID, so deny access. The parameters will be in
      // the watchdog's URL for the administrator to check.
      throw new AccessDeniedHttpException();
    }
    $session = Drupal::service('obw_social.session_handler');

    // Time out, in seconds, until login URL expires.
    $timeout = $this->config('user.settings')->get('password_reset_timeout');
    // No time out for first time login.
    if ($user->getLastLoginTime() && $current - $timestamp > $timeout) {
      $session->set('onetime_login_link_error', $this->t('You have tried to use a one-time login link that has expired. Please request a new one using the form below.'));
      \Drupal::messenger()
        ->addError($this->t('You have tried to use a one-time login link that has expired. Please request a new one using the form below.'));
      return $this->redirect('user.pass');
    }
    elseif ($user->isAuthenticated() && ($timestamp >= $user->getLastLoginTime()) && ($timestamp <= $current) && hash_equals($hash, user_pass_rehash($user, $timestamp))) {
      user_login_finalize($user);
      $session_handler = Drupal::service('obw_social.session_handler');
      if (!Drupal::currentUser()
          ->isAnonymous() && (($session_handler->get('submission_id') !== NULL && $session_handler->get('submission_nid') !== NULL) || $session_handler->get('url_story') !== NULL)) {
        if ($session_handler->get('submission_nid') !== NULL) {
          $node = Node::load($session_handler->get('submission_nid'));
        }
        else {
          $path = Drupal::service('path_alias.manager')
            ->getPathByAlias($session_handler->get('url_story'));
          if (preg_match('/node\/(\d+)/', $path, $matches)) {
            $node = Node::load($matches[1]);
          }
        }
        $params_action = $this->getParamsAction($node);
        if ($params_action !== FALSE) {
          $action_entity_controller = new ActionEntityController();
          $follow_status = $action_entity_controller->isUserActed($params_action, 'follow');

          if ($follow_status['is_acted'] === FALSE) {
            $action_entity_controller->actionEntity('follow', $params_action);
          }
          if ($session_handler->get('followed_via_email') !== NULL && $session_handler->get('submission_id') !== NULL && $session_handler->get('submission_nid') !== NULL) {
            if (self::loginHistory() == FALSE) {
              $session_handler->set('existed_user', 0);
            }
            else {
              $session_handler->set('existed_user', 1);
            }
            $followAction = Drupal::service('obw_action_campaign.follow_action');
            $followAction->followStory();
          }
        }
      }
      $this->logger->notice('User %name used one-time login link at time %timestamp.', [
        '%name' => $user->getDisplayName(),
        '%timestamp' => $timestamp,
      ]);
      Drupal::messenger()
        ->addMessage($this->t('You have just used your one-time login link. It is no longer necessary to use this link to log in. Please change your password.'));
      // Let the user's password be changed without the current password
      // check.
      $token = Crypt::randomBytesBase64(55);
      $_SESSION['pass_reset_' . $user->id()] = $token;
      return $this->redirect(
        'obw_contributor_profile.user_reset_password_form',
        ['user' => $user->id()],
        [
          'query' => ['pass-reset-token' => $token],
          'absolute' => TRUE,
        ]
      );
    }
    $session_handler = Drupal::service('obw_social.session_handler');
    if ($session_handler->get('come_back_url') !== NULL) {
      $come_back_url = $session_handler->get('come_back_url');
      if (preg_match('/node\/(\d+)/', $come_back_url, $matches)) {
        $session_handler->clear('come_back_url');
        $etm = \Drupal::entityTypeManager();
        $node = $etm->getStorage('node')->load($matches[1]);
        if ($node) {
          if ($node->getType() == 'pdf_page') {
            if ($session_handler->get('email_user') !== NULL) {
              $email_user = $session_handler->get('email_user');
              $session_handler->clear('email_user');
              return new RedirectResponse($come_back_url . '?login=true&email=' . $email_user, '301');
            }
            else {
              return new RedirectResponse($come_back_url . '?login=true', '301');
            }
          }
        }
      }
    }

    Drupal::logger('obw_contributor_profile')
      ->debug('timeout: redirect to user password form');

    $session->set('onetime_login_link_error', $this->t('You have tried to use a one-time login link that has either been used or is no longer valid. Please request a new one using the form below.'));

    \Drupal::messenger()
      ->addError($this->t('You have tried to use a one-time login link that has either been used or is no longer valid. Please request a new one using the form below.'));
    return $this->redirect('user.pass');
  }

  public function getParamsAction($node) {
    global $base_url;
    $current_user = Drupal::currentUser();
    if ($node instanceof Node) {
      $params_request = [
        'obj_title' => $node->getTitle(),
        'obj_url' => $node->toUrl()->toString(),
        'obj_type' => 'node',
        'obj_subtype' => $node->getType(),
        'obj_id' => $node->id(),
      ];
    }
    else {
      return FALSE;
    }
    $params_request['site_domain'] = $base_url;
    $params_request['user_id'] = $current_user->id();

    return $params_request;
  }

  public function batchSubscribeWeekly() {
    $etm = Drupal::entityTypeManager();
    $users = $etm->getStorage('user')->loadByProperties([
      'field_account_news_subscribed' => 1,
      'status' => 1,
    ]);
    $operations = [];
    foreach ($users as $user) {
      if (!isset($user->field_account_subcribe_options) || (isset($user->field_account_subcribe_options) && empty($user->field_account_subcribe_options->value))) {
        $operations[] = [
          '\Drupal\obw_contributor_profile\Controller\UserController::setSubscribeWeekly',
          [$user],
        ];
      }
    }

    $batch = [
      'title' => t('Set weekly option default for the existing users who are already subscribed'),
      'operations' => $operations,
      'finished' => '\Drupal\obw_contributor_profile\Controller\UserController::batchFinishedCallback',
    ];
    batch_set($batch);
    return batch_process('<front>');
  }

  public static function setSubscribeWeekly($user, &$context) {
    $msg = 'Setting default value for the uid: ' . $user->id();
    $user->set('field_account_subcribe_options', 'weekly');
    $user->save();
    $context['message'] = $msg;
    $context['results'][] = $user;
  }

  public static function batchUpdateSourceURL() {
    $etm = Drupal::entityTypeManager();
    $users = $etm->getStorage('user')->loadByProperties([
      'field_account_signup_url' => '/node',
      'status' => 1,
    ]);

    $operations = [];
    foreach ($users as $user) {
      $operations[] = [
        '\Drupal\obw_contributor_profile\Controller\UserController::setSourceURL',
        [$user],
      ];
    }

    $batch = [
      'title' => t('Update source url from /node -> /homepage'),
      'operations' => $operations,
      'finished' => '\Drupal\obw_contributor_profile\Controller\UserController::batchFinishedCallback',
    ];
    batch_set($batch);
    return batch_process('<front>');
  }

  public static function setSourceURL($user, &$context) {
    $msg = 'Updating source url for the uid: ' . $user->id() . '<br />';
    $user->set('field_account_signup_url', '/homepage');
    $user->save();
    $context['message'] = $msg;
    $context['results'][] = $user;
  }

  public static function batchFinishedCallback($success, $results, $operations) {
    if ($success) {
      // Do something else if needed.
      $message = t('Batch operation success.');
    }
    else {
      $message = t('There were some errors.');
    }

    Drupal::messenger($message);
  }

  public function batchSyncTBTUserToAC() {
    $etm = Drupal::entityTypeManager();
    $query = $etm->getStorage('user')->getQuery()
      ->condition('field_account_signup_source', 'TBT |', 'CONTAINS')
      ->condition('status', 1);
    $uids = $query->execute();
    $tbt_users = $etm->getStorage('user')->loadMultiple($uids);

    $operations = [];
    foreach ($tbt_users as $tbt_user) {
      $operations[] = [
        '\Drupal\obw_contributor_profile\Controller\UserController::reSaveTBTUser',
        [$tbt_user],
      ];
    }

    $batch = [
      'title' => t('Resaving TBT user to sync AC'),
      'operations' => $operations,
      'finished' => '\Drupal\obw_contributor_profile\Controller\UserController::reSaveTBTUserFinishedCallback',
    ];
    batch_set($batch);
    return batch_process('<front>');
  }

  public static function reSaveTBTUser($user, &$context) {
    $msg = 'Resaving TBT user: ' . $user->id();
    $user->save();
    $context['message'] = $msg;
    $context['results'][] = $user;
  }

  public static function reSaveTBTUserFinishedCallback($success, $results, $operations) {
    if ($success) {
      // Do something else if needed.
      $message = t('Resave successful TBT user!');
    }
    else {
      $message = t('There were some errors.');
    }
    \Drupal::messenger()->addMessage($message);
  }

  public static function loginHistory(AccountInterface $account = NULL): bool {
    if (!$account) {
      $account = \Drupal::currentUser();
    }
    if ($account->isAnonymous()) {
      return FALSE;
    }

    return \Drupal::database()->select('login_history', 'lh')
      ->fields('lh', ['login', 'hostname', 'one_time', 'user_agent'])
      ->condition('uid', $account->id())
      ->orderBy('login', 'DESC')
      ->range(0, 1)
      ->execute()
      ->fetch();
  }

}
