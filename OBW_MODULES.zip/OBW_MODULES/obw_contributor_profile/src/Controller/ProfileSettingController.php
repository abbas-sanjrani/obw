<?php

namespace Drupal\obw_contributor_profile\Controller;

use Drupal\bootstrap\Utility\Crypt;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Datetime\DateFormatterInterface;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Url;
use Drupal\user\Entity\User;
use Drupal\user\UserDataInterface;
use Drupal\user\UserStorageInterface;
use Drupal\webform\Entity\WebformSubmission;
use Psr\Log\LoggerInterface;
use Stripe\Customer;
use Stripe\Stripe;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;


/**
 * Class ProfileSettingController.
 */
class ProfileSettingController extends ControllerBase {

  protected $currentUser;

  protected $formBuilder;

  protected $linkGenerator;


  /**
   * The date formatter service.
   *
   * @var \Drupal\Core\Datetime\DateFormatterInterface
   */
  protected $dateFormatter;

  /**
   * The user storage.
   *
   * @var \Drupal\user\UserStorageInterface
   */
  protected $userStorage;

  /**
   * The user data service.
   *
   * @var \Drupal\user\UserDataInterface
   */
  protected $userData;

  /**
   * A logger instance.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;


  /**
   * Constructs a new ProfileSettingController object.
   *
   * @param AccountInterface $account
   * @param FormBuilderInterface $form_builder
   * @param $link_generator
   */
  public function __construct(AccountInterface $account, FormBuilderInterface $form_builder, $link_generator, DateFormatterInterface $date_formatter, UserStorageInterface $user_storage, UserDataInterface $user_data, LoggerInterface $logger) {
    $this->currentUser = $account;
    $this->formBuilder = $form_builder;
    $this->linkGenerator = $link_generator;
    $this->dateFormatter = $date_formatter;
    $this->userStorage = $user_storage;
    $this->userData = $user_data;
    $this->logger = $logger;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
    // Load the service required to construct this class.
      $container->get('current_user'),
      $container->get('form_builder'),
      $container->get('link_generator'),
      $container->get('date.formatter'),
      $container->get('entity_type.manager')->getStorage('user'),
      $container->get('user.data'),
      $container->get('logger.factory')->get('user')
    );
  }

  /**
   * Settings.
   *
   * @param User $user
   *
   * @return array Return template array.
   * Return template array.
   */
  public function settings(User $user, string $position) {

    if ($user->id() != $this->currentUser->id()) {
      //If current user is admin, we will redirect to backend edit page
      return new RedirectResponse('/user/' . $user->id() . '/edit');
    }

    $user = User::load($this->currentUser->id());
    //Check social user login not to show password in account settings page
    // if user associate with social, he is not have check accept tnc value
    $result = \Drupal::entityTypeManager()
      ->getStorage('social_auth')
      ->loadByProperties([
        'user_id' => $user->id(),
      ]);

    $test_tnc = $user->get('field_account_accept_tnc')->getValue()[0]['value'];
    $change_pass_form =
      $this->formBuilder->getForm('\Drupal\obw_contributor_profile\Form\ChangePasswordForm',
        User::load($this->currentUser->id()));

    if (!empty($result) && !$test_tnc) {
      $change_pass_form = '';
    }

    return [
      '#theme' => 'profile_settings_page',
      '#content' => [
        'profile_settings_form' => $this->formBuilder->getForm('\Drupal\obw_contributor_profile\Form\ProfileSettingsForm'),
        'change_password_form' => $change_pass_form,
        'profile_newsletter_form' => $this->formBuilder->getForm('\Drupal\obw_contributor_profile\Form\ProfileNewsletterForm', User::load($this->currentUser->id())),
        'connect_account' => 'todo: implement connect account',
        'menu' => $this->getMenuLinks(),
        'position' => $position,
      ],
    ];
  }

  public function donations(User $user) {
    $is_subscription_monthly = FALSE;
    $current_user = \Drupal::currentUser();
    if ($current_user->isAuthenticated()) {
      if (!empty($current_user->getEmail())) {
        $user_email = $current_user->getEmail();
        $query = \Drupal::service('obw_utilities.entity_query');
        $sids = $query->getSubmissionIDByEmailInSupportUs($user_email);
        if (!empty($sids)) {
          $sids_array = [];
          $histories_donate = [];
          foreach ($sids as $sid) {
            $sids_array[] = $sid->sid;
          }
          $submissions = WebformSubmission::loadMultiple($sids_array);
          foreach ($submissions as $submission) {
            $ws_data = $submission->getData();
            switch ($ws_data['payment_object']) {
              case 'charge':
                $payment_object = 'One-Time';
                break;
              case 'subscription':
                $payment_object = 'Monthly';
                break;
              default:
                $payment_object = $ws_data['payment_object'];
            }

            switch ($ws_data['payment_status']) {
              case 'succeeded':
                $payment_status = 'Complete';
                break;
              case 'inactive':
                $payment_status = 'Cancelled';
                break;
              case 'active':
                $payment_status = 'Ongoing';
                break;
              default:
                $payment_status = $ws_data['payment_status'];
            }

            $histories_donate[] = [
              'create_date' => date('d/m/Y', $submission->getCreatedTime()),
              'payment_amount' => 'S$' . str_replace('.00', '', number_format($ws_data['payment_amount'], '2')),
              'payment_object' => $payment_object,
              'payment_status' => $payment_status,
            ];
          }
        }

        $config = \Drupal::config('stripe.settings');
        $private_key = $config->get('apikey.' . $config->get('environment') . '.secret');
        Stripe::setApiKey($private_key);
        $customers = Customer::all(['email' => $user_email]);
        if (!empty($customers)) {
          $values = $customers->values();
          if (!empty($values[1][0])) {
            $customer = $values[1][0];
            if (!empty($customer->subscriptions) && !empty($customer->subscriptions->data)) {
              $is_subscription_monthly = TRUE;
            }
          }
        }
      }
    }
    return [
      '#theme' => 'profile_donations_page',
      '#content' => [
        'donations' => 'todo: implement donations',
        'menu' => $this->getMenuLinks('donations'),
        'is_subscription_monthly' => $is_subscription_monthly,
        'histories_donate' => isset($histories_donate) ? $histories_donate : FALSE,
      ],
      '#cache' => ['max-age' => 0],
    ];
  }

  public function actions(User $user) {
    $gsoty_config = \Drupal::config('obw_gsoty.config');
    if (!empty($gsoty_config)) {
      $is_enable_my_vote_tab = $gsoty_config->get('OBW_ENABLE_MY_VOTE_TAB');
    }

    if (isset($user->field_gsoty_story_id) && !empty($user->field_gsoty_story_id->value)) {
      $gsoty_story_id = $user->field_gsoty_story_id->value;
      if (preg_match('/node\/(\d+)/', $gsoty_story_id, $matches)) {
        $gsoty_story_id = $matches[1];
      }
    }
    return [
      '#theme' => 'profile_actions_page',
      '#content' => [
        'menu' => $this->getMenuLinks('actions'),
        'user_id' => $user->id(),
        'gsoty_story_id' => isset($gsoty_story_id) ? $gsoty_story_id : '-1',
        'is_enable_my_vote_tab' => isset($is_enable_my_vote_tab) ? $is_enable_my_vote_tab : 0,
      ],
      '#cache' => [
        'contexts' => ['user'],
      ],
    ];
  }

  public function storyReference(User $user) {

    $view_mode = 'stories_reference';
    $em = \Drupal::entityTypeManager();
    $build = $em->getViewBuilder('user')->view($user, $view_mode);
    $action_countries = $user->get('field_account_countries')->getValue();
    $action_actions = $user->get('field_account_actions')->getValue();
    $action_cause = $user->get('field_account_cause')->getValue();

    $flag_action = FALSE;
    if ($action_countries || $action_actions || $action_cause) {
      $flag_action = TRUE;
    }

    return [
      '#theme' => 'profile_story_reference_page',
      '#content' => [
        'build' => $build,
        'menu' => $this->getMenuLinks('story'),
        'flag_action' => $flag_action,
      ],

    ];
  }

  public function youCanHelpStories(User $user) {

    $countries = '';
    $causes = '';
    $actions = '';

    $actions_countries = $user->get('field_account_countries')->getValue();
    $list_countries = [];
    if ($actions_countries) {
      foreach ($actions_countries as $index => $item) {
        $list_countries[] = $item['target_id'];
      }
      $countries = implode(',', $list_countries);
    }

    $actions_action = $user->get('field_account_actions')->getValue();
    $list_actions = [];
    if ($actions_action) {
      foreach ($actions_action as $index => $item) {
        $list_actions[] = $item['target_id'];
      }
      $actions = implode(',', $list_actions);
    }

    $actions_cause = $user->get('field_account_cause')->getValue();
    $list_cause = [];
    if ($actions_cause) {
      foreach ($actions_cause as $index => $item) {
        $list_cause[] = $item['target_id'];
      }
      $causes = implode(',', $list_cause);
    }

    if (empty($list_countries) && (!empty($list_cause) || !empty($list_actions))) {
      $countries = 'all';
    }
    if (empty($list_cause) && (!empty($list_countries) || !empty($list_actions))) {
      $causes = 'all';
    }
    if (empty($list_actions) && (!empty($list_countries) || !empty($list_cause))) {
      $actions = 'all';
    }
    return [
      '#theme' => 'you_can_help_stories_page',
      '#content' => [
        'countries' => $countries,
        'causes' => $causes,
        'actions' => $actions,
      ],
    ];
  }

  private function getMenuLinks($active_route = 'settings') {
    return '<li data-menu="General" ' . ($active_route == 'settings' ? 'class="active"' : '') . ' >' . $this->linkGenerator->generate(t('General'), new Url('obw_contributor_profile.profile_settings', ['user' => $this->currentUser->id()])) . '</li>'
      . '<li data-menu="My Donations" ' . ($active_route == 'donations' ? 'class="active"' : '') . '>' . $this->linkGenerator->generate(t('My Donations'), new Url('obw_contributor_profile.profile_donations', ['user' => $this->currentUser->id()])) . '</li>'
      . '<li data-menu="My Actions" ' . ($active_route == 'actions' ? 'class="active"' : '') . '>' . $this->linkGenerator->generate(t('My Actions'), new Url('obw_contributor_profile.profile_actions', [
        'user' => \Drupal::currentUser()
          ->id(),
      ])) . '</li>'
      . '<li data-menu="Story Reference" ' . ($active_route == 'story' ? 'class="active"' : '') . '>' . $this->linkGenerator->generate(t('Story Preferences'), new Url('obw_contributor_profile.profile_story_reference', [
        'user' => \Drupal::currentUser()
          ->id(),
      ])) . '</li>';
  }

  public function settingsNotID() {
    if (!$this->currentUser->id()) {
      return new RedirectResponse('/user/login?destination=/user/settings');
    }
    return new RedirectResponse('/user/' . $this->currentUser->id() . '/settings');
  }

}
