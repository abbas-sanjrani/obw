<?php
/**
 * Created by PhpStorm.
 * User: TRI_TRAN
 * Date: 10-Sep-18
 * Time: 11:30 PM
 */

namespace Drupal\obw_contributor_profile\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\image\Entity\ImageStyle;
use Drupal\user\Entity\User;

/**
 * Provides a '' block.
 *
 * @Block(
 *   id = "account_menu_block",
 *   admin_label = @Translation("Account menu block"),
 *
 * )
 */
class AccountMenuBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {

    $current_user = \Drupal::currentUser();

    if ($current_user) {
      $user = User::load($current_user->id());
      $profile_picture = '';
      if ($user->get('user_picture')->entity) {
        $profile_picture = $user->get('user_picture')->entity->uri->value;
        $style48x48 = ImageStyle::load('thumbnail_48_48_');
        $profile_picture = $style48x48->buildUrl($profile_picture);
      }

      $first_name = isset($user->get('field_account_first_name')
          ->getValue()[0]['value']) ? $user->get('field_account_first_name')
        ->getValue()[0]['value'] : "";
      $last_name = isset($user->get('field_account_last_name')
          ->getValue()[0]['value']) ? $user->get('field_account_last_name')
        ->getValue()[0]['value'] : "";
      $full_name = trim($first_name . " " . $last_name, " ");
      $user_name = !empty($full_name) ? $full_name : $current_user->getAccountName();

      $user_id = $current_user->id();

      $profile_type = 'public_profile';
      $entityTypeManager = \Drupal::entityTypeManager();
      /**
       * @var $public_profile \Drupal\profile\Entity\Profile
       */
      $public_profile = $entityTypeManager->getStorage('profile')
        ->loadByUser($current_user, $profile_type);

      $profile_url = '#';
      if ($public_profile) {
        $profile_url = $public_profile->toUrl()->toString();
      }

    }

    return [
      '#theme' => 'account_menu_block',
      '#user_name' => $user_name,
      '#user_id' => $user_id,
      '#profile_url' => $profile_url,
      '#profile_photo' => $profile_picture,
      '#attached' => [
        'library' => [],
      ],
      '#cache' => [
        'contexts' => ['user'],
      ],
    ];
  }

}
