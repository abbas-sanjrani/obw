<?php

namespace Drupal\obw_contributor_profile\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;


class RouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection) {

    if ($route = $collection->get('entity.profile.type.user_profile_form')) {
      //change profile edit to admin theme
      $route->setOption('_admin_route', TRUE);
    }

    if ($route = $collection->get('entity.profile.delete_form')) {
      //change profile edit to admin theme
      $route->setOption('_admin_route', TRUE);
    }

    if ($route = $collection->get('user.reset')) {
      $route->setDefault('_controller', '\Drupal\obw_contributor_profile\Controller\UserController::resetPass');
    }

    if ($route = $collection->get('user.reset.login')) {
      $route->setDefault('_controller', '\Drupal\obw_contributor_profile\Controller\UserController::resetPassLogin');
    }

  }

}

/**
 * Symfony\Component\Routing\Route {#7755
 * -path: "/user/reset/{uid}/{timestamp}/{hash}"
 * -host: ""
 * -schemes: []
 * -methods: array:2 [
 * 0 => "GET"
 * 1 => "POST"
 * ]
 * -defaults: array:2 [
 * "_controller" => "\Drupal\user\Controller\UserController::resetPass"
 * "_title" => "Reset password"
 * ]
 * -requirements: array:1 [
 * "_access" => "TRUE"
 * ]
 * -options: array:3 [
 * "compiler_class" => "Symfony\Component\Routing\RouteCompiler"
 * "_maintenance_access" => true
 * "no_cache" => true
 * ]
 * -condition: ""
 * -compiled: Symfony\Component\Routing\CompiledRoute {#13161
 * -variables: array:3 [
 * 0 => "uid"
 * 1 => "timestamp"
 * 2 => "hash"
 * ]
 * -tokens: array:4 [
 * 0 => array:4 [
 * 0 => "variable"
 * 1 => "/"
 * 2 => "[^/]++"
 * 3 => "hash"
 * ]
 * 1 => array:4 [
 * 0 => "variable"
 * 1 => "/"
 * 2 => "[^/]++"
 * 3 => "timestamp"
 * ]
 * 2 => array:4 [
 * 0 => "variable"
 * 1 => "/"
 * 2 => "[^/]++"
 * 3 => "uid"
 * ]
 * 3 => array:2 [
 * 0 => "text"
 * 1 => "/user/reset"
 * ]
 * ]
 * -staticPrefix: "/user/reset"
 * -regex:
 * "#^/user/reset/(?P<uid>[^/]++)/(?P<timestamp>[^/]++)/(?P<hash>[^/]++)$#sD"
 * -pathVariables: array:3 [
 * 0 => "uid"
 * 1 => "timestamp"
 * 2 => "hash"
 * ]
 * -hostVariables: []
 * -hostRegex: null
 * -hostTokens: []
 * }
 * }
 */
