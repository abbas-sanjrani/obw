<?php

namespace Drupal\obw_custom_filter\TwigExtension;

use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;

class CustomFilter extends AbstractExtension {

  /**
   * Generates a list of all Twig filters that this extension defines.
   */
  public function getFilters() {
    return [
      new TwigFilter('youtubeid', [$this, 'matchYoutubeId']),
      new TwigFilter('getCurrentUrl', [$this, 'getCurrentUrl']),
    ];
  }

  /**
   * Gets a unique identifier for this Twig extension.
   */
  public function getName() {
    return 'obw_custom_filter.twig_extension';
  }

  /**
   * Replaces all numbers from the string.
   */
  public static function matchYoutubeId($string) {
    $group_matched = '';
    if (preg_match('%(?:youtube\.com/(?:v|e(?:mbed)?)/|.*[?&]v=|youtu\.be/)([^"&?/ ]{11})%i', $string, $group_matched)) {
      return $group_matched[1];
    }
    return $string;
  }

  /**
   * get vr url
   */
  public static function getCurrentUrl($string) {
    $host = \Drupal::request()->getSchemeAndHttpHost();
    $current_uri = \Drupal::request()->getRequestUri();

    return $host . $current_uri;
  }

}
