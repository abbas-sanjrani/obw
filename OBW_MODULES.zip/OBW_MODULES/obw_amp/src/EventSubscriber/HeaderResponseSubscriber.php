<?php

namespace Drupal\obw_amp\EventSubscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Class ExampleLoginListener.
 *
 * @package Drupal\example
 */
class HeaderResponseSubscriber implements EventSubscriberInterface {

  public function onRespond(ResponseEvent $event) {
    $request = $event->getRequest();

    $response = $event->getResponse();
    if ($request->query->has("__amp_source_origin")) {
      $__amp_source_origin = $request->query->get("__amp_source_origin");
      $origin = $__amp_source_origin;
      if ($request->headers->has("Origin")) {
        $origin = $request->headers->get("Origin");
      }
      $response->headers->set('Access-Control-Allow-Origin', $origin);
      $response->headers->set('AMP-Access-Control-Allow-Source-Origin', $__amp_source_origin);
      $response->headers->set('Access-Control-Expose-Headers', 'AMP-Access-Control-Allow-Source-Origin');
    }
  }

  public static function getSubscribedEvents() {
    $events[KernelEvents::RESPONSE][] = ['onRespond'];
    return $events;
  }

}
