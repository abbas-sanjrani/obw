<?php

namespace Drupal\obw_amp\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class CommentController.
 */
class CommentController extends ControllerBase {
    /**
   * Returns a comment page.
   *
   * @return array
   *   A simple renderable array.
   */
    public function show($node_id) {
        $element = array(
            '#attached' => array(
                'library' => array('obw_amp/coral-talk'),
            ),
        );
        
        return $element;
    }
}