var nodeActionParams = JSON.parse(drupalSettings.obw_theme.node_user_actions);

var isStory = nodeActionParams.isStory;
var userId = nodeActionParams.userId;

var storyPath = nodeActionParams.story_path;
var image_url = nodeActionParams.imageURL;
var user_id = nodeActionParams.user_id;
var user_email = nodeActionParams.user_email;
var user_name = nodeActionParams.user_name;
var jwt_audience = nodeActionParams.jwt_audience;
var jwt_issuer =  nodeActionParams.jwt_issuer;
var secret =  nodeActionParams.secret;
var coral_base_url =  nodeActionParams.coral_base_url;
var user_firstname = nodeActionParams.first_name;
var user_lastname = nodeActionParams.last_name;
var login_url = nodeActionParams.login_url;
var signup_url = nodeActionParams.signup_url;
var comment_path = nodeActionParams.comment_path;
var is_comment_text_changed = false;

(function($, Drupal, drupalSettings) {
  $(".close-comment").click(function() {
    window.location.assign(storyPath);
  });
  window.addEventListener(
    "message",
    function(event) {
      if (event.origin !== coral_base_url) {
        return;
      }

      var message = event.data;
      var loginElement = $(".user-group .user-button-group a.login-btn.use-ajax");
      var signupElement = $(".user-group .user-button-group a.sign-up-btn.use-ajax");

      if (message === "doLogin mobile" || message === "doLogin desktop") {
        window.location.assign(login_url + "?destination=" + comment_path);
      }
      if (message === "doSignin mobile" || message === "doSignin desktop") {
        window.location.assign(signup_url + "?destination=" + comment_path);
      }
      if (message === "comment input change") {
        window.onbeforeunload = function(e) {
          e.returnValue = "input changed";
        }
        is_comment_text_changed = true;
      }
      if (message === "comment input unchange") {
        window.onbeforeunload = null;
        is_comment_text_changed = false;
      }
    },
    false
  );

  function isMobile() {
    var isMobile = false; //initiate as false
    // device detection
    if (
      /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(
        navigator.userAgent
      ) ||
      /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(
        navigator.userAgent.substr(0, 4)
      )
    ) {
      isMobile = true;
    }
    return isMobile;
  }

  function getTotalComment() {
    var path = window.location.protocol + "//" + window.location.hostname + window.location.pathname;
    $.ajax({
      type: "POST",
      url: coral_base_url + "/api/v1/graph/ql",
      data: JSON.stringify({
        query:
          "query GetTotalComments($url: String!) {asset(url: $url) { title totalCommentCount(tags: []) }}",
        variables: {
          // url: window.location.href.replace(/[\?#]([#\w\s\b\?=])*$/g, "")
          url: path
        }
      }),
      crossDomain: true,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      error: function(err) {
        // console.log("error during request graph", err);
      },
      dataType: "json",
      success: function(response) {
        $(".comment-box .action-wrap span")[0].innerHTML =
          response.data.asset.totalCommentCount;
      }
    });
  }

  function getAuthToken(email, password) {
    let loginInfo = null;

    try {
      loginInfo = $.ajax({
        type: "POST",
        url: coral_base_url + "/api/v1/auth/local",
        data: JSON.stringify({
          email: email,
          password: password
        }),
        headers: {
          "Content-Type": "application/json",
          "Accesss-Control-Allow-Origin": "*"
        },
        dataType: "json"
      });
    } catch (err) {
      // console.log("err during login: ", err);
    }

    return loginInfo;
  }

  function registerUser(username, email, password) {
    let userInfo = null;

    try {
      userInfo = $.ajax({
        type: "POST",
        url: coral_base_url + "/api/v1/users",
        data: JSON.stringify({
          username: username,
          email: email,
          password: password
        }),
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        dataType: "json",
        success: function(result) {
          userInfo = result;
          // console.log("Result userInfo:", userInfo);
        }
      });
    } catch (err) {
      // console.log("err during resiter user: ", err);
    }

    return userInfo;
  }

  function loginTalk(username, email, password) {
    let loginInfo = getAuthToken(email, password);
    let userInfo = null;

    if (!loginInfo) {
      userInfo = registerUser(username, email, password);

      if (userInfo) {
        loginInfo = getAuthToken(email, password);
      }

      // TODO: handle when cannot register
    }
  }

  function generateToken(
    id,
    username,
    email,
    jwt_audience,
    jwt_issuer,
    secret,
    imageURL,
    user_firstname,
    user_lastname,
    callback
  ) {
    let resultToken = null;

    try {
      result = $.ajax({
        type: "POST",
        url: coral_base_url + "/api/v1/auth/generateToken",
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        data: JSON.stringify({
          id: id,
          jwt_audience: jwt_audience,
          jwt_issuer: jwt_issuer,
          secret: secret,
          username: username,
          email: email,
          imageURL: imageURL,
          firstname: user_firstname,
          lastname: user_lastname
        }),
        dataType: "json",
        success: function(result) {
          resultToken = result;
          // console.log("Result resultToken:", resultToken);
          callback(resultToken.token);
        }
      });
    } catch (err) {
      // console.log("err during generator api ", err);
    }

    return resultToken;
  }

  // default anonymous userId is d9f0d034-3a4a-4e3d-9861-e9854ed13180
  if (
    userId == "d9f0d034-3a4a-4e3d-9861-e9854ed13180" ||
    user_id == "anonymous"
  ) {
    userId = "";
  }

  function loadPage(token) {
    // embed coral-talk with token
    $.ajax({
      url: coral_base_url + "/static/embed.js",
      dataType: "script",
      success: function() {
        Coral.Talk.render(document.getElementById("coral_talk_stream"), {
          talk: coral_base_url,
          auth_token: token,
          events: function(events) {
            events.onAny(function(eventName, data) {
              if (eventName === 'query.CoralEmbedStream_Embed.ready') {
                // change scrolling field
                var talk_iframe = $("#coral_talk_stream_iframe").attr("scrolling", "yes");
                if (!isMobile()) {
                  document
                    .getElementById("coral_talk_stream_iframe")
                    .contentWindow.postMessage("desktop brower", coral_base_url);
                } else {
                  document
                    .getElementById("coral_talk_stream_iframe")
                    .contentWindow.postMessage("mobile brower", coral_base_url);
                }
              }
            });
          },
        });
      }
    });
  }

  if (isStory==1) {
    if (userId) {
      if (image_url === "") {
        image_url = null;
      }
      generateToken(
          user_id,
          user_name,
          user_email,
          jwt_audience,
          jwt_issuer,
          secret,
          image_url,
          user_firstname,
          user_lastname,
          loadPage
      );
    }
    else {
      loadPage(null);
    }
    // getTotalComment();
  }

  function closeCommentBox() {
    $(".overlay-box").fadeOut();
    $(".commmend-thread").removeClass("active");
    $("body").removeAttr("style");
    if (userId) {
      // getTotalComment();
    }
    window.onbeforeunload = null;
  }

  Drupal.behaviors.coralTalk = {
    attach: function(context, settings) {
      function commentBox() {
        $(".comment-box").on("click", function() {
          if (!isMobile()) {
            document
              .getElementById("coral_talk_stream_iframe")
              .contentWindow.postMessage("desktop brower", coral_base_url);
          } else {
            document
              .getElementById("coral_talk_stream_iframe")
              .contentWindow.postMessage("mobile brower", coral_base_url);
          }
          $(".overlay-box")
            .hide()
            .fadeIn();
          $(".commmend-thread").addClass("active");
          $("body").css({
            overflow: "hidden",
            position: "fixed",
            // 'transform' : 'translateX(-8px)',
          });
        });
        $(".close-comment").on("click", function() {
          if (is_comment_text_changed) {
            var confirmComment = confirm("Changes you made may not be saved, do you want to leave?");
            if (confirmComment == true) {
              // console.log("is_comment_text_changed:", is_comment_text_changed);
              is_comment_text_changed = false;
              closeCommentBox();
            }
          } else {
            closeCommentBox();
          }
        });
        $(".overlay-box").on("click", function() {
          if (is_comment_text_changed) {
            var confirmComment = confirm("Changes you made may not be saved, do you want to leave?");
            if (confirmComment == true) {
              // console.log("is_comment_text_changed:", is_comment_text_changed);
              is_comment_text_changed = false;
              closeCommentBox();
            }
          } else {
            closeCommentBox();
          }
        });
      }
      if (context === document) {
        commentBox();
      }
    }
  };
})(jQuery, Drupal, drupalSettings);

// console.log('parames:',nodeActionParams);
