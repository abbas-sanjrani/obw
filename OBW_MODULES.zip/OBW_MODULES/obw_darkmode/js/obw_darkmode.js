const checkbox = document.getElementById("checkbox");
// var status = localStorage.getItem("enable");

$(window).on("load", function () {
  if (localStorage.getItem("enable")) {
    DarkReader.enable({
      brightness: 100,
      contrast: 90,
      sepia: 10,
    });
  }
  if (localStorage.getItem("disable")) {
    DarkReader.disable();
  }

  checkbox.addEventListener("change", () => {
    if (checkbox.checked == true) {
      var set = DarkReader.enable({
        brightness: 100,
        contrast: 90,
        sepia: 10,
      });
      if (localStorage.getItem("disable")) {
        localStorage.removeItem("disable");
        localStorage.setItem("enable", set);
      } else {
        localStorage.setItem("enable", set);
      }
    } else {
      DarkReader.disable();
      localStorage.getItem("enable")
        ? localStorage.removeItem("enable")
        : localStorage.setItem("disable", set);
    }
  });
});

// function enable() {
//   DarkReader.enable({
//     brightness: 100,
//     contrast: 90,
//     sepia: 10,
//   });
// }

// function Disable() {
//   DarkReader.disable();
// }
