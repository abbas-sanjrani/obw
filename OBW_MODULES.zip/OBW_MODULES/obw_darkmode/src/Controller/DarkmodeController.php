<?php
namespace Drupal\obw_darkmode\Controller;
class DarkmodeController {
  public function Content() {
    return array(
      '#theme' => 'settings',
    );
  }
}
