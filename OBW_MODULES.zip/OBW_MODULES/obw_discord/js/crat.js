jQuery(function(){
    new Crate({
        server: drupalSettings['discord-server-channel'].server,
        channel: drupalSettings['discord-server-channel'].channel
    });
});