<?php

namespace Drupal\obw_discord\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class ObwDiscordController.
 */
class ObwDiscordController extends ControllerBase {

  /**
   * Webinar.
   *
   * @return string
   *   Return Hello string.
   */
  public function webinar() {
    \Drupal::service('page_cache_kill_switch')->trigger();
    $zoom_config = \Drupal::config('obw_discord.discordconfig');
    $discord_server = $zoom_config->get('discord_server');
    $discord_channel = $zoom_config->get('discord_channel'); 
  
    $build = [];
    $build['discord'] = [
      '#theme' => 'obw_discord',
      '#discord_server' => $discord_server,
      '#discord_channel' => $discord_channel,
    ];

    return $build;
  }

}
