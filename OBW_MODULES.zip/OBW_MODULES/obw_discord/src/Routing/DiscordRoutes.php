<?php

namespace Drupal\obw_discord\Routing;

use Symfony\Component\Routing\Route;

/**
 * Defines dynamic routes.
 */
class DiscordRoutes
{

    /**
     * Provides dynamic routes.
     */
    public function routes()
    {

        $config = \Drupal::config('obw_discord.discordconfig');
        
        $path = $config->get("discord_page_path");
        $path = trim($path);
        if($path == "")
        {
            $path = "/events/webinar-discord";
        }
        if($path[0] !== "/")
        {
            $path = "/".$path;
        }

        $routes = [];
        // Declares a single route under the name 'example.content'.
        // Returns an array of Route objects.
        $routes['example.content'] = new Route(
            // Path to attach this route to:
            $path,
            // Route defaults:
            [
                '_controller' => '\Drupal\obw_discord\Controller\ObwDiscordController::webinar',
                '_title' => 'Webinar Discord',
            ],
            // Route requirements:
            [
                '_permission' => 'access content',
            ]
        );
        return $routes;
    }
}
