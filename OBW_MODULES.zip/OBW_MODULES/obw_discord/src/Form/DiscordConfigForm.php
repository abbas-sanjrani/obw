<?php

namespace Drupal\obw_discord\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class DiscordConfigForm.
 */
class DiscordConfigForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'obw_discord.discordconfig',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'discord_config_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('obw_discord.discordconfig');
    $form['discord_server'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Discord server'),      
      '#default_value' => $config->get('discord_server'),
    ];
    $form['discord_channel'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Discord channel'),      
      '#default_value' => $config->get('discord_channel'),
    ];

    $form['discord_page_path'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Page path"),
      '#default_value' => $config->get('discord_page_path'),
      '#description' => $this->t("Please enter a path starting with / ")
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);

    $this->config('obw_discord.discordconfig')
      ->set('discord_server', $form_state->getValue('discord_server'))
      ->set('discord_channel', $form_state->getValue('discord_channel'))
      ->set('discord_page_path', $form_state->getValue('discord_page_path'))
      ->save();
  }

}
