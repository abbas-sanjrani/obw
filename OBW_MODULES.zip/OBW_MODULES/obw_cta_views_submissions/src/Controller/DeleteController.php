<?php
namespace Drupal\obw_cta_views_submissions\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use GuzzleHttp\Exception\RequestException;
/**
 * Class DeleteController.
 *
 * @package Drupal\obw_cta_views_submissions\Controller
 */
class DeleteController extends ControllerBase {

   /**
   * {@inheritdoc}
   * Json output from TBT and CTA
   */
  public function jsonOutputCtaAndTbt() {    
    $options = array(
      'headers' => array(
        'Content-Type' => 'application/json',
      ),    
      'auth' => ['han.duong', 'han.duong@kyanon.digital', 'Basic'],            
    );
    try {
      $client = \Drupal::httpClient();
      $response_lead = $client->request('GET','https://tbt-stg.ourbetterworld.org/leads-manage/json?_format=json', $options);
      //$data_lead = $response_lead->getBody()->getContents();    
      $raw_lead = json_decode($response_lead->getBody(), TRUE);

      $response_obw = $client->request('GET','https://stg.ourbetterworld.org/admin/cta-submission/json?_format=json', $options);
      //$data_obw = $response_obw->getBody()->getContents();      
      $raw_obw = json_decode($response_obw->getBody(), TRUE);

      if ($response_lead->getStatusCode() == 200 && $response_obw->getStatusCode() == 200) {
        $raws = array_merge($raw_obw,$raw_lead);
        $json = array('data' => $raws);      
        return new JsonResponse($json);
        // $response = new Response();
        // $response->setContent($raws);
        // $response->headers->set('Content-Type', 'application/json');
        // return $response;     
      }
    
    }
    catch (RequestException $e) {
      \Drupal::logger('call Rest API')->error($e);
    } 
  }

  /**
   * {@inheritdoc}
   * Deletes the duplicate email
   */
  public function deleteCtaSubmission() {    
    
    $database = \Drupal::database();        
    $query = $database->query('
      SELECT * FROM 
      node as node, 
      node__field_story_call_to_actions as nodestory,
      node__field_cta_form_detail as nodecta
      WHERE nodestory.entity_id=node.nid 
      and nodecta.entity_id = nodestory.field_story_call_to_actions_target_id
      ORDER BY `nodestory`.`entity_id` DESC
    ');
    if ($query) {
      while ($row = $query->fetchAssoc()) {        
        $query_webform = \Drupal::entityQuery('webform_submission')
        ->condition('webform_id', $row['field_cta_form_detail_target_id']);    
        $result_webform = $query_webform->execute();          
        $submission_data = [];
        foreach ($result_webform as $item) {      
          $submission = \Drupal\webform\Entity\WebformSubmission::load($item);      
          $sub_object  = $submission->getData();               
          if (!empty($sub_object['email'])) {
            $submission_data[$item]  = $sub_object['email'];                    
          }          
        }
        $unique = array_unique($submission_data);    
        $duplicates = array_diff_assoc($submission_data, $unique);
        if (!empty($duplicates))
        foreach ($duplicates as $key => $value) {
          $webform_submission = \Drupal\webform\Entity\WebformSubmission::load($key);          
          if (!empty($webform_submission)) {            
            $webform_submission->delete();
          }
        }
     
      }
    }
    return new RedirectResponse('/admin/cta-submission');     
  }

  public function scraping(){
    $arr = array();
    $database = \Drupal::database();    
  
    // node__field_series_override_url
      $query = $database->query('
        SELECT *
        FROM 
          node as node, 
          node_field_data,
          node__field_series_override_url as node_cta
        WHERE 
          node_cta.entity_id = node.nid 
        and 
          node_cta.entity_id = node_field_data.nid
      ');
      $result = $query->fetchAll();
      
      for ($i = 0; $i < count($result); $i++){
        $title = $result[$i]->title;
        $url_source = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$result[$i]->nid);
        $link = $result[$i]->field_series_override_url_uri;
        if(!empty($result[$i]->field_series_override_url_options)){ 
          $target_arr = unserialize($result[$i]->field_series_override_url_options);

          if(isset($target_arr['attributes']['target']) &&  $target_arr['attributes']['target']== '_self'){
            $target_value = "Existing Tab";
          }else if(isset($target_arr['attributes']['target']) &&  $target_arr['attributes']['target']== '_blank'){
            $target_value = "New Tab";
          }

        }else{ $target_value = null; }
        $array = ['title'=> $title, 'url'=>$url_source ,'link'=>$link, 'target'=>$target_value];
        array_push($arr, $array);
      }
    //node__field_series_override_url
    // node__field_partner_url
      $query = $database->query('
      SELECT *
      FROM 
        node as node, 
        node_field_data,
        node__field_partner_url as node_partner
      WHERE 
        node_partner.entity_id = node.nid 
      and 
        node_partner.entity_id = node_field_data.nid
      ');
      $result = $query->fetchAll();

      for ($i = 0; $i < count($result); $i++){
        $title = $result[$i]->title;
        $url_source = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$result[$i]->nid);
        $link = $result[$i]->field_partner_url_uri;
        if(!empty($result[$i]->field_partner_url_options)){ 
          $target_arr = unserialize($result[$i]->field_partner_url_options);

          if(isset($target_arr['attributes']['target']) &&  $target_arr['attributes']['target']== '_self'){
            $target_value = "Existing Tab";
          }else if(isset($target_arr['attributes']['target']) &&  $target_arr['attributes']['target']== '_blank'){
            $target_value = "New Tab";
          }

        }else{ $target_value = null; }
        $array = ['title'=> $title, 'url'=>$url_source ,'link'=>$link, 'target'=>$target_value];
        array_push($arr, $array);
      } 
    //node__field_partner_url
      
    // node__field_cta_link
      $query = $database->query('
      SELECT *
      FROM 
        node as node, 
        node_field_data,
        node__field_cta_link as node_cta
      WHERE 
        node_cta.entity_id = node.nid 
      and 
        node_cta.entity_id = node_field_data.nid
      ');
      $result = $query->fetchAll();

      for ($i = 0; $i < count($result); $i++){
        $title = $result[$i]->title;
        $url_source = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$result[$i]->nid);
        $link = $result[$i]->field_cta_link_uri;
        if(!empty($result[$i]->field_cta_link_options)){ 
          $target_arr = unserialize($result[$i]->field_cta_link_options);

          if(isset($target_arr['attributes']['target']) &&  $target_arr['attributes']['target']== '_self'){
            $target_value = "Existing Tab";
          }else if(isset($target_arr['attributes']['target']) &&  $target_arr['attributes']['target']== '_blank'){
            $target_value = "New Tab";
          }

        }else{ $target_value = null; }
        $array = ['title'=> $title, 'url'=>$url_source ,'link'=>$link, 'target'=>$target_value];
        array_push($arr, $array);
      }
    //node__field_cta_link
    

    //dump($arr);    
    return new JsonResponse($arr);
  }  
  

}
