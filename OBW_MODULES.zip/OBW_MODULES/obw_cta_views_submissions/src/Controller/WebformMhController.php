<?php

namespace Drupal\obw_cta_views_submissions\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\webform\WebformInterface;
use Drupal\webform\WebformSubmissionInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
/**
 * Provides route responses for Webform entity.
 */
class WebformMhController extends ControllerBase implements ContainerInjectionInterface {

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected $renderer;

  /**
   * The webform request handler.
   *
   * @var \Drupal\webform\WebformRequestInterface
   */
  protected $requestHandler;  

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->renderer = $container->get('renderer');
    $instance->requestHandler = $container->get('webform.request');  
    return $instance;
  }

  
  public function drafts(Request $request, WebformInterface $webform = NULL, WebformSubmissionInterface $webform_submission = NULL) {  
    
    $source_entity = $this->requestHandler->getCurrentSourceEntity('webform');
    
    if (!$webform) {
      list($webform, $source_entity) = $this->requestHandler->getWebformEntities();
    }
    else {
      $source_entity = $this->requestHandler->getCurrentSourceEntity('webform');
    }
    
    if ($token = $request->get('token')) {      
      $webform_submission_storage = \Drupal::entityTypeManager()->getStorage('webform_submission');
      $mailManager = \Drupal::service('plugin.manager.mail');
      if ($entities = $webform_submission_storage->loadByProperties(['token' => $token])) {
        $webform_submission = reset($entities);      
      }
      
      $options = ['absolute' => TRUE];
      if ($webform_submission != null) {
        $data = $webform_submission->getData();
        
        $email = '<a href="'.$data['email'].'">'.$data['email'].'</a>';
        $link = Url::fromRoute('entity.node.canonical', ['node' => $source_entity->id(), 'token'=> $token], $options);
        
        $draft_message = $webform->getThirdPartySetting('drafts_message', 'enabled');        
        $draft_message = str_replace('[webform_submission:values:email]', $email , $draft_message);        
        $drafts_leftsidebar = $webform->getThirdPartySetting('drafts_leftsidebar', 'enabled');

        
        $params['link'] = $link->toString();
        $params['username'] = $data['first_name'];
        $module = 'obw_cta_views_submissions';
        $key = 'draft_send_mailer';
        $mailManager->mail($module, $key, $data['email'] , 'en', $params);

      } else {        
        $url = Url::fromRoute('entity.node.canonical', ['node' => $source_entity->id()], $options);
        $response = new RedirectResponse($url->toString());
        $response->send(); 
      }
        
    }
    
    $build = [
      '#link' => $link->toString(),
      '#message' => $draft_message,      
      '#leftsidebar' => $drafts_leftsidebar,    
      '#theme' => 'webform_draft',      
      '#webform' => $webform,
      '#source_entity' => $source_entity,
      '#webform_submission' => $webform_submission,
    ];      
    $build['#cache']['max-age'] = 0;
    return $build;
  }

  public function expired(Request $request, WebformInterface $webform = NULL, WebformSubmissionInterface $webform_submission = NULL) {  
    
    $source_entity = $this->requestHandler->getCurrentSourceEntity('webform');
    
    if (!$webform) {
      list($webform, $source_entity) = $this->requestHandler->getWebformEntities();
    }
    else {
      $source_entity = $this->requestHandler->getCurrentSourceEntity('webform');
    }    
    
    $draft_message_expired = $webform->getThirdPartySetting('drafts_message_expired', 'enabled');     
    $drafts_leftsidebar = $webform->getThirdPartySetting('drafts_leftsidebar', 'enabled');
    
    $build = [      
      '#message' => $draft_message_expired,      
      '#leftsidebar' => $drafts_leftsidebar,    
      '#theme' => 'webform_expired',      
      '#webform' => $webform,
      '#source_entity' => $source_entity,
      '#webform_submission' => $webform_submission,
    ];      
   
    return $build;
  }


}
