<?php

namespace Drupal\obw_cta_views_submissions\Validate;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form API callback. Validate element value.
 */
class EmailValidateConstraint {
  /**
  * Validates given element.   
  */
  public static function validate(array &$element, FormStateInterface $formState, array &$form) {
      
    $webformKey = $element['#webform_key'];
    $value = $formState->getValue($webformKey);
    
    if ($value === '' || is_array($value)) {
        return;
    }
    
    $session_handler = \Drupal::service('obw_social.session_handler');     
    //$session_handler->clear('is_email_non_member');  
    
    $member = \Drupal::entityQuery('user')
      ->condition('mail', $value)
      ->execute();      
    if (empty($member)) {   
      if ($session_handler->get('is_email_non_member') == NULL ) {    
        $formState->setError($element, t('Email is not a member.'));    
        $session_handler->set('is_email_non_member', $value);   
      } else {
        if ($session_handler->get('is_email_non_member') == $value) {
          $formState->clearErrors();                                              
          $session_handler->clear('is_email_non_member');
        } else {
          $formState->setError($element, t('Email is not a member.'));  
          $session_handler->set('is_email_non_member', $value);   
        }
      }
    } else {      
      $formState->clearErrors();                                              
    }       

  }
}