<?php

namespace Drupal\obw_cta_views_submissions\Element;

use Drupal\Core\Render\Element;
use Drupal\Core\Render\Element\FormElement;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\Markup;

/**
 * Provides a 'obw_cta_views_submissions'.
 *
 * Webform elements are just wrappers around form elements, therefore every
 * webform element must have correspond FormElement.
 *
 * Below is the definition for a custom 'obw_cta_views_submissions' which just
 * renders a simple text field.
 *
 * @FormElement("obw_cta_views_submissions")
 *
 * @see \Drupal\Core\Render\Element\FormElement
 * @see https://api.drupal.org/api/drupal/core%21lib%21Drupal%21Core%21Render%21Element%21FormElement.php/class/FormElement
 * @see \Drupal\Core\Render\Element\RenderElement
 * @see https://api.drupal.org/api/drupal/namespace/Drupal%21Core%21Render%21Element
 * @see \Drupal\obw_cta_views_submissions\Element\WebformExampleElement
 */
class OBWKeywordElement extends FormElement {

  /**
   * {@inheritdoc}
   */
  public function getInfo() {
    $class = get_class($this);
    return [   
      'keyword' => [
        '#markup' => Markup::create('<div class="container">
          <iframe src="http://keywords.baotram.info/" title="Keyword" width="790" height="300" scrolling="“no”" frameborder="“0”"></iframe></div>
        '),
      ],
      'ai' => [
        '#markup' => Markup::create('<div class="container">
          <iframe src="https://ihangover.vn/ai/" title="AI" width="450" height="600" scrolling="“no”" frameborder="“0”"></iframe></div>
        '),
      ]
    ];
    
  } 

}

