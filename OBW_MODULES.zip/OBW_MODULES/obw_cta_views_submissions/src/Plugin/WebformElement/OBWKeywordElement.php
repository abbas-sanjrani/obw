<?php

namespace Drupal\obw_cta_views_submissions\Plugin\WebformElement;

use Drupal\Core\Form\FormStateInterface;
use Drupal\webform\Plugin\WebformElementBase;
use Drupal\webform\WebformSubmissionInterface;

/**
 * Provides a 'obw_cta_views_submissions' element.
 *
 * @WebformElement(
 *   id = "obw_cta_views_submissions",
 *   label = @Translation("OBW Keyword Element"),
 *   description = @Translation("Provides a OBW keyword element."),
 *   category = @Translation("OBW elements"),
 * )
 *
 * @see \Drupal\obw_cta_views_submissions\Element\OBWKeywordElement
 * @see \Drupal\webform\Plugin\WebformElementBase
 * @see \Drupal\webform\Plugin\WebformElementInterface
 * @see \Drupal\webform\Annotation\WebformElement
 */
class OBWKeywordElement extends WebformElementBase {

  /**
   * {@inheritdoc}
   */
  protected function defineDefaultProperties() {   
    return [
      'multiple' => '',
      'size' => '',
      'minlength' => '',
      'maxlength' => '',
      'placeholder' => '',
    ] + parent::defineDefaultProperties();
  } 

}
