/*(function ($, Drupal) {
  $(document).ready(function(){
      $('.question textarea').attr('maxlength', '');
      $('.webform-cta-submition .webform-actions').attr('style', 'max-width: 100% !important');      
      var parent = $('.question-label, .question legend').parent();
      $('.question-label, .question legend').on('click', function(){
          if($(this).parent().hasClass('active')) {
              $(this).parent().removeClass('active')
              $(this).next().slideToggle();
          } else {
              $('.question.active .form-textarea-wrapper, .question.active .js-webform-radios, .question.active .js-webform-checkboxes').slideToggle();
              parent.removeClass('active');
              $(this).parent().addClass('active');
              $(this).next().slideToggle();
          }
      });     
  });
})(jQuery, Drupal); */


(function ($, Drupal) {
  $(document).ready(function () {
    // limit words text

    var text = $(".form-textarea-wrapper textarea");
    for (let i = 0; i < text.length; i++) {
      var text_typef = $(text[i]).attr('data-counter-type');
      if (text_typef == 'character') {
        var text_lengthf = $(text[i]).val();
        var text_maxf = $(text[i]).attr('data-counter-maximum');
        var text_message = $(text[i]).attr('data-counter-maximum-message');
        if (text_message === undefined) {
          text_message = " ";
        }
        var wordsf = text_lengthf.length;
        if (wordsf > text_maxf) {
          $(text[i]).next().html("<p class='alert-limit overLimitText'><span>" + text_message + " " + wordsf + "</span>/<span>" + text_maxf + "</span></p>");
        } else {
          $(text[i]).next().html("<p class='alert-limit'><span>" + wordsf + "</span>/<span>" + text_maxf + "</span></p>");
        }
      } else {
        var text_lengthf = $(text[i]).val().split(' ');;
        var text_maxf = $(text[i]).attr('data-counter-maximum');
        var text_message = $(text[i]).attr('data-counter-maximum-message');
        if (text_message === undefined) {
          text_message = " ";
        }
        var wordsf = text_lengthf.length;
        if (wordsf > text_maxf) {
          $(text[i]).next().html("<p class='alert-limit overLimitText'><span>" + text_message + " " + wordsf + "</span>/<span>" + text_maxf + "</span></p>");
        } else if (wordsf > 1) {
          $(text[i]).next().html("<p class='alert-limit'><span>" + wordsf + "</span>/<span>" + text_maxf + "</span></p>");
        } else {
          $(text[i]).next().html("<p class='alert-limit'><span>0</span>/<span>" + text_maxf + "</span></p>");
        }
      }
      $(text[i]).keyup(function () {
        var text_type = $(text[i]).attr('data-counter-type');
        if (text_type == 'character') {
          var text_length = $(text[i]).val();
          var text_max = $(text[i]).attr('data-counter-maximum');
          var text_message = $(text[i]).attr('data-counter-maximum-message');
          if (text_message === undefined) {
            text_message = " ";
          }
          var words = text_length.length;
        } else {
          var text_length = $(text[i]).val().split(' ');
          var text_max = $(text[i]).attr('data-counter-maximum');
          var text_message = $(text[i]).attr('data-counter-maximum-message');
          if (text_message === undefined) {
            text_message = " ";
          }
          var words = text_length.length;
        }

        if (words > text_max) {
          $(text[i]).next().html("<p class='alert-limit overLimitText'><span>" + text_message + " <b>" + words + "</b></span>/<span>" + text_max + "</span></p>");
        } else {
          $(text[i]).next().html("<p class='alert-limit'><span>" + words + "</span>/<span>" + text_max + "</span></p>");
        }
      });
    }

    // Scroll to text field empty
    /*  $('#edit-actions-submit').click(function (e) {
        var isOverLimits = $(".overLimitText");
        if ($(isOverLimits).length > 0) {
          // $('.page-loading').remove();
          // e.preventDefault();
          // const id = $(isOverLimits).parent().prev().attr('id');
          // const pos = $("#" + id).offset().top;
          // //console.log(pos);
          // //   location.href = "#"+id;
          // $('body, html').animate({
          //   scrollTop: pos - 200
          // });
        }
      }) */

    // close accordion
    var acc = document.getElementsByClassName("question-label");
    var i;
    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function () {
        Ontoggle(this)
        var thisIs = $(this).parent().find('textarea');
        $(thisIs).attr("disabled", true);
        setTimeout(function () {
          $(thisIs).removeAttr("disabled");
        }, 200);
        setTimeout(function () {
          $(thisIs).trigger('click');
        }, 250);
      });
    }


    function Ontoggle(acc) {
      $(acc).parent().toggleClass("active");
      var panel = acc.nextElementSibling;
      if (panel.style.maxHeight) {
        panel.style.maxHeight = null;
      } else {
        panel.style.maxHeight = panel.scrollHeight + 50 + "px";
      }
    }

    $('body').on('click', function (e) {
      var f = $('.question.active')
      if (f.length > 0 && !$(e.target).closest("#edit-container-03").length) {
        f.each(function (i) {
          switch (true) {
            case $(f[i]).find('textarea').length && !$(f[i]).find('textarea').val():
            case $(f[i]).find('input.form-text').length && !$(f[i]).find('input.form-text').val():
            case $(f[i]).find('input.form-radio').length && !$(f[i]).find('input').is(':checked'):
            case $(f[i]).find('select.form-select').length && !$(f[i]).find('select.form-select').val():
            case $(f[i]).find('input.form-checkbox').length && !$(f[i]).find('input.form-checkbox').is(':checked'):
              CloseAll(f[i]);
          }

          function CloseAll(f) {
            $(f).children('label').trigger("click");
          }
        })
      }
    });
    var f = $('.question')
    f.each(function (i) {
      switch (true) {
        case $(f[i]).find('textarea').length && $(f[i]).find('textarea').val().length > 0:
        case $(f[i]).find('input.form-text').length && $(f[i]).find('input.form-text').val().length > 0:
        case $(f[i]).find('input.form-radio').length && $(f[i]).find('input').is(':checked'):
        case $(f[i]).find('select.form-select').length && $(f[i]).find('select.form-select').val().length > 0:
        case $(f[i]).find('input.form-checkbox').length && $(f[i]).find('input.form-checkbox').is(':checked'):
          $(f[i]).find('label').trigger("click");
      }
    })

    //Validate email form
    const validateEmail = (email) => {
      return email.match(
        /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
    };

    const validate = () => {
      const email = $('.form-email').val();
      const isErr = $(".form-item-email.wrongmail");
      if (validateEmail(email)) {
        $(".form-item-email").removeClass('wrongmail');
        $(".form-item-email").addClass('rightmail');
      } else {
        $(isErr).find('.prompt').text('Please enter your email in this format:  example@email.com');
        $(".form-item-email").addClass('wrongmail');
        $(".form-item-email").removeClass('rightmail');
      }
      return false;
    }

    $('input[type="email"]').on('input', validate);

    const isError = setInterval(function () {
      const email = $('.form-email').val();
      if (validateEmail(email)) {
        $('.form-item-email').addClass('rightmail');
        clearInterval(isError);
      }
    }, 100)

    $(".question textarea").attr("maxlength", "");
    $(".webform-cta-submition .webform-actions").attr("style", "max-width: 100% !important");

  });
})(jQuery, Drupal);
