(function ($, Drupal, drupalSettings) {

  'use strict';

  /**
   * Attaches the JS behavior
   */
  Drupal.behaviors.jsClearDuplicate = {
    attach: function (context, settings) {
      jQuery('.btn-slider').on('click', function() {        
        jQuery('.sliderPop').show();
        jQuery('.ct-sliderPop-container').addClass('open');	  
        jQuery('.sliderPop .ct-sliderPop-container').addClass('slides');
        jQuery('body').addClass('shadow');
      });    
      jQuery('.ct-sliderPop-close').on('click', function() {
        jQuery('.sliderPop').hide();
        jQuery('.ct-sliderPop-container').removeClass('open');	  
        jQuery('.sliderPop .ct-sliderPop-container').removeClass('slides');
        jQuery('body').removeClass('shadow');
      });
      jQuery('.ct-sliderPop-confirm').on('click', function() {
        location.href = '/admin/cta-submission/clear';        
        jQuery('.sliderPop').hide();
        jQuery('.ct-sliderPop-container').removeClass('open');	  
        jQuery('.sliderPop .ct-sliderPop-container').removeClass('slides');
        jQuery('body').removeClass('shadow');
      });      
    }
  };
})(jQuery, Drupal, drupalSettings);
